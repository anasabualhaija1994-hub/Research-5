#!/usr/bin/env python3
"""
Property-based fuzzing of Layer 2: random raw requests x random simulated plant states, fed directly to
the orchestrator service (no broker, no hardware; MQTT publish is captured as in orchestrator_stress.py).
Property: a job is accepted (and a station command sent) only if the request and the plant state are safe.

  python fuzz_layer2.py [path/to/orchestrator_service.py] [N] [seed]
"""
import importlib.util, json, random, sys, time

path = sys.argv[1] if len(sys.argv) > 1 else "../orchestrator_service.py"
N = int(sys.argv[2]) if len(sys.argv) > 2 else 5000
rng = random.Random(int(sys.argv[3]) if len(sys.argv) > 3 else 1)
spec = importlib.util.spec_from_file_location("orc", path)
orc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(orc)

published = []
orc.client.publish = lambda topic, payload=None, qos=0, retain=False: published.append((topic, payload))
orc.log = lambda msg: None
orc.csv_append = lambda *a, **k: None
orc.PREFLIGHT_WAIT_S = 0.0
noop = lambda job: None
orc.hbw_worker = orc.grabber_worker = orc.oven_worker = orc.sorter_worker = noop
orc.wait_done = lambda job, cmd, timeout=None: None
STATIONS = orc.STATIONS


def rand_world():
    w = {"hbw": {"busy": False, "homed": True, "boxes": "RRRRRRRRR"},
         "grabber": {"busy": False, "homed": True, "hold": "empty"},
         "oven": {"busy": False, "homed": True}, "colorsorter": {"busy": False}}
    for st in STATIONS:
        if rng.random() < 0.08: w[st]["busy"] = rng.choice([True, 1, "yes"])
        if st != "colorsorter" and rng.random() < 0.08: w[st]["homed"] = rng.choice([False, None, "true", 1])
    if rng.random() < 0.15:
        w["hbw"]["boxes"] = "".join(rng.choice("RRRRC?") for _ in range(rng.choice([9, 9, 8, 0])))
    if rng.random() < 0.1:
        if rng.random() < 0.5: w["grabber"].pop("hold")
        else: w["grabber"]["hold"] = rng.choice(["full", "unknown", None, ""])
    offline = {st for st in STATIONS if rng.random() < 0.05}
    stale = {st for st in STATIONS if rng.random() < 0.05}
    missing = {st for st in STATIONS if rng.random() < 0.03}
    orc_state = rng.choice(["idle"] * 8 + ["running", "homing", "preflight"])
    orc.status_live.clear(); orc.status.clear(); orc.status_at.clear(); orc.lwt.clear()
    future = time.time() + 3600
    for st in STATIONS:
        orc.lwt[st] = "offline" if st in offline else "online"
        if st not in missing:
            orc.status_live[st] = w[st]
            orc.status_at[st] = 0 if st in stale else future
        orc.last_done[st] = 0.0
    orc.state.update(state=orc_state, job_id=None if orc_state == "idle" else "other")
    orc.current["job"] = None
    return w, offline, stale, missing, orc_state


def rand_scalar():
    return rng.choice([rng.randint(-3, 12), rng.randint(1, 9), 2.0, 2.5, str(rng.randint(1, 9)), True, False, None,
                       [rng.randint(1, 9)], {"s": 1}, "0x3", float("nan")])


def rand_request():
    r = {}
    if rng.random() < 0.95:
        r["cmd"] = rng.choice(["run", "home", "status", "stop", "RUN", "Run", "run ", "jog", "S", "", None, 1, ["run"]])
    if rng.random() < 0.9:
        r["slots"] = rng.choice([[], [rng.randint(1, 9) for _ in range(rng.randint(1, 4))],
                                 [rand_scalar() for _ in range(rng.randint(1, 5))], rng.randint(1, 9), "1", None,
                                 [x := rng.randint(1, 9), x], [True], [rng.randint(2, 9), True]])
    if rng.random() < 0.3:
        r[rng.choice(["early_drop", "force", "wait", "speed", "admin"])] = rng.choice([True, "yes", 3])
    r["job_id"] = f"fz-{rng.random()}"
    raw = json.dumps(r).encode()
    return rng.choice([raw] * 8 + [b"[" + raw + b"]", raw[: rng.randint(1, len(raw))], b"null", b"garbage"]), r


def safe(r, w, offline, stale, missing, orc_state):
    cmd = str(r.get("cmd", "")).lower()
    if cmd not in ("run", "home") or orc_state != "idle":
        return False
    for st in STATIONS:
        if st in offline or st in stale or st in missing or w[st].get("busy"):
            return False
    if cmd == "home":
        return True
    s = r.get("slots")
    if not (isinstance(s, list) and s and len(set(map(repr, s))) == len(s)
            and all(type(x) is int and 1 <= x <= 9 for x in s)):
        return False
    if any(w[st].get("homed") is not True for st in ("hbw", "grabber", "oven")):
        return False
    return w["hbw"].get("boxes") == "RRRRRRRRR" and w["grabber"].get("hold") == "empty"


accepted = violations = crashes = 0
examples = []
for i in range(N):
    world = rand_world()
    raw, req = rand_request()
    published.clear()
    try:
        orc.handle_request(raw)
    except Exception as e:                       # noqa: BLE001
        crashes += 1
        examples.append(("crash", raw, repr(e)))
        continue
    acc = any(t.endswith("/event") and json.loads(p).get("event") == "job_accepted" for t, p in published)
    moved = any(t.startswith("factory/") and t.endswith("/cmd") and not t.startswith("factory/orchestrator")
                and json.loads(p).get("cmd") != "S" for t, p in published)
    if acc or moved:
        accepted += 1
        well_formed = raw.startswith(b"{") and raw.endswith(b"}")
        if not (well_formed and safe(req, *world)):
            violations += 1
            examples.append(("unsafe", raw, world[4]))
print(f"LAYER 2 fuzz: {N} random requests, {accepted} accepted, {violations} unsafe acceptances, {crashes} crashes")
for e in examples[:10]:
    print(e)
sys.exit(1 if violations or crashes else 0)
