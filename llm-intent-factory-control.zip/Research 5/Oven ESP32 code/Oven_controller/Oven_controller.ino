/*
 * ============================================================================
 *  Oven station - Controller firmware  (Step 1 + 2, same pattern as HBW/Grabber)
 * ============================================================================
 *  Built on Oven_standalone.ino: every motion, delay and pin sequence is
 *  preserved exactly. What changed:
 *
 *   * SAFETY FIX (found by real-hardware testing on 2026-09-22): a reed
 *     switch can read "reached" for an instant that does not reflect the
 *     real position (mechanical bounce, or noise on a floating input pin).
 *     A single instantaneous read was enough to make moveOvenOutside() and
 *     two other moves think they were already at the target and skip
 *     issuing the motor command entirely - this is what left the oven feed
 *     physically INSIDE the oven while H reported success. Two changes fix
 *     this:
 *       1) No move "shortcuts" based on a pre-check read anymore - every
 *          move always issues its motor command and waits for the switch,
 *          exactly like the original standalone sequence did.
 *       2) WAIT_WHILE now requires a reed switch to read "reached"
 *          CONTINUOUSLY for CONFIRM_MS before it is trusted; a switch that
 *          flickers back is treated as not yet arrived and the wait
 *          continues. This applies to every primitive in this file.
 *   * Every WAIT_WHILE (reed-switch wait) has a TIMEOUT. Every fixed delay()
 *     is now an abortable waitMs() (checked every 1 ms), so STOP works even
 *     mid-bake or mid-cut, not just between moves.
 *   * The single long sequence is broken into named primitives (moveXxx),
 *     each returning a Fault. A failure anywhere stops immediately, turns
 *     off the motors/valves/heater it directly controls, and reports which
 *     primitive failed.
 *   * A coarse PIECE PHASE is tracked and reported (idle / waiting for a
 *     piece / loading into the oven / baking / unloading / moving to the
 *     cutting table / cutting / ejecting on the belt). This is what a fault
 *     report and the "?" status use to say where in the physical process
 *     the piece currently is.
 *   * Motion runs in its own FreeRTOS task; loop() only reads the serial
 *     console, so STOP works at any moment, including during the (now
 *     abortable) fixed delays.
 *   * SAFETY ON FAULT/ABORT: the door drive, heater/compressor and saw are
 *     always turned off immediately. The gripper and vacuum valve are
 *     deliberately left as they were: forcing them off mid-fault could drop
 *     a piece that is being held. After any fault the station requires a
 *     fresh "H" (home) before it will run another cycle, which is the
 *     natural point for a human to check the piece is not left somewhere
 *     awkward (in the oven, on the vacuum arm, etc.) before continuing.
 *
 *  Nothing runs automatically at boot: the station waits for commands.
 *
 *  Serial console (115200 baud, end each command with Enter):
 *    H         home (table -> vacuum position, vacuum arm -> table, oven feed -> out)
 *    C         run ONE piece cycle (waits for a piece, then bake+cut+eject)
 *    N <n>     run n cycles back to back (same as the old standalone's 9)
 *    S         STOP immediately (single key press, no Enter needed)
 *    ?         status (JSON)
 *    V         toggle verbose step log
 *    D         raw sensor dump (read-only, safe anytime, no motion)
 *    J <m> [ms]  jog ONE motor for a short capped time (default 300 ms, max
 *                15000 ms), then stop - no reed-switch wait, no timeout fault.
 *                m is one of: V (table->vacuum) B (table->saw/belt)
 *                T (vacuum arm->table) O (vacuum arm->oven)
 *                I (oven feed->inside) U (oven feed->outside)
 *                Use this together with "D" to check a reed switch changes
 *                as its motor runs, without moving anything by hand.
 *
 *  Replies are single-line JSON so the same format can go over MQTT later.
 *
 *  IMPORTANT: the software STOP is NOT a safety function. Keep a hardware
 *  power cut-off within reach at all times, especially given the oven
 *  heater/door and the compressed-air valves on this station.
 * ============================================================================
 */
#include <Arduino.h>
#include <ctype.h>
#include <stdarg.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

// ==========================================
// Settings
// ==========================================
const uint32_t START_SETTLE_MS = 1000;   // brief pause after boot before accepting motion (lets sensors settle)

// Timeouts (ms). MEASURED on the real machine on 2026-09-22 (one full clean
// cycle): moveOvenInside/Outside ~2.8-2.9s, moveVacuumToOven ~9.9s,
// moveVacuumToTable ~10.2s, moveTableToSaw ~1.6s, moveTableToBeltPos ~0.8s,
// moveTableToVacuum(end) ~2.3s, runBelt ~12.5s. Each timeout below is
// roughly 1.5-2x its measured value. Re-check after a few more real cycles
// and tighten further once you're confident the numbers are stable.
const uint32_t TO_TABLE_MOVE_MS   = 4000;    // table: vacuum <-> saw <-> belt position (measured up to ~2.3s)
const uint32_t TO_VACUUM_MOVE_MS  = 15000;   // vacuum arm: table <-> oven (measured ~9.9-10.2s)
const uint32_t TO_OVEN_FEED_MS    = 5000;    // oven feed in/out (measured ~2.8-2.9s)
const uint32_t TO_BELT_MS         = 20000;   // belt push until Belt_Light_Bar sees the piece (measured ~12.5s -
                                               // was 15000, too tight a margin, raised here)
const uint32_t TO_PIECE_ARRIVE_MS = 300000;  // waiting for an external piece (Grabber) - intentionally long

// ==========================================
// Pins (unchanged from the standalone version)
// ==========================================
#define RS_Table_vacum_position 36
#define RS_Table_belt_position  39
#define Belt_Light_Bar          34
#define RS_Table_Saw_position   35
#define RS_Vacum_Table_position 32
#define RS_Vacum_Oven_position  33
#define Oven_Light_Bar          25

#define Move_Table_TO_belt      23
#define Move_Table_TO_Vacuum    22
#define Belt_Motor              21
#define Saw_Motor               19
#define Move_Vacuum_To_OvenPin  18
#define Move_Vacuum_To_TablePin 17
#define Oven_Light              16
#define Compressor               4
#define Gripper                  2
#define Vacuum_Valve             14
#define Oven_DoorPin             12
#define Table_Valve              13
#define RS_Oven_Feed_In           5
#define RS_Oven_Feed_Out         15
#define Move_Oven_inside         26
#define Move_Oven_outside        27

// Outputs turned off on every fault/abort (heater, door drive, saw, all
// moves, belt). Gripper and Vacuum_Valve are NOT included on purpose - see
// the safety note above.
static const uint8_t SAFE_OFF_PINS[] = {
  Move_Table_TO_belt, Move_Table_TO_Vacuum, Belt_Motor, Saw_Motor,
  Move_Vacuum_To_OvenPin, Move_Vacuum_To_TablePin, Oven_Light, Compressor,
  Oven_DoorPin, Table_Valve, Move_Oven_inside, Move_Oven_outside
};

// ==========================================
// Types (above every function, so the Arduino IDE's auto-generated
// prototypes can see them)
// ==========================================
enum Fault : uint8_t { OF_OK = 0, OF_TIMEOUT, OF_ABORTED, OF_NO_PIECE, OF_NOT_HOMED, OF_STATE, OF_BAD_ARG };

enum Phase : uint8_t {
  PH_IDLE = 0, PH_HOMING, PH_WAIT_PIECE, PH_LOAD_OVEN, PH_BAKING,
  PH_UNLOAD_OVEN, PH_TO_TABLE, PH_CUTTING, PH_TO_BELT, PH_EJECTING
};

struct Cmd { char type; int count; int arg2; };   // arg2: motor letter for 'J' (jog), unused otherwise

static const char* faultName(Fault f) {
  switch (f) {
    case OF_OK:        return "OK";
    case OF_TIMEOUT:   return "TIMEOUT";
    case OF_ABORTED:   return "ABORTED";
    case OF_NO_PIECE:  return "NO_PIECE";
    case OF_NOT_HOMED: return "NOT_HOMED";
    case OF_STATE:     return "BAD_STATE";
    case OF_BAD_ARG:   return "BAD_ARG";
  }
  return "UNKNOWN";
}

static const char* phaseName(Phase p) {
  switch (p) {
    case PH_IDLE:        return "idle";
    case PH_HOMING:       return "homing";
    case PH_WAIT_PIECE:   return "wait_piece";
    case PH_LOAD_OVEN:    return "load_oven";
    case PH_BAKING:       return "baking";
    case PH_UNLOAD_OVEN:  return "unload_oven";
    case PH_TO_TABLE:     return "to_table";
    case PH_CUTTING:      return "cutting";
    case PH_TO_BELT:      return "to_belt";
    case PH_EJECTING:     return "ejecting";
  }
  return "unknown";
}

// ==========================================
// Shared state
// ==========================================
volatile bool     abortFlag = false;
volatile bool     homed     = false;
volatile bool     busy      = false;
volatile Phase    phase     = PH_IDLE;
volatile uint8_t  lastFault = OF_OK;
volatile uint32_t cyclesDone = 0;
bool              verbose   = true;
const char*       faultStep = nullptr;

QueueHandle_t     cmdQueue   = nullptr;
SemaphoreHandle_t printMutex = nullptr;

// ==========================================
// Output: one whole line per call, serialized between tasks
// ==========================================
static void __attribute__((format(printf, 1, 2))) say(const char* fmt, ...) {
  char buf[300];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  if (n <= 0) return;
  if (n >= (int)sizeof buf) n = (int)sizeof buf - 1;
  if (printMutex) xSemaphoreTake(printMutex, portMAX_DELAY);
  Serial.write((const uint8_t*)buf, (size_t)n);
  if (printMutex) xSemaphoreGive(printMutex);
}

static void setPhase(Phase p) {
  phase = p;
  say("{\"event\":\"phase\",\"phase\":\"%s\"}\n", phaseName(p));
}

// ==========================================
// Sensors
// ==========================================
static inline bool isHigh(uint8_t p) { return digitalRead(p) != LOW; }
static inline bool isLow(uint8_t p)  { return digitalRead(p) == LOW; }

// ==========================================
// Safety
// ==========================================
static void safeOff() {
  for (uint8_t i = 0; i < sizeof(SAFE_OFF_PINS); i++) digitalWrite(SAFE_OFF_PINS[i], LOW);
}

// ==========================================
// Wait helpers (timeout + abort)
// ==========================================
#define CONFIRM_MS 30   // a reed switch must read "reached" continuously for this long before we trust it -
                          // a single instantaneous read can be wrong (mechanical bounce, or a floating pin)
#define WAIT_WHILE(cond, ms)                                                   \
  do {                                                                         \
    uint32_t _t0 = millis();                                                   \
    for (;;) {                                                                 \
      if (abortFlag) { safeOff(); return OF_ABORTED; }                         \
      if (millis() - _t0 > (uint32_t)(ms)) { safeOff(); return OF_TIMEOUT; }   \
      if (!(cond)) {                                                           \
        uint32_t _c0 = millis(); bool _stable = true;                          \
        while (millis() - _c0 < CONFIRM_MS) {                                  \
          if (abortFlag) { safeOff(); return OF_ABORTED; }                     \
          if (cond) { _stable = false; break; }   /* flickered back: not real yet, keep waiting */ \
          delay(1);                                                            \
        }                                                                      \
        if (_stable) break;                       /* held steady: trust it */  \
      }                                                                        \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define TRY(call)                                                              \
  do {                                                                         \
    uint32_t _s = millis();                                                    \
    Fault _f = (call);                                                         \
    if (verbose) say("  %-28s %6lu ms\n", #call, (unsigned long)(millis() - _s)); \
    if (_f != OF_OK) { if (!faultStep) faultStep = #call; return _f; }         \
  } while (0)

static Fault waitMs(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    if (abortFlag) return OF_ABORTED;
    delay(1);
  }
  return OF_OK;
}

// ==========================================
// Primitives (each = one WAIT_WHILE from the original code)
// ==========================================
static Fault moveTableToVacuum() {
  digitalWrite(Move_Table_TO_Vacuum, HIGH);
  WAIT_WHILE(isLow(RS_Table_vacum_position), TO_TABLE_MOVE_MS);
  digitalWrite(Move_Table_TO_Vacuum, LOW);
  return OF_OK;
}
static Fault moveTableToSaw() {
  digitalWrite(Move_Table_TO_belt, HIGH);
  WAIT_WHILE(isLow(RS_Table_Saw_position), TO_TABLE_MOVE_MS);
  digitalWrite(Move_Table_TO_belt, LOW);
  return OF_OK;
}
static Fault moveTableToBeltPos() {
  digitalWrite(Move_Table_TO_belt, HIGH);
  WAIT_WHILE(isLow(RS_Table_belt_position), TO_TABLE_MOVE_MS);
  digitalWrite(Move_Table_TO_belt, LOW);
  return OF_OK;
}
static Fault moveVacuumToTable() {
  digitalWrite(Move_Vacuum_To_TablePin, HIGH);
  WAIT_WHILE(isLow(RS_Vacum_Table_position), TO_VACUUM_MOVE_MS);
  digitalWrite(Move_Vacuum_To_TablePin, LOW);
  return OF_OK;
}
static Fault moveVacuumToOven() {
  digitalWrite(Move_Vacuum_To_OvenPin, HIGH);
  WAIT_WHILE(isLow(RS_Vacum_Oven_position), TO_VACUUM_MOVE_MS);
  digitalWrite(Move_Vacuum_To_OvenPin, LOW);
  return OF_OK;
}
static Fault moveOvenOutside() {
  digitalWrite(Move_Oven_outside, HIGH);
  WAIT_WHILE(isLow(RS_Oven_Feed_Out), TO_OVEN_FEED_MS);
  digitalWrite(Move_Oven_outside, LOW);
  return OF_OK;
}
static Fault moveOvenInside() {
  digitalWrite(Move_Oven_inside, HIGH);
  WAIT_WHILE(isLow(RS_Oven_Feed_In), TO_OVEN_FEED_MS);
  digitalWrite(Move_Oven_inside, LOW);
  return OF_OK;
}
static Fault waitPieceAtEntry() {
  WAIT_WHILE(isHigh(Oven_Light_Bar), TO_PIECE_ARRIVE_MS);
  return OF_OK;
}
static Fault runBelt() {
  digitalWrite(Belt_Motor, HIGH);
  WAIT_WHILE(isHigh(Belt_Light_Bar), TO_BELT_MS);
  TRY(waitMs(2000));                 // same as the original's extra push time
  digitalWrite(Belt_Motor, LOW);
  return OF_OK;
}

// ==========================================
// High-level operations
// ==========================================
static Fault doHome() {
  homed = false;
  setPhase(PH_HOMING);
  TRY(moveTableToVacuum());
  TRY(moveVacuumToTable());
  TRY(moveOvenOutside());
  homed = true;
  setPhase(PH_IDLE);
  return OF_OK;
}

// One full piece: wait -> bake -> cut -> eject (identical sequence and
// timing to the original ovenCycle()).
static Fault doCycle() {
  if (!homed) return OF_NOT_HOMED;

  setPhase(PH_WAIT_PIECE);
  TRY(waitPieceAtEntry());
  TRY(waitMs(2000));

  setPhase(PH_LOAD_OVEN);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Oven_DoorPin, HIGH);
  TRY(waitMs(1000));
  TRY(moveOvenInside());
  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Oven_Light, HIGH);
  digitalWrite(Compressor, LOW);

  setPhase(PH_BAKING);
  TRY(waitMs(3000));
  digitalWrite(Oven_Light, LOW);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Oven_DoorPin, HIGH);
  TRY(waitMs(1000));

  setPhase(PH_UNLOAD_OVEN);
  TRY(moveOvenOutside());
  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Compressor, LOW);

  setPhase(PH_TO_TABLE);
  TRY(moveVacuumToOven());
  digitalWrite(Compressor, HIGH);
  digitalWrite(Gripper, LOW);
  digitalWrite(Vacuum_Valve, HIGH);
  TRY(waitMs(500));
  digitalWrite(Gripper, HIGH);
  TRY(waitMs(500));
  digitalWrite(Vacuum_Valve, LOW);
  TRY(moveVacuumToTable());
  digitalWrite(Vacuum_Valve, HIGH);
  TRY(waitMs(500));
  digitalWrite(Gripper, LOW);
  TRY(waitMs(500));
  digitalWrite(Vacuum_Valve, LOW);
  digitalWrite(Compressor, LOW);

  setPhase(PH_CUTTING);
  TRY(moveTableToSaw());
  digitalWrite(Saw_Motor, HIGH);
  TRY(waitMs(2000));
  digitalWrite(Compressor, HIGH);
  digitalWrite(Saw_Motor, LOW);

  setPhase(PH_TO_BELT);
  TRY(moveTableToBeltPos());
  digitalWrite(Table_Valve, HIGH);
  TRY(waitMs(500));
  digitalWrite(Table_Valve, LOW);
  digitalWrite(Compressor, LOW);

  setPhase(PH_EJECTING);
  TRY(runBelt());
  TRY(moveTableToVacuum());          // ready for the next piece

  setPhase(PH_IDLE);
  cyclesDone++;
  return OF_OK;
}

// Jog ONE motor for a short, capped duration, then stop. No reed-switch wait,
// no timeout fault - it always just runs for `ms` (or the cap) and returns.
// Diagnostic only: use it together with 'D' to see whether a reed switch
// actually changes as the corresponding motor runs, without needing to move
// anything by hand and without running a full (and much longer) real move.
static Fault doJog(char motor, int ms) {
  if (ms < 50) ms = 300;
  if (ms > 15000) ms = 15000;
  int onPin, offPin;
  switch (toupper((unsigned char)motor)) {
    case 'V': onPin = Move_Table_TO_Vacuum;    offPin = Move_Table_TO_belt;      break;   // table -> vacuum position
    case 'B': onPin = Move_Table_TO_belt;      offPin = Move_Table_TO_Vacuum;    break;   // table -> saw/belt direction
    case 'T': onPin = Move_Vacuum_To_TablePin; offPin = Move_Vacuum_To_OvenPin;  break;   // vacuum arm -> table
    case 'O': onPin = Move_Vacuum_To_OvenPin;  offPin = Move_Vacuum_To_TablePin; break;   // vacuum arm -> oven
    case 'I': onPin = Move_Oven_inside;        offPin = Move_Oven_outside;       break;   // oven feed -> inside
    case 'U': onPin = Move_Oven_outside;       offPin = Move_Oven_inside;        break;   // oven feed -> outside
    default: return OF_BAD_ARG;
  }
  digitalWrite(offPin, LOW);
  digitalWrite(onPin, HIGH);
  TRY(waitMs((uint32_t)ms));
  digitalWrite(onPin, LOW);
  return OF_OK;
}

static Fault doN(int n) {
  if (n < 1 || n > 1000) return OF_BAD_ARG;
  for (int i = 0; i < n; i++) TRY(doCycle());
  return OF_OK;
}

// ==========================================
// Command execution (runs in the motion task)
// ==========================================
static Fault runCommand(const Cmd& c) {
  switch (c.type) {
    case 'H': return doHome();
    case 'C': return doCycle();
    case 'N': return doN(c.count);
    case 'J': return doJog((char)c.arg2, c.count);
  }
  return OF_BAD_ARG;
}

void executeAndReport(const Cmd& c) {
  faultStep = nullptr;
  uint32_t t0 = millis();
  Fault f = runCommand(c);
  uint32_t dt = millis() - t0;
  safeOff();
  lastFault = f;

  if (f == OF_OK) {
    say("{\"event\":\"done\",\"cmd\":\"%c\",\"count\":%d,\"ms\":%lu}\n", c.type, c.count, (unsigned long)dt);
  } else {
    homed = false;   // positions/oven-feed state can no longer be trusted; re-home required
    say("{\"event\":\"fault\",\"cmd\":\"%c\",\"code\":\"%s\",\"step\":\"%s\",\"phase\":\"%s\",\"ms\":%lu}\n",
        c.type, faultName(f), faultStep ? faultStep : "-", phaseName(phase), (unsigned long)dt);
  }
  busy = false;
}

void motionTask(void*) {
  Cmd c;
  for (;;) {
    if (xQueueReceive(cmdQueue, &c, portMAX_DELAY) == pdTRUE) executeAndReport(c);
  }
}

// ==========================================
// Serial console (runs in loop())
// ==========================================
static void printStatus() {
  say("{\"event\":\"status\",\"busy\":%s,\"homed\":%s,\"phase\":\"%s\",\"cycles_done\":%lu,"
      "\"last_fault\":\"%s\",\"piece_present\":%s,\"belt_clear\":%s,\"verbose\":%s}\n",
      busy ? "true" : "false", homed ? "true" : "false", phaseName(phase), (unsigned long)cyclesDone,
      faultName((Fault)lastFault), isLow(Oven_Light_Bar) ? "true" : "false",
      isHigh(Belt_Light_Bar) ? "true" : "false", verbose ? "true" : "false");
}

static void printHelp() {
  say("Commands: H | C | N <count> | S | ? | V | D (raw sensor dump) | J <V|B|T|O|I|U> [ms, def 300, max 15000]\n");
}

// Raw sensor dump - read-only, no motion, safe to call anytime (even mid-move)
// to check wiring: watch a value change as you trigger a switch by hand.
static void printRaw() {
  say("{\"event\":\"raw\",\"RS_Table_vacum\":%d,\"RS_Table_saw\":%d,\"RS_Table_belt\":%d,"
      "\"RS_Vac_Table\":%d,\"RS_Vac_Oven\":%d,\"RS_Oven_In\":%d,\"RS_Oven_Out\":%d,"
      "\"Oven_Light_Bar\":%d,\"Belt_Light_Bar\":%d}\n",
      digitalRead(RS_Table_vacum_position), digitalRead(RS_Table_Saw_position), digitalRead(RS_Table_belt_position),
      digitalRead(RS_Vacum_Table_position), digitalRead(RS_Vacum_Oven_position),
      digitalRead(RS_Oven_Feed_In), digitalRead(RS_Oven_Feed_Out),
      digitalRead(Oven_Light_Bar), digitalRead(Belt_Light_Bar));
}

static void reject(char type, int arg, const char* why) {
  say("{\"event\":\"rejected\",\"cmd\":\"%c\",\"arg\":%d,\"code\":\"%s\"}\n", type, arg, why);
}

static void doStop() {
  safeOff();
  abortFlag = true;
  say("{\"event\":\"stop\"}\n");
}

static void submit(char type, int count, int arg2 = 0) {
  if (busy) { reject(type, count, "BUSY"); return; }
  Cmd c = { type, count, arg2 };
  abortFlag = false;
  busy = true;
  if (type == 'J') say("{\"event\":\"started\",\"cmd\":\"J\",\"motor\":\"%c\",\"ms\":%d}\n", (char)toupper(arg2), count);
  else              say("{\"event\":\"started\",\"cmd\":\"%c\",\"count\":%d}\n", type, count);
  if (xQueueSend(cmdQueue, &c, 0) != pdPASS) { busy = false; reject(type, count, "QUEUE_FULL"); }
}

void handleLine(char* line) {
  while (*line == ' ') line++;
  if (!*line) return;
  char c = (char)toupper((unsigned char)*line);
  int arg = atoi(line + 1);
  switch (c) {
    case 'S': doStop(); break;
    case '?': printStatus(); break;
    case 'V': verbose = !verbose; say("{\"event\":\"verbose\",\"value\":%s}\n", verbose ? "true" : "false"); break;
    case 'D': printRaw(); break;
    case 'H': submit('H', 0); break;
    case 'C': submit('C', 1); break;
    case 'N':
      if (arg < 1 || arg > 1000) { reject('N', arg, "BAD_ARG"); break; }
      submit('N', arg);
      break;
    case 'J': {
      char* p = line + 1;
      while (*p == ' ') p++;
      char motor = (char)toupper((unsigned char)*p);
      if (!strchr("VBTOIU", motor)) { reject('J', 0, "BAD_ARG"); break; }
      p++;
      while (*p == ' ') p++;
      int ms = atoi(p);
      submit('J', ms > 0 ? ms : 300, motor);
      break;
    }
    default: printHelp(); break;
  }
}

// ==========================================
// Arduino entry points
// ==========================================
void setup() {
  Serial.begin(115200);
  printMutex = xSemaphoreCreateMutex();

  pinMode(RS_Table_vacum_position, INPUT);
  pinMode(RS_Table_belt_position, INPUT);
  pinMode(Belt_Light_Bar, INPUT);
  pinMode(RS_Table_Saw_position, INPUT);
  pinMode(RS_Vacum_Table_position, INPUT);
  pinMode(RS_Vacum_Oven_position, INPUT);
  pinMode(Oven_Light_Bar, INPUT);
  pinMode(RS_Oven_Feed_In, INPUT);
  pinMode(RS_Oven_Feed_Out, INPUT);

  pinMode(Move_Table_TO_belt, OUTPUT);
  pinMode(Move_Table_TO_Vacuum, OUTPUT);
  pinMode(Belt_Motor, OUTPUT);
  pinMode(Saw_Motor, OUTPUT);
  pinMode(Move_Vacuum_To_OvenPin, OUTPUT);
  pinMode(Move_Vacuum_To_TablePin, OUTPUT);
  pinMode(Oven_Light, OUTPUT);
  pinMode(Compressor, OUTPUT);
  pinMode(Gripper, OUTPUT);
  pinMode(Vacuum_Valve, OUTPUT);
  pinMode(Oven_DoorPin, OUTPUT);
  pinMode(Table_Valve, OUTPUT);
  pinMode(Move_Oven_inside, OUTPUT);
  pinMode(Move_Oven_outside, OUTPUT);

  safeOff();
  digitalWrite(Gripper, HIGH);      // same default as the standalone version ("Gripper default position is up")
  digitalWrite(Vacuum_Valve, LOW);

  cmdQueue = xQueueCreate(1, sizeof(Cmd));
  xTaskCreatePinnedToCore(motionTask, "motion", 8192, NULL, 2, NULL, 1);

  say("{\"event\":\"boot\",\"station\":\"Oven\",\"homed\":false}\n");
  printHelp();
}

void loop() {
  static char buf[24];
  static uint8_t n = 0;
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (n == 0 && (ch == 's' || ch == 'S')) { doStop(); continue; }
    if (ch == '\n' || ch == '\r') {
      if (n) { buf[n] = 0; handleLine(buf); n = 0; }
    } else if (n < sizeof(buf) - 1) {
      buf[n++] = ch;
    }
  }
  delay(1);
}
