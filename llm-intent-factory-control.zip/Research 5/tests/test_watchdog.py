"""Unit test of the orchestrator's heartbeat watchdog, without a broker (paho is replaced by a stub).
    python test_watchdog.py"""
import os, sys, time, threading, types
SENT = []
class _Client:
    def __init__(self, *a, **k): pass
    def will_set(self, *a, **k): pass
    def publish(self, topic, payload=None, qos=0, retain=False): SENT.append((topic, payload))
    def subscribe(self, *a, **k): pass
    def connect(self, *a, **k): pass
    def loop_start(self): pass
fake = types.SimpleNamespace(Client=_Client, CallbackAPIVersion=types.SimpleNamespace(VERSION2=2), SENT=SENT)
sys.modules["paho"] = types.ModuleType("paho"); sys.modules["paho.mqtt"] = types.ModuleType("paho.mqtt")
sys.modules["paho.mqtt.client"] = fake; sys.modules["paho.mqtt"].client = fake
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import orchestrator_service as o
o.LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
o.WATCHDOG_S = 0.7
threading.Thread(target=o.watchdog, daemon=True).start()

def beat(stations):
    for st in stations: o.status_at[st] = time.time()

# 1) healthy job: all stations beat every 0.5 s for 3 s -> no failure
job = o.Job("t-ok", [1]); o.current["job"] = job
for _ in range(6): beat(o.STATIONS); time.sleep(0.5)
assert not job.abort.is_set(), job.errors
print("healthy job: no watchdog firing")

# 2) hbw goes silent: others keep beating -> fail within ~0.7-0.8 s, STOP to all four
fake.SENT.clear()
job = o.Job("t-lost", [1]); o.current["job"] = job
beat(o.STATIONS); t_last = time.time()
while not job.abort.is_set() and time.time() - t_last < 3:
    beat(["grabber", "oven", "colorsorter"]); time.sleep(0.05)
dt = time.time() - t_last
assert job.abort.is_set() and "hbw lost" in job.errors[0] and "watchdog" in job.errors[0], job.errors
stops = {t for t, p in fake.SENT if t.endswith("/cmd") and '"S"' in str(p)}
assert stops == {f"factory/{s}/cmd" for s in o.STATIONS}, stops
print(f"silent hbw: job failed after {dt:.2f} s ({job.errors[0]}), STOP sent to {len(stops)} stations")

# 3) stale status at job start does not fire immediately (grace from job.t0)
for st in o.STATIONS: o.status_at[st] = time.time() - 100
job = o.Job("t-start", [1]); o.current["job"] = job
time.sleep(0.3); assert not job.abort.is_set(); time.sleep(0.6); assert job.abort.is_set()
print("stale status at job start: fires only after WATCHDOG_S from job start")

# 4) idle (no job) never fires; watchdog off (0) never fires
o.current["job"] = None; time.sleep(1.0)
o.WATCHDOG_S = 0; job = o.Job("t-off", [1]); o.current["job"] = job; time.sleep(1.0)
assert not job.abort.is_set(); print("idle and WATCHDOG_S=0: no firing")
print("ALL PASSED")
