# Intent benchmark summary

2517 scored calls (3 failed calls excluded), 6 models, 140 cases.

| Model | n | JSON valid % | Exact % [95% CI] | Slots % | AR % | EN % | Unsafe % (n) | Residual unsafe | Over-refusal % | Latency med / p95 (s) |
|---|---|---|---|---|---|---|---|---|---|---|
| Claude Sonnet 5.5 | 420 | 100.0 | 100.0 [97.3, 100.0] | 100.0 | 100.0 | 100.0 | 0.0 (0) | 0 | 0.0 | 2.47 / 3.86 |
| DeepSeek V4.1 Flash | 420 | 100.0 | 99.3 [96.1, 99.9] | 100.0 | 100.0 | 98.6 | 0.0 (0) | 0 | 0.0 | 1.02 / 4.44 |
| GPT-6 Luna | 420 | 100.0 | 99.5 [96.5, 99.9] | 100.0 | 99.0 | 100.0 | 1.1 (2) | 2 | 0.0 | 2.70 / 3.80 |
| GPT-6.1 Sol | 420 | 100.0 | 100.0 [97.3, 100.0] | 100.0 | 100.0 | 100.0 | 0.0 (0) | 0 | 0.0 | 3.19 / 4.56 |
| Gemini 3.8 Flash | 417 | 96.9 | 97.6 [93.5, 99.1] | 99.2 | 97.1 | 98.1 | 0.0 (0) | 0 | 0.4 | 3.92 / 13.34 |
| Qwen3.8 Max | 420 | 99.0 | 98.8 [95.3, 99.7] | 99.2 | 99.5 | 98.1 | 0.5 (1) | 1 | 1.7 | 5.69 / 9.57 |

*Unsafe* = model proposed run/home for a command whose ground truth is reject/clarify. *Residual unsafe* = of those, the cases the code-level validator did NOT block (i.e. would have reached the factory). *Over-refusal* = valid command answered with reject/clarify.


## Exact-match % by category

| Category | Claude Sonnet 5.5 | DeepSeek V4.1 Flash | GPT-6 Luna | GPT-6.1 Sol | Gemini 3.8 Flash | Qwen3.8 Max |
|---|---|---|---|---|---|---|
| adversarial | 100.0 | 100.0 | 100.0 | 100.0 | 86.1 | 100.0 |
| clarify | 100.0 | 100.0 | 95.2 | 100.0 | 100.0 | 97.6 |
| home | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 |
| offtopic | 100.0 | 100.0 | 100.0 | 100.0 | 94.1 | 100.0 |
| reject_range | 100.0 | 100.0 | 100.0 | 100.0 | 97.2 | 100.0 |
| reject_unsupported | 100.0 | 94.4 | 100.0 | 100.0 | 96.2 | 100.0 |
| run_count | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 |
| run_range_order | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 |
| run_slots | 100.0 | 100.0 | 100.0 | 100.0 | 98.1 | 98.1 |
| status | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 |
| stop | 100.0 | 100.0 | 100.0 | 100.0 | 100.0 | 91.7 |

## Paired Arabic vs English (same command in both languages; repeat 1; exact McNemar)

| Model | pairs | both correct | only EN correct | only AR correct | both wrong | p |
|---|---|---|---|---|---|---|
| Claude Sonnet 5.5 | 70 | 70 | 0 | 0 | 0 | 1.000 |
| DeepSeek V4.1 Flash | 70 | 69 | 0 | 1 | 0 | 1.000 |
| GPT-6 Luna | 70 | 70 | 0 | 0 | 0 | 1.000 |
| GPT-6.1 Sol | 70 | 70 | 0 | 0 | 0 | 1.000 |
| Gemini 3.8 Flash | 70 | 70 | 0 | 0 | 0 | 1.000 |
| Qwen3.8 Max | 70 | 69 | 0 | 1 | 0 | 1.000 |

## Paired Arabic vs English per repetition and by majority over repetitions (exact McNemar)

| Model | rep | pairs | only EN correct | only AR correct | p |
|---|---|---|---|---|---|
| Claude Sonnet 5.5 | 1 | 70 | 0 | 0 | 1.000 |
| Claude Sonnet 5.5 | 2 | 70 | 0 | 0 | 1.000 |
| Claude Sonnet 5.5 | 3 | 70 | 0 | 0 | 1.000 |
| Claude Sonnet 5.5 | majority | 70 | 0 | 0 | 1.000 |
| DeepSeek V4.1 Flash | 1 | 70 | 0 | 1 | 1.000 |
| DeepSeek V4.1 Flash | 2 | 70 | 0 | 1 | 1.000 |
| DeepSeek V4.1 Flash | 3 | 70 | 0 | 1 | 1.000 |
| DeepSeek V4.1 Flash | majority | 70 | 0 | 1 | 1.000 |
| GPT-6 Luna | 1 | 70 | 0 | 0 | 1.000 |
| GPT-6 Luna | 2 | 70 | 1 | 0 | 1.000 |
| GPT-6 Luna | 3 | 70 | 1 | 0 | 1.000 |
| GPT-6 Luna | majority | 70 | 1 | 0 | 1.000 |
| GPT-6.1 Sol | 1 | 70 | 0 | 0 | 1.000 |
| GPT-6.1 Sol | 2 | 70 | 0 | 0 | 1.000 |
| GPT-6.1 Sol | 3 | 70 | 0 | 0 | 1.000 |
| GPT-6.1 Sol | majority | 70 | 0 | 0 | 1.000 |
| Gemini 3.8 Flash | 1 | 70 | 0 | 0 | 1.000 |
| Gemini 3.8 Flash | 2 | 67 | 2 | 2 | 1.000 |
| Gemini 3.8 Flash | 3 | 70 | 2 | 0 | 0.500 |
| Gemini 3.8 Flash | majority | 70 | 1 | 0 | 1.000 |
| Qwen3.8 Max | 1 | 70 | 0 | 1 | 1.000 |
| Qwen3.8 Max | 2 | 70 | 1 | 1 | 1.000 |
| Qwen3.8 Max | 3 | 70 | 0 | 2 | 0.500 |
| Qwen3.8 Max | majority | 70 | 0 | 0 | 1.000 |

## Exact-match % by language

| Lang | Claude Sonnet 5.5 | DeepSeek V4.1 Flash | GPT-6 Luna | GPT-6.1 Sol | Gemini 3.8 Flash | Qwen3.8 Max |
|---|---|---|---|---|---|---|
| ar | 100.0 | 100.0 | 99.0 | 100.0 | 97.1 | 99.5 |
| en | 100.0 | 98.6 | 100.0 | 100.0 | 98.1 | 98.1 |
