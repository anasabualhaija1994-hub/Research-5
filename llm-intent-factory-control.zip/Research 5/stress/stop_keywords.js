// Deterministic stop detection (runs before the LLM). Over-triggering is acceptable: a stop is always safe.
function isStopCommand(text) {
  const t = String(text || '').toLowerCase()
    .replace(/[ً-ْـ]/g, '')          // Arabic diacritics and tatweel
    .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي');
  if (/\b(stop|halt|abort|cancel|freeze|e-?stop|emergency)\b/.test(t)) return true;
  const tokens = t.split(/[\s,.;:!?؟،؛()"'«»\-]+/).filter(Boolean);
  const exact = new Set(['قف', 'وقف', 'الغ', 'الغي', 'اوقف', 'توقف', 'ايقاف', 'الغاء', 'طوارئ']);
  const prefixes = ['اوقف', 'توقف', 'ايقاف', 'الغاء', 'وقفوا', 'وقف'];
  return tokens.some(w => exact.has(w) || exact.has(w.replace(/^[وف]/, '')) || prefixes.some(p => w.startsWith(p)));
}
module.exports = { isStopCommand };
