#!/usr/bin/env python3
"""
Tell the stations that the line was cleared BY HAND:
  HBW     -> all 9 boxes are in their rack slots   (L * R)
  Grabber -> the vacuum cup is empty               (L E)
Only run it after you physically checked: boxes in the rack, conveyor empty, nothing on the cup.
    python reset_state.py [--broker 192.168.0.249]
"""
import argparse
import json
import time

import paho.mqtt.client as mqtt

ap = argparse.ArgumentParser()
ap.add_argument("--broker", default="192.168.0.249")
ap.add_argument("--port", type=int, default=1883)
a = ap.parse_args()

replies = {}


def on_message(c, u, m):
    try:
        ev = json.loads(m.payload)
    except Exception:
        return
    st = m.topic.split("/")[1]
    # the station answers L with a status line (event topic) or a rejected line
    if st in replies and replies[st] is None and ev.get("event") in ("status", "rejected"):
        replies[st] = ev


cl = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"reset-{int(time.time())}")
cl.on_message = on_message
cl.connect(a.broker, a.port)
cl.subscribe([("factory/hbw/event", 1), ("factory/grabber/event", 1)])
cl.loop_start()
time.sleep(0.5)
t = int(time.time())
replies.update({"hbw": None, "grabber": None})
cl.publish("factory/hbw/cmd", json.dumps({"cmd": "L", "all": True, "loc": "R", "command_id": f"reset-h-{t}"}), qos=1)
cl.publish("factory/grabber/cmd", json.dumps({"cmd": "L", "loc": "E", "command_id": f"reset-g-{t}"}), qos=1)
end = time.time() + 5
while time.time() < end and any(v is None for v in replies.values()):
    time.sleep(0.1)
cl.loop_stop()

ok = True
h, g = replies["hbw"], replies["grabber"]
if h and h.get("event") == "status" and h.get("boxes") == "RRRRRRRRR":
    print("HBW     OK  boxes=RRRRRRRRR")
else:
    ok = False
    print(f"HBW     FAILED {h or 'no reply'}  (busy? box still on the conveyor -> SENSOR_MISMATCH)")
if g and g.get("event") == "status" and g.get("hold") == "empty":
    print("Grabber OK  hold=empty")
else:
    ok = False
    print(f"Grabber FAILED {g or 'no reply'}  (busy?)")
print("-> ready, now send 'home' (or press Enter in the experiment script)" if ok else "-> fix the line and run again")
