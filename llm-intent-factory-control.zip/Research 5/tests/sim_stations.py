"""Four simulated stations over a REAL MQTT broker (time-scaled), for testing physical_experiments.py."""
import json, sys, threading, time
import paho.mqtt.client as mqtt

S = float(sys.argv[1]) if len(sys.argv) > 1 else 0.05
cl = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="sim-stations")


def emit(st, ev):
    cl.publish(f"factory/{st}/event", json.dumps(ev), qos=1)


def sleep(x, st=None):
    end = time.time() + x * S
    while time.time() < end:
        if st is not None and st.abort:
            raise InterruptedError
        time.sleep(0.005)


class St:
    def __init__(self, name):
        self.name, self.busy, self.abort, self.cid, self.homed = name, False, False, None, True

    def start(self, k, cid, fn, **f):
        if self.busy:
            return emit(self.name, {"event": "rejected", "cmd": k, "code": "BUSY", "command_id": cid})
        self.busy, self.abort, self.cid = True, False, cid
        emit(self.name, {"event": "started", "cmd": k, "command_id": cid, **f})

        def run():
            try:
                fn()
                emit(self.name, {"event": "done", "cmd": k, "ms": 1, "command_id": cid, **f})
            except InterruptedError:
                pass
            finally:
                self.busy, self.cid = False, None
        threading.Thread(target=run, daemon=True).start()

    def fault(self, code):
        if self.busy:
            cid = self.cid
            self.abort = True
            emit(self.name, {"event": "fault", "code": code, "step": "sim", "phase": "-", "command_id": cid})


hbw, grab, oven, sorter = St("hbw"), St("grabber"), St("oven"), St("colorsorter")
hbw.boxes, hbw.outside = ["R"] * 9, False
grab.hold = "empty"
oven.piece_in = threading.Event()
sorter.arrival = threading.Event()
ST = {"hbw": hbw, "grabber": grab, "oven": oven, "colorsorter": sorter}


def on_cmd(st, c):
    k, cid, slot = c["cmd"], c.get("command_id"), c.get("slot")
    o = ST[st]
    if k == "S":
        o.abort = True
        return
    if k == "H":
        def H():
            sleep(10, o)
            if st == "grabber": grab.hold = "empty"
            if st == "hbw": hbw.outside = False; hbw.boxes[:] = ["R"] * 9
            if st == "oven": oven.piece_in.clear(); sorter.arrival.clear()
        return o.start("H", cid, H)
    if st == "hbw":
        def R():
            sleep(29, o); hbw.boxes[slot - 1] = "C"; hbw.outside = True
            emit("hbw", {"event": "progress", "state": "box_outside", "slot": slot})
        def T():
            sleep(26, o); hbw.boxes[slot - 1] = "R"
        return o.start(k, cid, R if k == "R" else T, slot=slot)
    if st == "grabber":
        def P():
            sleep(14, o); grab.hold = "full"; hbw.outside = False
        def O():
            sleep(11, o); oven.piece_in.set(); sleep(12 if k == "O" else 17, o); grab.hold = "empty"
        return o.start(k, cid, P if k == "P" else O)
    if st == "oven":
        def C():
            while not oven.piece_in.is_set():
                sleep(0.2, o)
            sleep(39, o); oven.piece_in.clear()
            emit("oven", {"event": "phase", "phase": "cutting"})
            sleep(13, o)
            threading.Timer(5 * S, sorter.arrival.set).start()
        return o.start(k, cid, C)
    if st == "colorsorter":
        def C():
            while not sorter.arrival.is_set():
                sleep(0.2, o)
            sleep(4, o); emit("colorsorter", {"event": "color", "color": "blue", "voltage": 1.78})
            sleep(4, o); sorter.arrival.clear()
        return o.start(k, cid, C)


def on_message(c, u, m):
    if m.topic == "sim/fault":
        ST[m.payload.decode()].fault("SIM_VACUUM")
        return
    st = m.topic.split("/")[1]
    threading.Thread(target=on_cmd, args=(st, json.loads(m.payload)), daemon=True).start()


cl.on_message = on_message
cl.on_connect = lambda c, u, f, rc, p=None: (c.subscribe([(f"factory/{s}/cmd", 1) for s in ST] + [("sim/fault", 1)]),
                                              [c.publish(f"factory/{s}/lwt", "online", qos=1, retain=True) for s in ST])
cl.connect("127.0.0.1", 1883)
cl.loop_start()
while True:
    for n, o in ST.items():
        s = {"event": "status", "busy": o.busy, "homed": o.homed}
        if n == "hbw": s["boxes"] = "".join(hbw.boxes)
        if n == "grabber": s["hold"] = grab.hold
        cl.publish(f"factory/{n}/status", json.dumps(s), qos=0)
    time.sleep(float(__import__("os").environ.get("HB","0.3")))
