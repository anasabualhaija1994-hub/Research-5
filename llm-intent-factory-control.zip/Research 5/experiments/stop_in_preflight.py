#!/usr/bin/env python3
"""
Physical check 1 (PROTOCOL.md section 5): STOP during the preflight.

The preflight waits for a fresh heartbeat from every station (heartbeats every 5 s). This script waits
for a heartbeat round, sends `run`, and sends `stop` DELAY seconds later from the same MQTT client, so the
stop always arrives after the run and before the next heartbeat round, i.e. inside the preflight.

  python stop_in_preflight.py            # slot 1, stop 1.0 s after the run
  python stop_in_preflight.py 1 1.5      # slot, delay

PASS = job_rejected with reason "stopped", no job_accepted, no station motion command.
"""
import json
import os
import sys
import threading
import time

import paho.mqtt.client as mqtt

BROKER_HOST = "192.168.0.249"
BROKER_PORT = 1883
T_ORC = "factory/orchestrator"
STATIONS = ("hbw", "grabber", "oven", "colorsorter")

slot = int(sys.argv[1]) if len(sys.argv) > 1 else 1
delay = float(sys.argv[2]) if len(sys.argv) > 2 else 1.0
tag = time.time_ns()
run_id, stop_id = f"pfstop-run-{tag}", f"pfstop-stop-{tag}"

beat = threading.Event()
done = threading.Event()
events, motion = [], []
t_run = [None]

try:
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"pfstop-{os.getpid()}-{tag}")
except AttributeError:
    c = mqtt.Client(client_id=f"pfstop-{os.getpid()}-{tag}")


def on_connect(cl, u, f, rc, p=None):
    cl.subscribe([(f"{T_ORC}/event", 1), ("factory/hbw/status", 0)] +
                 [(f"factory/{s}/cmd", 1) for s in STATIONS])


def on_message(cl, u, msg):
    t = time.time()
    if msg.topic == "factory/hbw/status":
        beat.set()
        return
    txt = msg.payload.decode("utf-8", "replace")
    try:
        ev = json.loads(txt)
    except ValueError:
        return
    rel = f"+{t - t_run[0]:.3f}s" if t_run[0] else ""
    if msg.topic.endswith("/cmd"):
        if t_run[0] and ev.get("cmd") != "S":
            motion.append((msg.topic, ev.get("cmd"), rel))
            print("!! MOTION", msg.topic, ev.get("cmd"), rel)
        return
    if ev.get("job_id") in (run_id, stop_id):
        events.append(ev)
        print("<<", rel, json.dumps(ev, ensure_ascii=False))
        if ev.get("job_id") == run_id and ev.get("event") in ("job_rejected", "job_failed", "job_done"):
            done.set()


c.on_connect = on_connect
c.on_message = on_message
c.connect(BROKER_HOST, BROKER_PORT, 30)
c.loop_start()

print("waiting for a heartbeat round ...")
beat.clear()
if not beat.wait(8):
    print("no HBW heartbeat in 8 s - is the factory on?")
    sys.exit(2)
time.sleep(0.3)                                   # let the other stations' heartbeats of this round arrive

t_run[0] = time.time()
c.publish(f"{T_ORC}/cmd", json.dumps({"cmd": "run", "job_id": run_id, "slots": [slot]}), qos=1)
print(">> run", run_id, "slots", [slot])
time.sleep(delay)
c.publish(f"{T_ORC}/cmd", json.dumps({"cmd": "stop", "job_id": stop_id}), qos=1)
print(f">> stop {stop_id} (+{time.time() - t_run[0]:.3f}s)")

done.wait(15)
time.sleep(1.0)                                   # catch any late command
c.loop_stop()

kinds = {(e.get("job_id"), e.get("event")): e for e in events}
rej = kinds.get((run_id, "job_rejected"))
accepted = (run_id, "job_accepted") in kinds
ok = rej is not None and rej.get("reason") == "stopped" and not accepted and not motion
print()
print("RESULT:", "PASS" if ok else "FAIL",
      f"| rejected={rej.get('reason') if rej else None} accepted={accepted} motion_cmds={len(motion)}")
if rej and rej.get("reason") == "preflight":
    print("   (rejected by the preflight before the stop - fix the plant state, e.g. run reset_state.py)")
sys.exit(0 if ok else 1)
