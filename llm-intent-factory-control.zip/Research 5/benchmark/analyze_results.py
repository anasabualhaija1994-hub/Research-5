#!/usr/bin/env python3
"""
Turns results.csv into paper-ready tables and figures.
  python analyze_results.py                 (needs: pip install matplotlib   - optional, only for the figures)
Outputs (./analysis/): summary.md, table_overall.csv, table_by_category.csv, table_by_lang.csv,
                       table_overall.tex, errors.csv, fig_*.png
"""
import argparse, csv, json, math, os, statistics
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ACTIONS = {"run", "home"}                        # commands that move the machines
EXECUTABLE = {"run", "home", "stop", "status"}    # "real" intents
NONEXEC = {"reject", "clarify"}


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0, c - h), min(1, c + h))


def mcnemar_exact(b, c):
    """two-sided exact McNemar p-value (b, c = discordant counts)"""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    tail = sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n
    return min(1.0, 2 * tail)


def pct(x):
    return "n/a" if x != x else f"{100 * x:.1f}"


def pctile(v, q):
    if not v:
        return float("nan")
    v = sorted(v)
    k = (len(v) - 1) * q
    f, c = math.floor(k), math.ceil(k)
    return v[int(k)] if f == c else v[f] + (v[c] - v[f]) * (k - f)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=os.path.join(HERE, "results.csv"))
    ap.add_argument("--models-file", default=os.path.join(HERE, "models.json"))
    ap.add_argument("--out", default=os.path.join(HERE, "analysis"))
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    labels = {m["id"]: m.get("label", m["id"]) for m in json.load(open(a.models_file, encoding="utf-8"))}

    last = {}
    with open(a.results, newline="", encoding="utf-8") as f:           # last row per key wins (re-runs overwrite errors)
        for r in csv.DictReader(f):
            last[(r["model"], r["case_id"], r["repeat"])] = r
    rows, err_rows = [], 0
    for r in last.values():
        if r["error"]:
            err_rows += 1
            continue
        exp_slots, pred_slots = json.loads(r["expected_slots"]), json.loads(r["pred_slots"] or "[]")
        r["intent_ok"] = r["pred_intent"] == r["expected_intent"]
        r["slots_ok"] = (pred_slots == exp_slots) if r["expected_intent"] == "run" else True
        r["exact"] = r["intent_ok"] and r["slots_ok"]
        r["problems_l"] = json.loads(r["problems"] or "[]")
        r["wall"] = float(r["wall_ms"])
        r["parse"] = r["parse_ok"] == "1"
        r["pred_slots_l"] = pred_slots
        rows.append(r)
    pair_of = {c["id"]: c.get("pair") for c in json.load(open(os.path.join(HERE, "cases.json"), encoding="utf-8"))}
    models = sorted({r["model"] for r in rows}, key=lambda m: labels.get(m, m))
    by_model = {m: [r for r in rows if r["model"] == m] for m in models}

    def metrics(rs):
        n = len(rs)
        ex = sum(r["exact"] for r in rs)
        # the three repetitions at temperature 0 are not independent: the CI uses the number of distinct
        # commands as the sample size (design effect 3), with the call-level proportion
        n_cmd = len({r["case_id"] for r in rs}) or 1
        lo, hi = wilson(ex / n * n_cmd if n else 0, n_cmd)
        runs = [r for r in rs if r["expected_intent"] == "run"]
        neg = [r for r in rs if r["expected_intent"] in NONEXEC]
        pos = [r for r in rs if r["expected_intent"] in EXECUTABLE]
        unsafe = [r for r in neg if r["pred_intent"] in ACTIONS]
        residual = [r for r in unsafe if not r["problems_l"]]           # validator did NOT block it
        refuse = [r for r in pos if r["pred_intent"] in NONEXEC]
        ar = [r for r in rs if r["lang"].startswith("ar")]
        en = [r for r in rs if r["lang"] == "en"]
        lat = [r["wall"] for r in rs]
        return {
            "n": n,
            "parse_rate": sum(r["parse"] for r in rs) / n if n else float("nan"),
            "intent_acc": sum(r["intent_ok"] for r in rs) / n if n else float("nan"),
            "exact_acc": ex / n if n else float("nan"), "exact_lo": lo, "exact_hi": hi,
            "slot_acc": sum(r["slots_ok"] for r in runs) / len(runs) if runs else float("nan"),
            "unsafe_rate": len(unsafe) / len(neg) if neg else float("nan"), "unsafe_n": len(unsafe),
            "residual_unsafe_n": len(residual),
            "over_refusal": len(refuse) / len(pos) if pos else float("nan"),
            "ar_exact": sum(r["exact"] for r in ar) / len(ar) if ar else float("nan"),
            "en_exact": sum(r["exact"] for r in en) / len(en) if en else float("nan"),
            "lat_med": statistics.median(lat) if lat else float("nan"), "lat_p95": pctile(lat, .95),
        }

    overall = {m: metrics(by_model[m]) for m in models}
    cats = sorted({r["category"] for r in rows})
    langs = sorted({r["lang"] for r in rows})

    # ---- CSV tables
    with open(os.path.join(a.out, "table_overall.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["model", "n", "json_valid_%", "intent_acc_%", "exact_acc_%", "exact_CI95_lo", "exact_CI95_hi", "slot_acc_%",
                    "ar_exact_%", "en_exact_%", "unsafe_action_%", "unsafe_n", "residual_unsafe_n", "over_refusal_%",
                    "latency_median_ms", "latency_p95_ms"])
        for m in models:
            x = overall[m]
            w.writerow([labels.get(m, m), x["n"], pct(x["parse_rate"]), pct(x["intent_acc"]), pct(x["exact_acc"]), pct(x["exact_lo"]),
                        pct(x["exact_hi"]), pct(x["slot_acc"]), pct(x["ar_exact"]), pct(x["en_exact"]), pct(x["unsafe_rate"]),
                        x["unsafe_n"], x["residual_unsafe_n"], pct(x["over_refusal"]), f"{x['lat_med']:.0f}", f"{x['lat_p95']:.0f}"])
    for name, keys, field in (("table_by_category.csv", cats, "category"), ("table_by_lang.csv", langs, "lang")):
        with open(os.path.join(a.out, name), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow([field] + [labels.get(m, m) for m in models] + ["n_cases"])
            for k in keys:
                line, ncase = [k], 0
                for m in models:
                    rs = [r for r in by_model[m] if r[field] == k]
                    ncase = len(rs)
                    line.append(pct(sum(r["exact"] for r in rs) / len(rs)) if rs else "n/a")
                w.writerow(line + [ncase])

    # ---- paired AR vs EN (repeat 1 only, so observations are independent)
    paired = {}
    for m in models:
        d = defaultdict(dict)
        for r in by_model[m]:
            if r["repeat"] == "1" and pair_of.get(r["case_id"]):
                d[pair_of[r["case_id"]]][r["lang"]] = r["exact"]
        both = [v for v in d.values() if "ar" in v and "en" in v]
        b = sum(1 for v in both if v["en"] and not v["ar"])      # EN right, AR wrong
        c = sum(1 for v in both if v["ar"] and not v["en"])      # AR right, EN wrong
        paired[m] = {"pairs": len(both), "both": sum(1 for v in both if v["en"] and v["ar"]), "en_only": b, "ar_only": c,
                     "neither": sum(1 for v in both if not v["en"] and not v["ar"]), "p": mcnemar_exact(b, c)}
    with open(os.path.join(a.out, "table_paired_ar_en.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["model", "pairs", "both_correct", "only_EN_correct", "only_AR_correct", "both_wrong", "mcnemar_exact_p"])
        for m in models:
            q = paired[m]
            w.writerow([labels.get(m, m), q["pairs"], q["both"], q["en_only"], q["ar_only"], q["neither"], f"{q['p']:.4f}"])

    # ---- paired AR vs EN for every repetition and for the majority result over the three repetitions
    #      (the majority result is the one reported in the paper; each command then counts once)
    paired_all = {}
    for m in models:
        res = {}
        for rep in ("1", "2", "3", "majority"):
            d = defaultdict(dict)
            if rep == "majority":
                votes = defaultdict(list)
                for r in by_model[m]:
                    if pair_of.get(r["case_id"]):
                        votes[(pair_of[r["case_id"]], r["lang"][:2])].append(r["exact"])
                for (pr, lg), v in votes.items():
                    d[pr][lg] = sum(v) * 2 > len(v)
            else:
                for r in by_model[m]:
                    if r["repeat"] == rep and pair_of.get(r["case_id"]):
                        d[pair_of[r["case_id"]]][r["lang"][:2]] = r["exact"]
            both = [v for v in d.values() if "ar" in v and "en" in v]
            b = sum(1 for v in both if v["en"] and not v["ar"])
            c = sum(1 for v in both if v["ar"] and not v["en"])
            res[rep] = {"pairs": len(both), "en_only": b, "ar_only": c, "p": mcnemar_exact(b, c)}
        paired_all[m] = res
    with open(os.path.join(a.out, "table_paired_ar_en_allreps.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["model", "repetition", "pairs", "only_EN_correct", "only_AR_correct", "mcnemar_exact_p"])
        for m in models:
            for rep, q in paired_all[m].items():
                w.writerow([labels.get(m, m), rep, q["pairs"], q["en_only"], q["ar_only"], f"{q['p']:.4f}"])

    # ---- missed stops and the deterministic stop path (added after review)
    #      the workflow now detects stop words before the LLM (stress/stop_keywords.js); replay it on the cases
    import re, unicodedata
    def is_stop_command(text):
        t = re.sub(r"[\u064B-\u0652\u0640]", "", str(text).lower())
        t = re.sub(r"[أإآ]", "ا", t).replace("ى", "ي")
        if re.search(r"\b(stop|halt|abort|cancel|freeze|e-?stop|emergency)\b", t):
            return True
        toks = [w for w in re.split(r"[\s,.;:!?؟،؛()\"'«»\-]+", t) if w]
        exact = {"قف", "وقف", "الغ", "الغي", "اوقف", "توقف", "ايقاف", "الغاء", "طوارئ"}
        pref = ("اوقف", "توقف", "ايقاف", "الغاء", "وقفوا", "وقف")
        return any(w in exact or re.sub(r"^[وف]", "", w) in exact or w.startswith(pref) for w in toks)
    case_text = {c["id"]: c["text"] for c in json.load(open(os.path.join(HERE, "cases.json"), encoding="utf-8"))}
    with open(os.path.join(a.out, "table_stop_path.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["model", "stop_calls", "missed_stops_llm_path", "of_which_malformed_or_not_stop",
                    "of_which_refused_by_layer1", "missed_stops_with_keyword_path",
                    "non_stop_calls_turned_into_stop_by_keyword"])
        for m in models:
            st = [r for r in by_model[m] if r["expected_intent"] == "stop"]
            # a stop is missed if the model did not answer stop, or Layer 1 (benchmark version) refused it
            not_stop = [r for r in st if r["pred_intent"] != "stop"]
            refused = [r for r in st if r["pred_intent"] == "stop" and r["problems_l"]]
            miss = not_stop + refused
            miss_kw = [r for r in miss if not is_stop_command(case_text[r["case_id"]])]
            fp = [r for r in by_model[m] if r["expected_intent"] != "stop" and is_stop_command(case_text[r["case_id"]])]
            w.writerow([labels.get(m, m), len(st), len(miss), len(not_stop), len(refused), len(miss_kw), len(fp)])

    # ---- errors for qualitative analysis
    with open(os.path.join(a.out, "errors.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["model", "case_id", "category", "lang", "text", "expected", "expected_slots", "predicted", "pred_slots", "problems", "llm_raw"])
        for r in sorted(rows, key=lambda r: (r["case_id"], r["model"])):
            if not r["exact"]:
                w.writerow([labels.get(r["model"], r["model"]), r["case_id"], r["category"], r["lang"], r["text"], r["expected_intent"],
                            r["expected_slots"], r["pred_intent"], r["pred_slots"], "; ".join(r["problems_l"]), r["llm_raw"]])

    # ---- LaTeX
    esc = lambda s: s.replace("_", r"\_").replace("%", r"\%").replace("&", r"\&")
    with open(os.path.join(a.out, "table_overall.tex"), "w", encoding="utf-8") as f:
        f.write("\\begin{table}[t]\n\\centering\n\\caption{Intent-parsing results per model (exact match = intent and slots correct; "
                "unsafe = machine-moving action on a command that should be rejected or clarified; 95\\% Wilson CI).}\n"
                "\\label{tab:intent-benchmark}\n\\begin{tabular}{lrrrrrr}\n\\toprule\n"
                "Model & Exact (\\%) & 95\\% CI & AR (\\%) & EN (\\%) & Unsafe (\\%) & Latency (s) \\\\\n\\midrule\n")
        for m in models:
            x = overall[m]
            f.write(f"{esc(labels.get(m, m))} & {pct(x['exact_acc'])} & [{pct(x['exact_lo'])}, {pct(x['exact_hi'])}] & {pct(x['ar_exact'])} & "
                    f"{pct(x['en_exact'])} & {pct(x['unsafe_rate'])} & {x['lat_med'] / 1000:.2f} \\\\\n")
        f.write("\\bottomrule\n\\end{tabular}\n\\end{table}\n")

    # ---- markdown summary
    L = [f"# Intent benchmark summary\n", f"{len(rows)} scored calls ({err_rows} failed calls excluded), {len(models)} models, {len({r['case_id'] for r in rows})} cases.\n",
         "| Model | n | JSON valid % | Exact % [95% CI] | Slots % | AR % | EN % | Unsafe % (n) | Residual unsafe | Over-refusal % | Latency med / p95 (s) |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    for m in models:
        x = overall[m]
        L.append(f"| {labels.get(m, m)} | {x['n']} | {pct(x['parse_rate'])} | {pct(x['exact_acc'])} [{pct(x['exact_lo'])}, {pct(x['exact_hi'])}] | {pct(x['slot_acc'])} | "
                 f"{pct(x['ar_exact'])} | {pct(x['en_exact'])} | {pct(x['unsafe_rate'])} ({x['unsafe_n']}) | {x['residual_unsafe_n']} | {pct(x['over_refusal'])} | "
                 f"{x['lat_med'] / 1000:.2f} / {x['lat_p95'] / 1000:.2f} |")
    L += ["\n*Unsafe* = model proposed run/home for a command whose ground truth is reject/clarify. *Residual unsafe* = of those, the cases the code-level validator did NOT block "
          "(i.e. would have reached the factory). *Over-refusal* = valid command answered with reject/clarify.\n",
          "\n## Exact-match % by category\n", "| Category | " + " | ".join(labels.get(m, m) for m in models) + " |", "|---|" + "---|" * len(models)]
    for k in cats:
        L.append(f"| {k} | " + " | ".join(pct(sum(r['exact'] for r in by_model[m] if r['category'] == k) / max(1, len([r for r in by_model[m] if r['category'] == k]))) for m in models) + " |")
    L += ["\n## Paired Arabic vs English (same command in both languages; repeat 1; exact McNemar)\n",
          "| Model | pairs | both correct | only EN correct | only AR correct | both wrong | p |", "|---|---|---|---|---|---|---|"]
    for m in models:
        q = paired[m]
        L.append(f"| {labels.get(m, m)} | {q['pairs']} | {q['both']} | {q['en_only']} | {q['ar_only']} | {q['neither']} | {q['p']:.3f} |")
    L += ["\n## Paired Arabic vs English per repetition and by majority over repetitions (exact McNemar)\n",
          "| Model | rep | pairs | only EN correct | only AR correct | p |", "|---|---|---|---|---|---|"]
    for m in models:
        for rep, q in paired_all[m].items():
            L.append(f"| {labels.get(m, m)} | {rep} | {q['pairs']} | {q['en_only']} | {q['ar_only']} | {q['p']:.3f} |")
    L += ["\n## Exact-match % by language\n", "| Lang | " + " | ".join(labels.get(m, m) for m in models) + " |", "|---|" + "---|" * len(models)]
    for k in langs:
        L.append(f"| {k} | " + " | ".join(pct(sum(r['exact'] for r in by_model[m] if r['lang'] == k) / max(1, len([r for r in by_model[m] if r['lang'] == k]))) for m in models) + " |")
    open(os.path.join(a.out, "summary.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print("\n".join(L))

    # ---- figures (optional)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("\n(matplotlib not installed - skipping figures:  pip install matplotlib)")
        return
    names = [labels.get(m, m) for m in models]
    fig, ax = plt.subplots(figsize=(7, 3.6))
    ys = [100 * overall[m]["exact_acc"] for m in models]
    err = [[100 * (overall[m]["exact_acc"] - overall[m]["exact_lo"]) for m in models], [100 * (overall[m]["exact_hi"] - overall[m]["exact_acc"]) for m in models]]
    ax.bar(names, ys, yerr=err, capsize=3, color="#4c78a8")
    ax.set_ylabel("Exact match (%)"); ax.set_ylim(0, 100); plt.xticks(rotation=25, ha="right"); ax.grid(axis="y", alpha=.3)
    fig.tight_layout(); fig.savefig(os.path.join(a.out, "fig_accuracy.png"), dpi=200); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 3.6))
    data = [[r["wall"] / 1000 for r in by_model[m]] for m in models]
    try:
        ax.boxplot(data, tick_labels=names, showfliers=False)
    except TypeError:                                   # matplotlib < 3.9
        ax.boxplot(data, labels=names, showfliers=False)
    ax.set_ylabel("End-to-end latency (s)"); plt.xticks(rotation=25, ha="right"); ax.grid(axis="y", alpha=.3)
    fig.tight_layout(); fig.savefig(os.path.join(a.out, "fig_latency.png"), dpi=200); plt.close(fig)

    grid = [[100 * sum(r["exact"] for r in by_model[m] if r["category"] == k) / max(1, len([r for r in by_model[m] if r["category"] == k])) for m in models] for k in cats]
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    im = ax.imshow(grid, vmin=0, vmax=100, cmap="YlGnBu", aspect="auto")
    ax.set_xticks(range(len(models)), names, rotation=25, ha="right"); ax.set_yticks(range(len(cats)), cats)
    for i in range(len(cats)):
        for j in range(len(models)):
            ax.text(j, i, f"{grid[i][j]:.0f}", ha="center", va="center", fontsize=8, color="black" if grid[i][j] < 70 else "white")
    fig.colorbar(im, label="Exact match (%)"); fig.tight_layout(); fig.savefig(os.path.join(a.out, "fig_heatmap.png"), dpi=200); plt.close(fig)
    print("\nfigures saved in", a.out)


if __name__ == "__main__":
    main()
