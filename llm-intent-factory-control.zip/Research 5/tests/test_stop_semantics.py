"""Sends requests to the orchestrator, prints the resulting events and checks them (exit code 0 = PASS).
Used by run_scenario.sh."""
import json, time, sys, paho.mqtt.client as mqtt
ev=[]
c=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="tester")
def om(cl,u,m):
    if m.topic.endswith("/cmd") and "S" in m.payload.decode() and '"cmd": "S"' in m.payload.decode(): ev.append((time.time(),m.topic,"STOP")); return
    if m.topic=="factory/orchestrator/event":
        e=json.loads(m.payload); ev.append((time.time(),e.get("event"),e.get("job_id"),e.get("reason") or e.get("error") or ""))
    elif m.topic.endswith("/cmd"):
        ev.append((time.time(),m.topic,json.loads(m.payload).get("cmd")))
c.on_message=om; c.connect("127.0.0.1",1883); c.subscribe([("factory/orchestrator/event",1),("factory/+/cmd",1)]); c.loop_start()
time.sleep(1)
def req(d): c.publish("factory/orchestrator/cmd", json.dumps(d), qos=1)
t0=time.time()
mode=sys.argv[1]
if mode=="stop_in_preflight_run":
    req({"cmd":"run","slots":[1],"job_id":"T-run"}); time.sleep(0.8); req({"cmd":"stop","job_id":"T-stop"}); time.sleep(12)
elif mode=="stop_in_preflight_home":
    req({"cmd":"home","job_id":"T-home"}); time.sleep(0.8); req({"cmd":"stop","job_id":"T-stop"}); time.sleep(12)
elif mode=="lwt_in_home":
    req({"cmd":"home","job_id":"T-home2"}); time.sleep(float(sys.argv[2]) if len(sys.argv)>2 else 3)
    c.publish("factory/hbw/lwt","offline",qos=1,retain=True); time.sleep(4)
    c.publish("factory/hbw/lwt","online",qos=1,retain=True); time.sleep(1)
if mode=="normal":
    req({"cmd":"run","slots":[1,2,3],"job_id":"T-norm"}); time.sleep(14)
for e in ev: print(round(e[0]-t0,3),*e[1:])

evs = [e for e in ev if len(e) >= 4]
def has(name, jid, text=""):
    return any(e[1] == name and e[2] == jid and text in str(e[3]) for e in evs)
motion = [e for e in ev if len(e) == 3 and e[2] not in ("STOP", "S") and not e[1].startswith("factory/orchestrator")]
if mode == "stop_in_preflight_run":
    ok = has("job_rejected", "T-run", "stopped") and not has("job_accepted", "T-run") and not motion
elif mode == "stop_in_preflight_home":
    ok = (has("home_failed", "T-home", "stop") or has("job_rejected", "T-home", "stopped")) \
         and not has("job_accepted", "T-home") and not motion
elif mode == "lwt_in_home":
    ok = has("home_failed", "T-home2", "offline")
else:
    ok = has("job_accepted", "T-norm") and not has("job_failed", "T-norm")
print("RESULT:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
