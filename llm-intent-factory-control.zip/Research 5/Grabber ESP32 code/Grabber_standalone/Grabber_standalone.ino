/*
 * ============================================================================
 *  Grabber - STANDALONE ESP32 firmware
 * ============================================================================
 *  Upload and the Grabber runs by itself, in the same order the Python sender
 *  used to send to the Grabber station. No PC, no bridge, no serial, no logging.
 *
 *    1) Initial Homing
 *    2) 9 cycles, one per HBW position (1,4,7,2,5,8,3,6,9):
 *         a) wait for the HBW to bring a piece            (see HBW_RETRIEVE_WAIT_MS)
 *         b) PICK from HBW
 *         c) PUT to Oven  (every 3rd cycle: PUT + extra rotate homing)
 *         d) wait for that PUT to actually finish before starting the next PICK
 *            (in the Python sender the PUT runs in parallel with HBW's RETURN;
 *             here it's simply done in-line, one motion after another)
 * ============================================================================
 */
#include <Arduino.h>

// ==========================================
// Settings
// ==========================================
// Wait after power-up/reset before the first movement
const unsigned long START_DELAY_MS = 3000;

// Python: time.sleep(1) after the Initial Homing
const unsigned long HOMING_SETTLE_MS = 1000;

// The Grabber cannot "see" that the HBW placed a piece on the conveyor, so before
// each PICK it waits a fixed time (= duration of "POS X Retrieve" + "POS X Return"
// up to the point the piece is ready, in the Python version).
// >>> Set it a bit ABOVE the "POS X Retrieve" Total_ms values in timing_log.csv <<<
const unsigned long HBW_RETRIEVE_WAIT_MS = 20000;

// ==========================================
// Pins
// ==========================================
#define REF_SWITCH_VERTICAL_AXIS       36
#define REF_SWITCH_HORIZONTAL_AXIS     39
#define REF_SWITCH_ROTATE              34

#define ENC_VERT_AXIS_IMPULSE_1        35
#define ENC_VERT_AXIS_IMPULSE_2        32
#define ENC_HORZ_AXIS_IMPULSE_1        33
#define ENC_HORZ_AXIS_IMPULSE_2        25
#define ENC_ROTATE_IMPULSE_1           26
#define ENC_ROTATE_IMPULSE_2           27

#define MOTOR_VERT_AXIS_UP             16
#define MOTOR_VERT_AXIS_DOWN           17
#define MOTOR_HORZ_AXIS_BACKWARD       4
#define MOTOR_HORZ_AXIS_FORWARD        18
#define MOTOR_ROTATE_CLOCKWISE         19
#define MOTOR_ROTATE_COUNTERCLOCKWISE  21
#define COMPRESSOR                     22
#define VALVE_VACUUM                   23

volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int rotatePulseCount     = 0;

volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;
volatile int8_t rotateMoveDirection     = 0;

const int8_t encoder_table[16] = {
   0, -1,  1,  0,
   1,  0,  0, -1,
  -1,  0,  0,  1,
   0,  1, -1,  0
};

// ==========================================
// Encoder interrupts (unchanged)
// ==========================================
void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 1) verticalPulseCount++;
  else if (verticalMoveDirection == -1) verticalPulseCount--;
}

void IRAM_ATTR handleRotateEncoder() {
  static uint8_t lastState = 0;
  if (rotateMoveDirection == 0) return;
  uint8_t cur = (digitalRead(ENC_ROTATE_IMPULSE_1) << 1) | digitalRead(ENC_ROTATE_IMPULSE_2);
  rotatePulseCount += encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

void IRAM_ATTR handleHorizontalEncoder() {
  static uint8_t lastState = 0;
  if (horizontalMoveDirection == 0) return;
  uint8_t cur = (digitalRead(ENC_HORZ_AXIS_IMPULSE_1) << 1) | digitalRead(ENC_HORZ_AXIS_IMPULSE_2);
  horizontalPulseCount -= encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

// ==========================================
// Basic movements (each = one command group from the Python blocks)
// ==========================================
#define WAIT_WHILE(cond) while (cond) { delay(1); }

// --- Homing (to the reference switches) ---
void vertAxisHomeUp() {
  digitalWrite(MOTOR_VERT_AXIS_UP, HIGH); verticalMoveDirection = 1;
  WAIT_WHILE(digitalRead(REF_SWITCH_VERTICAL_AXIS) == LOW);
  digitalWrite(MOTOR_VERT_AXIS_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);
}

void horzAxisHomeBack() {
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, HIGH); horizontalMoveDirection = 1;
  WAIT_WHILE(digitalRead(REF_SWITCH_HORIZONTAL_AXIS) == LOW);
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);
}

void rotateHomeCW() {
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH); rotateMoveDirection = 1;
  WAIT_WHILE(digitalRead(REF_SWITCH_ROTATE) == LOW);
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW); rotatePulseCount = 0; rotateMoveDirection = 0; delay(10);
}

// --- Moves to an encoder target ---
void rotateCCWTo(int target) {
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, HIGH); rotateMoveDirection = -1;
  WAIT_WHILE(rotatePulseCount > target);
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, LOW); rotateMoveDirection = 0; delay(10);
}

void rotateCWTo(int target) {
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH); rotateMoveDirection = 1;
  WAIT_WHILE(rotatePulseCount < target);
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW); rotateMoveDirection = 0; delay(10);
}

void horzFwdTo(int target) {
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD, HIGH); horizontalMoveDirection = -1;
  WAIT_WHILE(horizontalPulseCount > target);
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD, LOW); horizontalMoveDirection = 0; delay(10);
}

void vertDownTo(int target) {
  digitalWrite(MOTOR_VERT_AXIS_DOWN, HIGH); verticalMoveDirection = -1;
  WAIT_WHILE(verticalPulseCount > target);
  digitalWrite(MOTOR_VERT_AXIS_DOWN, LOW); verticalMoveDirection = 0; delay(10);
}

// --- Vacuum / gripper ---
void vacuumOn() {
  digitalWrite(COMPRESSOR, HIGH);
  digitalWrite(VALVE_VACUUM, HIGH);
  delay(100);
}

void vacuumOff() {
  digitalWrite(COMPRESSOR, LOW);
  digitalWrite(VALVE_VACUUM, LOW);
  delay(100);
}

// ==========================================
// Grabber homing (Initial Homing)
// ==========================================
void initialHoming() {
  vertAxisHomeUp();
  horzAxisHomeBack();
  rotateHomeCW();
}

// ==========================================
// Pick from HBW  (Phase 1)
// ==========================================
void pickFromHBW() {
  rotateCCWTo(-5380);
  horzFwdTo(-680);
  vertDownTo(-1000);
  vacuumOn();
  vertAxisHomeUp();
  horzAxisHomeBack();
}

// ==========================================
// Put to Oven  (Phase 2) - normal / with rotate homing every 3rd cycle
// ==========================================
void putToOven() {
  rotateCWTo(-3560);
  horzFwdTo(-3380);
  vertDownTo(-3000);
  vacuumOff();
  vertAxisHomeUp();
  horzAxisHomeBack();
}

void putToOvenWithRotateHoming() {
  rotateCWTo(-3560);
  horzFwdTo(-3380);
  vertDownTo(-3000);
  vacuumOff();
  vertAxisHomeUp();
  horzAxisHomeBack();
  rotateHomeCW();
}

// ==========================================
// Sequence (same order as the Python main)
// ==========================================
void runSequence() {
  initialHoming();
  delay(HOMING_SETTLE_MS);

  for (int cycle = 1; cycle <= 9; cycle++) {
    delay(HBW_RETRIEVE_WAIT_MS);   // wait for the HBW to bring the piece to the conveyor
    pickFromHBW();

    if (cycle % 3 == 0) {
      putToOvenWithRotateHoming();
    } else {
      putToOven();
    }
  }
}

// ==========================================
// Arduino entry points
// ==========================================
void setup() {
  pinMode(REF_SWITCH_VERTICAL_AXIS,   INPUT_PULLUP);
  pinMode(REF_SWITCH_HORIZONTAL_AXIS, INPUT_PULLUP);
  pinMode(REF_SWITCH_ROTATE,          INPUT_PULLUP);

  pinMode(ENC_VERT_AXIS_IMPULSE_1, INPUT);
  pinMode(ENC_VERT_AXIS_IMPULSE_2, INPUT);
  pinMode(ENC_HORZ_AXIS_IMPULSE_1, INPUT);
  pinMode(ENC_HORZ_AXIS_IMPULSE_2, INPUT);
  pinMode(ENC_ROTATE_IMPULSE_1,    INPUT);
  pinMode(ENC_ROTATE_IMPULSE_2,    INPUT);

  pinMode(MOTOR_VERT_AXIS_UP,              OUTPUT);
  pinMode(MOTOR_VERT_AXIS_DOWN,            OUTPUT);
  pinMode(MOTOR_HORZ_AXIS_BACKWARD,        OUTPUT);
  pinMode(MOTOR_HORZ_AXIS_FORWARD,         OUTPUT);
  pinMode(MOTOR_ROTATE_CLOCKWISE,          OUTPUT);
  pinMode(MOTOR_ROTATE_COUNTERCLOCKWISE,   OUTPUT);
  pinMode(COMPRESSOR,                      OUTPUT);
  pinMode(VALVE_VACUUM,                    OUTPUT);

  digitalWrite(MOTOR_VERT_AXIS_UP,            LOW);
  digitalWrite(MOTOR_VERT_AXIS_DOWN,          LOW);
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD,      LOW);
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD,       LOW);
  digitalWrite(MOTOR_ROTATE_CLOCKWISE,        LOW);
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, LOW);
  digitalWrite(COMPRESSOR,                    LOW);
  digitalWrite(VALVE_VACUUM,                  LOW);

  attachInterrupt(digitalPinToInterrupt(ENC_VERT_AXIS_IMPULSE_1), handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_VERT_AXIS_IMPULSE_2), handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_ROTATE_IMPULSE_1),    handleRotateEncoder,     CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_ROTATE_IMPULSE_2),    handleRotateEncoder,     CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_HORZ_AXIS_IMPULSE_1), handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_HORZ_AXIS_IMPULSE_2), handleHorizontalEncoder, CHANGE);
}

bool sequenceDone = false;

void loop() {
  if (!sequenceDone) {
    delay(START_DELAY_MS);   // safety delay before the first movement
    runSequence();           // runs once
    sequenceDone = true;
  }
}
