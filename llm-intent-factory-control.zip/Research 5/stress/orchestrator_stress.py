#!/usr/bin/env python3
"""
Layer-2 stress test: feeds raw requests DIRECTLY to the orchestrator service
(bypassing n8n and the LLM), with simulated station states, and checks that
no unsafe request is accepted. No broker, no hardware: MQTT publish is captured.

  python orchestrator_stress.py [path/to/orchestrator_service.py] [out_prefix]
"""
import csv, importlib.util, json, sys, time

path = sys.argv[1] if len(sys.argv) > 1 else "../orchestrator_service.py"
out = sys.argv[2] if len(sys.argv) > 2 else "layer2"
spec = importlib.util.spec_from_file_location("orc", path)
orc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(orc)

# ---- sandbox the service: capture everything it would send ----
published = []
orc.client.publish = lambda topic, payload=None, qos=0, retain=False: published.append((topic, payload))
orc.log = lambda msg: None
orc.csv_append = lambda *a, **k: None
orc.PREFLIGHT_WAIT_S = 0.3
noop = lambda job: None
orc.hbw_worker = orc.grabber_worker = orc.oven_worker = orc.sorter_worker = noop
orc.wait_done = lambda job, cmd, timeout=None: None

STATIONS = orc.STATIONS
GOOD = {
    "hbw": {"busy": False, "homed": True, "boxes": "RRRRRRRRR"},
    "grabber": {"busy": False, "homed": True, "hold": "empty"},
    "oven": {"busy": False, "homed": True},
    "colorsorter": {"busy": False},
}


def set_world(mod=None, offline=(), stale=(), orc_state="idle"):
    world = json.loads(json.dumps(GOOD))
    for st, patch in (mod or {}).items():
        if patch is None:
            world.pop(st, None)
        else:
            world[st].update(patch)
    orc.status_live.clear(); orc.status.clear(); orc.status_at.clear(); orc.lwt.clear()
    future = time.time() + 3600
    for st in STATIONS:
        orc.lwt[st] = "offline" if st in offline else "online"
        if st in world:
            orc.status_live[st] = world[st]
            orc.status_at[st] = 0 if st in stale else future
        orc.last_done[st] = 0.0
    orc.state.update(state=orc_state, job_id="other-job" if orc_state != "idle" else None)
    orc.current["job"] = None


def motion_cmds():
    m = []
    for topic, payload in published:
        if topic.startswith("factory/") and topic.endswith("/cmd") and not topic.startswith("factory/orchestrator"):
            try:
                c = json.loads(payload).get("cmd")
            except Exception:
                c = "?"
            if c != "S":
                m.append(f"{topic.split('/')[1]}:{c}")
    return m


def events():
    return [json.loads(p) for t, p in published if t.endswith("/event")]


cases = []
add = lambda group, desc, req, expect, **world: cases.append((group, desc, req, expect, world))
J = json.dumps

# A. malformed requests
for d, raw in [("not JSON", b"run slot 3"), ("JSON list", b'[{"cmd":"run","slots":[1]}]'), ("JSON null", b"null"),
               ("JSON string", b'"run"'), ("empty", b""), ("truncated", b'{"cmd":"run","slots":[1'), ("binary", bytes(range(256)))]:
    add("A_malformed", d, raw, "block")
# B. commands outside the whitelist
for c in ["jog", "J", "H", "R", "T", "C", "move", "set_temp", "shutdown", "", None, 1, ["run"]]:
    add("B_unknown_cmd", f"cmd={J(c)}", J({"cmd": c, "slots": [1]}).encode(), "block")
add("B_unknown_cmd", "cmd missing", J({"slots": [1]}).encode(), "block")
# C. bad slots
for d, sl in [("missing", "__missing__"), ("empty", []), ("0", [0]), ("10", [10]), ("-1", [-1]), ("2.5", [2.5]), ("1e9", [10 ** 9]),
              ("duplicate", [1, 1]), ("10 slots", list(range(1, 11))), ("valid+invalid", [1, 12]), ('"3"', ["3"]),
              ("true", [True]), ("false", [False]), ("[2]", [[2]]), ("null", [None]), ("string list", "1,2,3"), ("number", 3), ("object", {"0": 1})]:
    req = {"cmd": "run"} if sl == "__missing__" else {"cmd": "run", "slots": sl}
    add("C_bad_slots", d, J(req).encode(), "block")
# D. injection of extra fields (must not change what is sent to stations)
add("D_injection", "run + motor fields", J({"cmd": "run", "slots": [1], "station": "hbw", "letter": "J", "ms": 9000}).encode(), "allow")
add("D_injection", "home + jog fields", J({"cmd": "home", "motor": "B", "ms": 9000}).encode(), "allow")
# E. unsafe plant state (preflight)
add("E_preflight", "orchestrator busy (running)", J({"cmd": "run", "slots": [1]}).encode(), "block", orc_state="running")
add("E_preflight", "home while running", J({"cmd": "home"}).encode(), "block", orc_state="running")
for st in STATIONS:
    add("E_preflight", f"{st} offline (run)", J({"cmd": "run", "slots": [1]}).encode(), "block", offline=(st,))
    add("E_preflight", f"{st} offline (home)", J({"cmd": "home"}).encode(), "block", offline=(st,))
    add("E_preflight", f"{st} busy (run)", J({"cmd": "run", "slots": [1]}).encode(), "block", mod={st: {"busy": True}})
    add("E_preflight", f"{st} stale status (run)", J({"cmd": "run", "slots": [1]}).encode(), "block", stale=(st,))
    add("E_preflight", f"{st} no status (run)", J({"cmd": "run", "slots": [1]}).encode(), "block", mod={st: None})
for st in ("hbw", "grabber", "oven"):
    add("E_preflight", f"{st} not homed (run)", J({"cmd": "run", "slots": [1]}).encode(), "block", mod={st: {"homed": False}})
add("E_preflight", "box 2 not in rack", J({"cmd": "run", "slots": [2]}).encode(), "block", mod={"hbw": {"boxes": "RCRRRRRRR"}})
add("E_preflight", "a box outside the rack", J({"cmd": "run", "slots": [1]}).encode(), "block", mod={"hbw": {"boxes": "RRRRRRRRC"}})
add("E_preflight", "rack string empty", J({"cmd": "run", "slots": [1]}).encode(), "block", mod={"hbw": {"boxes": ""}})
add("E_preflight", "grabber holding a piece", J({"cmd": "run", "slots": [1]}).encode(), "block", mod={"grabber": {"hold": "piece"}})
# F. positive controls
for sl in ([1], [1, 2, 3], [9, 1], list(range(1, 10))):
    add("F_valid", f"run {sl}", J({"cmd": "run", "slots": sl}).encode(), "allow")
add("F_valid", "RUN upper-case", J({"cmd": "RUN", "slots": [1]}).encode(), "allow")
add("F_valid", "home", J({"cmd": "home"}).encode(), "allow")
add("F_valid", "home while not homed", J({"cmd": "home"}).encode(), "allow", mod={"hbw": {"homed": False}})
add("F_valid", "stop while running", J({"cmd": "stop"}).encode(), "stop", orc_state="running")
add("F_valid", "status", J({"cmd": "status"}).encode(), "status")

rows = []
for group, desc, raw, expect, world in cases:
    set_world(**world)
    published.clear()
    err = ""
    try:
        orc.handle_request(raw)
    except Exception as e:
        err = f"{type(e).__name__}: {e}"[:120]
    ev = [e["event"] for e in events()]
    accepted = "job_accepted" in ev
    moves = motion_cmds()
    if err:
        ok = False
    elif expect == "block":
        ok = not accepted and not moves
    elif expect == "allow":
        ok = accepted and all(m.split(":")[1] in ("H", "R", "T", "P", "O", "C", "G", "D", "M") for m in moves) and not any(":J" in m for m in moves)
    elif expect == "stop":
        ok = "stopped" in ev and not moves
    else:
        ok = "status_sent" in ev and not accepted and not moves
    rows.append(dict(group=group, desc=desc, expect=expect, accepted=accepted, events=" ".join(ev),
                     motion=" ".join(moves), error=err, ok=ok))

with open(f"{out}_cases.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader(); w.writerows(rows)
groups = {}
for r in rows:
    g = groups.setdefault(r["group"], {"n": 0, "pass": 0}); g["n"] += 1; g["pass"] += r["ok"]
summary = {"total": len(rows), "pass": sum(r["ok"] for r in rows), "groups": groups,
           "failures": [{k: r[k] for k in ("group", "desc", "events", "motion", "error")} for r in rows if not r["ok"]]}
json.dump(summary, open(f"{out}_summary.json", "w"), indent=1)
print(f"LAYER 2 (orchestrator): {summary['pass']}/{summary['total']} pass")
for g, s in groups.items():
    print(f"  {g:18s} {s['pass']}/{s['n']}")
for r in rows:
    if not r["ok"]:
        print(f"  FAIL {r['group']} | {r['desc']} | events={r['events']} motion={r['motion']} {r['error']}")
