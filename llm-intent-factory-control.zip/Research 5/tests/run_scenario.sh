#!/bin/bash
# Stop-semantics checks with simulated stations (needs mosquitto and paho-mqtt).
#   ./run_scenario.sh stop_in_preflight_run   HB=5 (slow heartbeat keeps the preflight waiting)
#   ./run_scenario.sh stop_in_preflight_home
#   ./run_scenario.sh lwt_in_home            (HBW Last Will during homing)
#   ./run_scenario.sh normal                 (regression: 3-piece run)
cd "$(dirname "$0")"; mkdir -p logs
case "$1" in stop_in_preflight_*) HB=5; SC=0.05;; lwt_in_home) HB=0.3; SC=1.0;; *) HB=0.3; SC=0.05;; esac
mosquitto -p 1883 > /dev/null 2>&1 & MP=$!; sleep 0.5
HB=$HB python3 sim_stations.py $SC > /dev/null 2>&1 & SP=$!; sleep 1
python3 orc_local.py > logs/orchestrator.log 2>&1 & OP=$!; sleep 2
python3 test_stop_semantics.py "$@"; RC=$?
kill $OP $SP $MP 2>/dev/null; wait 2>/dev/null
exit $RC
