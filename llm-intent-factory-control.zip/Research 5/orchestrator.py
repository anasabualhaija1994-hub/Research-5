#!/usr/bin/env python3
"""
============================================================================
 Factory Orchestrator v2 - pipelined, dependency-driven
============================================================================
Every station has its own worker thread. A worker sends its next command the
instant that command's real prerequisites are met (an event from another
station), so stations run side by side and several pieces are in flight at
once. There are no fixed timers between stations.

Per piece i (HBW slot s):
  HBW      R(s)  starts after the previous piece's T is done (the HBW can only
                 have one box out of its rack at a time)
  Grabber  P     starts the moment the box reaches HBW's outer light barrier
                 (HBW "progress: box_outside"), if the Grabber is free
  HBW      T(s)  starts the moment Grabber P is done (piece lifted off the
                 holder) - runs in parallel with everything below
  Oven     C     armed the moment Grabber P is done, as soon as the oven is
                 free from the previous piece
  Grabber  O/R   with EARLY_DROP: starts as soon as the oven tray is free, i.e.
                 the previous piece's oven cycle has reached phase "cutting"
                 (vacuum already lifted it off the tray). The piece then waits
                 on the tray and the next oven C sees it immediately (~11 s
                 saved per piece). Without EARLY_DROP: waits for oven armed.
                 Every REHOME_ROTATE_EVERY-th piece uses R (put + rotate
                 re-homing), like the original standalone's cycles 3/6/9, to
                 stop encoder drift accumulating over many pieces.
  Sorter   C     armed as soon as the oven is armed and the sorter is free

If anything faults, times out, or is rejected, every station is sent STOP
(STOP_ALL_ON_FAULT) and the script exits with the reason. Ctrl+C does the same.

Install once:   pip install paho-mqtt
Run:            python orchestrator.py
Before running: home HBW/Grabber/Oven (H), declare boxes (L all R), and make
                sure the pieces are physically in the boxes. A preflight check
                verifies all of this and refuses to start if it is off.
============================================================================
"""
import json
import sys
import threading
import time

import paho.mqtt.client as mqtt

# ==========================================
# Config
# ==========================================
BROKER_HOST = "192.168.0.249"
BROKER_PORT = 1883

HBW_SLOTS = [1, 2, 3]           # one piece per slot, processed in this order
REHOME_ROTATE_EVERY = 3         # Grabber uses R (rotate re-home) on every Nth piece
SAME_STATION_SETTLE_S = 0.3     # min gap between two commands to the SAME station
STOP_ALL_ON_FAULT = True
PREFLIGHT = True
EARLY_DROP = True               # Grabber drops next piece once oven tray is free
TRAY_FREE_PHASE = "cutting"     # oven phase after which the tray is empty

MOVE_TIMEOUT_S = 180            # a single motion command finishing
WAIT_TIMEOUT_S = 900            # waiting on another station / a piece

STATIONS = ("hbw", "grabber", "oven", "colorsorter")

# ==========================================
# Shared state
# ==========================================
abort = threading.Event()
errors = []
connected = threading.Event()

pending = {}                                  # command_id -> Cmd
last_done = {s: 0.0 for s in STATIONS}        # per-station time of last "done"
lwt = {}                                      # station -> "online"/"offline"
status = {}                                   # station -> last status JSON (any)
status_live = {}                              # station -> last LIVE (non-retained) status

_counter = 0
_counter_lock = threading.Lock()
T0 = time.time()

pieces = [
    {"slot": s,
     "r_ready": threading.Event(),      # box is at HBW's outer barrier
     "p_done": threading.Event(),       # Grabber has lifted the piece
     "oven_armed": threading.Event(),   # oven acknowledged its C command
     "tray_free": threading.Event(),    # oven tray empty (prev piece lifted off)
     "oven_done": threading.Event(),
     "cs_done": threading.Event(),
     "t_done_at": None}
    for s in HBW_SLOTS
]
piece_by_slot = {p["slot"]: p for p in pieces}
if pieces:
    pieces[0]["tray_free"].set()
oven_current = [-1]                           # index of the piece the oven is processing


def log(msg):
    print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)


def fail(msg):
    if not abort.is_set():
        errors.append(msg)
        log(f"!!! {msg}")
        abort.set()


class Aborted(Exception):
    pass


class Cmd:
    def __init__(self, station, letter, cid):
        self.station, self.letter, self.cid = station, letter, cid
        self.started = threading.Event()
        self.finished = threading.Event()
        self.error = None
        self.sent_at = time.time()


# ==========================================
# MQTT
# ==========================================
try:
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="factory-orchestrator")
except AttributeError:                       # paho-mqtt 1.x
    client = mqtt.Client(client_id="factory-orchestrator")


def on_connect(c, userdata, flags, rc, props=None):
    for st in STATIONS:
        c.subscribe(f"factory/{st}/event")
        c.subscribe(f"factory/{st}/status")
        c.subscribe(f"factory/{st}/lwt")
    connected.set()


def on_message(c, userdata, msg):
    parts = msg.topic.split("/")
    if len(parts) != 3 or parts[0] != "factory" or parts[1] not in STATIONS:
        return
    st, kind = parts[1], parts[2]
    raw = msg.payload.decode("utf-8", "replace").strip()

    if kind == "lwt":
        lwt[st] = raw
        return
    try:
        ev = json.loads(raw)
    except ValueError:
        return                                # verbose step lines etc.
    if kind == "status":
        status[st] = ev
        if not msg.retain:
            status_live[st] = ev
        return
    if kind != "event":
        return

    etype = ev.get("event")

    # HBW: box has reached the outer light barrier -> Grabber may go pick it
    if st == "hbw" and etype == "progress" and ev.get("state") == "box_outside":
        p = piece_by_slot.get(ev.get("slot"))
        if p:
            p["r_ready"].set()

    # Oven: previous piece has left the tray -> next piece may be dropped
    if st == "oven" and etype == "phase" and ev.get("phase") == TRAY_FREE_PHASE:
        nxt = oven_current[0] + 1
        if 0 < nxt < len(pieces) and not pieces[nxt]["tray_free"].is_set():
            pieces[nxt]["tray_free"].set()
            log(f"oven        tray free -> piece {pieces[nxt]['slot']} may be dropped")

    cmd = pending.get(ev.get("command_id"))
    if cmd is None:
        return
    if etype == "started":
        cmd.started.set()
    elif etype == "done":
        last_done[st] = time.time()
        log(f"{st:11s} {cmd.letter} done  ({time.time() - cmd.sent_at:.1f}s)")
        cmd.started.set()
        cmd.finished.set()
    elif etype in ("fault", "rejected"):
        cmd.error = (f"{st} {cmd.letter} {etype.upper()}: {ev.get('code')} "
                     f"step={ev.get('step', '-')} phase={ev.get('phase', '-')}")
        cmd.started.set()
        cmd.finished.set()
        fail(cmd.error)


client.on_connect = on_connect
client.on_message = on_message


def send(station, letter, **extra):
    global _counter
    if abort.is_set():
        raise Aborted()
    with _counter_lock:
        _counter += 1
        cid = f"orc-{station[:2]}-{_counter}-{int(time.time())}"
    cmd = Cmd(station, letter, cid)
    pending[cid] = cmd
    gap = last_done[station] + SAME_STATION_SETTLE_S - time.time()
    if gap > 0:
        time.sleep(gap)
    payload = {"cmd": letter, "command_id": cid}
    payload.update(extra)
    cmd.sent_at = time.time()
    client.publish(f"factory/{station}/cmd", json.dumps(payload), qos=1)
    log(f"{station:11s} {letter} sent  {extra if extra else ''}")
    return cmd


def stop_all():
    for st in STATIONS:
        client.publish(f"factory/{st}/cmd",
                       json.dumps({"cmd": "S", "command_id": f"orc-stop-{st[:2]}-{int(time.time())}"}), qos=1)
    time.sleep(0.5)


# ==========================================
# Waiting helpers
# ==========================================
def _wait(ev, what, timeout):
    end = time.time() + timeout
    while True:
        if abort.is_set():
            raise Aborted()
        if ev.wait(0.2):
            return
        if time.time() > end:
            raise TimeoutError(f"timed out waiting for {what}")


def wait_started(cmd):
    _wait(cmd.started, f"{cmd.station}:{cmd.letter} to start", 15)
    if cmd.error:
        raise RuntimeError(cmd.error)


def wait_done(cmd, timeout=MOVE_TIMEOUT_S):
    _wait(cmd.finished, f"{cmd.station}:{cmd.letter} to finish", timeout)
    if cmd.error:
        raise RuntimeError(cmd.error)


def wait_for(event, what):
    _wait(event, what, WAIT_TIMEOUT_S)


# ==========================================
# Station workers
# ==========================================
def hbw_worker():
    for p in pieces:
        r = send("hbw", "R", slot=p["slot"])
        wait_done(r)
        p["r_ready"].set()                       # (normally already set by the progress event)
        wait_for(p["p_done"], f"Grabber to pick piece {p['slot']}")
        t = send("hbw", "T", slot=p["slot"])
        wait_done(t)


def grabber_worker():
    for i, p in enumerate(pieces):
        wait_for(p["r_ready"], f"box {p['slot']} at HBW outer barrier")
        pick = send("grabber", "P")
        wait_done(pick)
        p["p_done"].set()
        if EARLY_DROP:
            wait_for(p["tray_free"], f"oven tray free for piece {p['slot']}")
        else:
            wait_for(p["oven_armed"], f"oven armed for piece {p['slot']}")
        put = send("grabber", "R" if (i + 1) % REHOME_ROTATE_EVERY == 0 else "O")
        wait_done(put)


def oven_worker():
    for i, p in enumerate(pieces):
        wait_for(p["p_done"], f"piece {p['slot']} picked")
        oven_current[0] = i
        c = send("oven", "C")
        wait_started(c)
        p["oven_armed"].set()
        wait_done(c, WAIT_TIMEOUT_S)
        p["oven_done"].set()


def sorter_worker():
    for p in pieces:
        wait_for(p["oven_armed"], f"oven armed for piece {p['slot']}")
        c = send("colorsorter", "C")
        wait_done(c, WAIT_TIMEOUT_S)
        p["t_done_at"] = time.time() - T0
        p["cs_done"].set()
        log(f"=== piece from slot {p['slot']} COMPLETE ===")


def run_worker(fn):
    try:
        fn()
    except Aborted:
        pass
    except Exception as e:                      # RuntimeError, TimeoutError, anything else
        fail(f"{fn.__name__}: {e}")


# ==========================================
# Preflight
# ==========================================
def preflight():
    log("preflight: waiting for a live status from every station ...")
    end = time.time() + 9
    while time.time() < end and not all(s in status_live for s in STATIONS):
        time.sleep(0.2)

    problems = []
    for st in STATIONS:
        if lwt.get(st) != "online":
            problems.append(f"{st}: not online (lwt={lwt.get(st)})")
        s = status_live.get(st) or status.get(st)
        if s is None:
            problems.append(f"{st}: no status received")
            continue
        if st not in status_live:
            log(f"  warning: {st}: only a retained status seen (no live heartbeat)")
        if s.get("busy"):
            problems.append(f"{st}: busy")
        if st in ("hbw", "grabber", "oven") and s.get("homed") is not True:
            problems.append(f"{st}: not homed (send H first)")

    h = status_live.get("hbw") or status.get("hbw") or {}
    boxes = h.get("boxes", "")
    for slot in HBW_SLOTS:
        if len(boxes) < slot or boxes[slot - 1] != "R":
            problems.append(f"hbw: box {slot} is not marked in rack (boxes={boxes!r})")
    if boxes and any(ch != "R" for ch in boxes):
        problems.append(f"hbw: not every box is in the rack (boxes={boxes!r}); fix with L after checking physically")
    g = status_live.get("grabber") or status.get("grabber") or {}
    if g.get("hold") not in (None, "empty"):
        problems.append(f"grabber: hold state is {g.get('hold')!r}, expected 'empty'")

    if problems:
        for pr in problems:
            log(f"  PREFLIGHT FAIL: {pr}")
        return False
    log("preflight OK: all stations online, homed, idle; boxes in rack")
    return True


# ==========================================
# Main
# ==========================================
def main():
    global T0
    client.connect(BROKER_HOST, BROKER_PORT, keepalive=30)
    client.loop_start()
    if not connected.wait(10):
        print("could not connect to the MQTT broker")
        sys.exit(1)
    time.sleep(0.5)                              # let retained lwt/status arrive

    if PREFLIGHT and not preflight():
        client.loop_stop()
        sys.exit(1)

    T0 = time.time()
    log(f"starting: {len(pieces)} piece(s), slots {HBW_SLOTS}")
    workers = [threading.Thread(target=run_worker, args=(fn,), daemon=True, name=fn.__name__)
               for fn in (hbw_worker, grabber_worker, oven_worker, sorter_worker)]
    for w in workers:
        w.start()

    try:
        while any(w.is_alive() for w in workers):
            time.sleep(0.3)
    except KeyboardInterrupt:
        fail("interrupted by user (Ctrl+C)")
    for w in workers:
        w.join(timeout=3)

    if errors:
        if STOP_ALL_ON_FAULT:
            log("sending STOP to all stations")
            stop_all()
        print("\nSTOPPED:", errors[0])
        print("Check the physical state, re-home (H), re-declare boxes (L), then re-run.")
        client.loop_stop()
        sys.exit(1)

    total = time.time() - T0
    print(f"\nAll {len(pieces)} piece(s) done in {total:.0f}s ({total / len(pieces):.0f}s per piece)")
    for p in pieces:
        print(f"  slot {p['slot']}: sorted at t+{p['t_done_at']:.0f}s")
    client.loop_stop()


if __name__ == "__main__":
    main()
