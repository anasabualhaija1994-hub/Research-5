/*
 * ============================================================================
 *  Grabber station - Controller firmware  (Step 1 + 2 + MQTT)
 * ============================================================================
 *  Built on Grabber_standalone.ino: every motion, target position, delay and
 *  pin sequence is preserved exactly. What changed (Step 1/2, unchanged from
 *  before):
 *
 *   * Every WAIT_WHILE has a TIMEOUT. The three homing waits (reference
 *     switches) also require the switch to read "reached" continuously for
 *     CONFIRM_MS before it is trusted. The four encoder-target moves
 *     (rotateCCWTo, rotateCWTo, horzFwdTo, vertDownTo) get STALL detection.
 *   * Every fixed delay() (including inside vacuumOn/vacuumOff) is now an
 *     abortable waitMs().
 *   * A simple HOLDING state (empty / full / unknown) is tracked - there is
 *     no vacuum sensor on this station, so the code cannot truly verify a
 *     pickup succeeded; it marks the state optimistically after a clean
 *     pick/put, and UNKNOWN the moment anything goes wrong around the
 *     vacuum step.
 *   * Motion runs in its own FreeRTOS task; loop() only reads the serial
 *     console.
 *   * SAFETY ON FAULT/ABORT: only the six axis motors are force-stopped.
 *     The compressor and vacuum valve are deliberately left as they were.
 *     After any fault a fresh "H" (home) is required before another pick or
 *     put.
 *
 *   MQTT (new) - same pattern as HBW/ColorSorter: every say() line is
 *     mirrored to the event topic unchanged; commands can arrive as JSON on
 *     the command topic with an optional "command_id" that is deduplicated
 *     (last 16 remembered) so a retried publish never runs twice; a
 *     retained heartbeat/status is published every HEARTBEAT_MS; a Last
 *     Will marks the station "offline" (retained) the instant its MQTT
 *     link drops. WiFi/MQTT connect/reconnect are fully non-blocking.
 *     Fill in WIFI_PASSWORD below before flashing.
 *
 *  Nothing runs automatically at boot: the station waits for commands.
 *
 *  Serial console (115200 baud, end each command with Enter):
 *    H          home all three axes (vertical up, horizontal back, rotate CW)
 *    P          PICK from the HBW conveyor
 *    O          PUT to the oven (no extra rotate-homing afterwards)
 *    R          PUT to the oven, WITH an extra rotate-homing afterwards
 *    A          run the original fixed sequence: 9x (wait for the HBW, PICK,
 *               PUT - with rotate-homing on cycles 3/6/9). Needs HOLDING=empty
 *               and homed.
 *    N <n>      same pattern as "A" but for n cycles instead of 9
 *    S          STOP immediately (single key press, no Enter needed)
 *    ?          status (JSON)
 *    V          toggle verbose step log
 *    D          raw sensor dump (read-only, safe anytime, no motion)
 *    L <E|F|?>  declare the HOLDING state by hand after checking the vacuum cup
 *    J <m> [ms] jog ONE motor for a short capped time (default 300 ms, max
 *               3000 ms). m is one of: U D F K C Q V (see original header)
 *
 *  MQTT command topic payload examples (see TOPIC_CMD below):
 *    {"cmd":"H","command_id":"c-1"}
 *    {"cmd":"P","command_id":"c-2"}
 *    {"cmd":"O","command_id":"c-3"}
 *    {"cmd":"R","command_id":"c-4"}
 *    {"cmd":"A","command_id":"c-5"}
 *    {"cmd":"N","count":9,"command_id":"c-6"}
 *    {"cmd":"S","command_id":"c-7"}
 *    {"cmd":"L","loc":"E","command_id":"c-8"}
 *    {"cmd":"J","motor":"U","ms":300,"command_id":"c-9"}
 *
 *  Replies are single-line JSON, identical over Serial and MQTT.
 *
 *  IMPORTANT: the software STOP is NOT a safety function. Keep a hardware
 *  power cut-off within reach at all times.
 * ============================================================================
 */
#include <Arduino.h>
#include <ctype.h>
#include <stdarg.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

// ==========================================
// Settings
// ==========================================
const uint32_t HOMING_SETTLE_MS = 1000;   // Python: time.sleep(1) after Initial Homing

// The Grabber cannot "see" that the HBW placed a piece on the conveyor, so
// PICK first waits this long. Same role as the original HBW_RETRIEVE_WAIT_MS
// - set it a bit above the HBW's own "POS X Retrieve" duration.
const uint32_t HBW_PIECE_WAIT_MS = 20000;

// Timeouts (ms). MEASURED on the real machine on 2026-09-22 (one full clean
// pick + one full clean put). See original header for the full breakdown.
const uint32_t TO_HOME_MS   = 8000;    // homing to a reference switch (measured up to ~5.7s)
const uint32_t TO_MOVE_MS   = 12000;   // an encoder-target move (measured up to ~8.4s)
const uint32_t STALL_MS     = 600;     // motor ON and no encoder pulse for this long -> STALL
const uint32_t CONFIRM_MS   = 30;      // a reference switch must read "reached" continuously this long to be trusted

// The rotate axis is only re-referenced by rotateHomeCW(). Between homings its encoder
// count drifts, so after this many puts the station re-homes the rotate axis ITSELF,
// whatever the caller asked for. The counter lives here (not in the orchestrator) so it
// also works when pieces arrive as separate one-piece jobs. Reset by any rotate homing.
const uint8_t ROTATE_REHOME_EVERY = 3;

// ==========================================
// Pins (unchanged from the standalone version)
// ==========================================
#define REF_SWITCH_VERTICAL_AXIS       36
#define REF_SWITCH_HORIZONTAL_AXIS     39
#define REF_SWITCH_ROTATE              34

#define ENC_VERT_AXIS_IMPULSE_1        35
#define ENC_VERT_AXIS_IMPULSE_2        32
#define ENC_HORZ_AXIS_IMPULSE_1        33
#define ENC_HORZ_AXIS_IMPULSE_2        25
#define ENC_ROTATE_IMPULSE_1           26
#define ENC_ROTATE_IMPULSE_2           27

#define MOTOR_VERT_AXIS_UP             16
#define MOTOR_VERT_AXIS_DOWN           17
#define MOTOR_HORZ_AXIS_BACKWARD       4
#define MOTOR_HORZ_AXIS_FORWARD        18
#define MOTOR_ROTATE_CLOCKWISE         19
#define MOTOR_ROTATE_COUNTERCLOCKWISE  21
#define COMPRESSOR                     22
#define VALVE_VACUUM                   23

// Target positions (unchanged from the standalone version)
const int PICK_ROTATE_TARGET = -5380;
const int PICK_HORZ_TARGET   = -680;
const int PICK_VERT_TARGET   = -1000;
const int PUT_ROTATE_TARGET  = -3570;
const int PUT_HORZ_TARGET    = -3320;
const int PUT_VERT_TARGET    = -3000;

// Only the six axis motors are force-stopped on fault/abort - see the header note.
static const uint8_t SAFE_OFF_PINS[] = {
  MOTOR_VERT_AXIS_UP, MOTOR_VERT_AXIS_DOWN, MOTOR_HORZ_AXIS_BACKWARD,
  MOTOR_HORZ_AXIS_FORWARD, MOTOR_ROTATE_CLOCKWISE, MOTOR_ROTATE_COUNTERCLOCKWISE
};

// ==========================================
// MQTT settings - FILL IN WIFI_PASSWORD BEFORE FLASHING
// ==========================================
const char* WIFI_SSID      = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD  = "YOUR_WIFI_PASSWORD";

const char* MQTT_HOST      = "192.168.0.249";
const uint16_t MQTT_PORT   = 1883;
const char* MQTT_CLIENT_ID = "grabber-esp32";

const char* TOPIC_CMD    = "factory/grabber/cmd";
const char* TOPIC_EVENT  = "factory/grabber/event";
const char* TOPIC_STATUS = "factory/grabber/status";
const char* TOPIC_LWT    = "factory/grabber/lwt";

const uint32_t WIFI_RETRY_MS = 5000;
const uint32_t MQTT_RETRY_MS = 5000;
const uint32_t HEARTBEAT_MS  = 5000;

#define CMDID_LEN     40
#define CMDID_HISTORY 16

// ==========================================
// Types (above every function, so the Arduino IDE's auto-generated
// prototypes can see them)
// ==========================================
enum Fault : uint8_t { GF_OK = 0, GF_TIMEOUT, GF_STALL, GF_ABORTED, GF_NOT_HOMED, GF_STATE, GF_BAD_ARG };

enum Phase : uint8_t { PH_IDLE = 0, PH_HOMING, PH_WAIT_PIECE, PH_PICKING, PH_PUTTING };

enum Hold : uint8_t { HOLD_EMPTY = 0, HOLD_FULL = 1, HOLD_UNKNOWN = 2 };

struct Cmd { char type; int count; int arg2; char cmd_id[CMDID_LEN + 1]; };   // arg2: motor letter for 'J' (jog), unused otherwise

static const char* faultName(Fault f) {
  switch (f) {
    case GF_OK:        return "OK";
    case GF_TIMEOUT:   return "TIMEOUT";
    case GF_STALL:     return "STALL";
    case GF_ABORTED:   return "ABORTED";
    case GF_NOT_HOMED: return "NOT_HOMED";
    case GF_STATE:     return "BAD_STATE";
    case GF_BAD_ARG:   return "BAD_ARG";
  }
  return "UNKNOWN";
}
static const char* phaseName(Phase p) {
  switch (p) {
    case PH_IDLE:       return "idle";
    case PH_HOMING:     return "homing";
    case PH_WAIT_PIECE: return "wait_piece";
    case PH_PICKING:    return "picking";
    case PH_PUTTING:    return "putting";
  }
  return "unknown";
}
static const char* holdName(Hold h) {
  switch (h) {
    case HOLD_EMPTY:   return "empty";
    case HOLD_FULL:    return "full";
    case HOLD_UNKNOWN: return "unknown";
  }
  return "unknown";
}

// ==========================================
// Shared state
// ==========================================
volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int rotatePulseCount     = 0;

volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;
volatile int8_t rotateMoveDirection     = 0;

volatile bool     abortFlag  = false;
volatile bool     homed      = false;
volatile bool     motionStarted = false;   // true once a motor pin was actually engaged in the current command
volatile bool     busy       = false;
volatile Phase    phase      = PH_IDLE;
volatile uint8_t  lastFault  = GF_OK;
volatile uint8_t  holding    = HOLD_EMPTY;
volatile uint32_t cyclesDone = 0;
volatile uint8_t  putsSinceRotateHome = 0;   // puts completed since the rotate axis was last homed
bool              verbose    = true;
const char*       faultStep  = nullptr;

QueueHandle_t     cmdQueue   = nullptr;
SemaphoreHandle_t printMutex = nullptr;

const int8_t encoder_table[16] = {
   0, -1,  1,  0,
   1,  0,  0, -1,
  -1,  0,  0,  1,
   0,  1, -1,  0
};

// ==========================================
// MQTT globals
// ==========================================
WiFiClient        wifiClient;
PubSubClient      mqttClient(wifiClient);
SemaphoreHandle_t mqttMutex   = nullptr;   // RECURSIVE mutex - see note on say() below
uint32_t          lastWifiAttempt = 0;
uint32_t          lastMqttAttempt = 0;
uint32_t          lastHeartbeat   = 0;

char    cmdIdHistory[CMDID_HISTORY][CMDID_LEN + 1];
uint8_t cmdIdHistoryPos = 0;

static bool isDuplicateCmdId(const char* id) {
  if (!id || !id[0]) return false;
  for (uint8_t i = 0; i < CMDID_HISTORY; i++)
    if (cmdIdHistory[i][0] && strncmp(cmdIdHistory[i], id, CMDID_LEN) == 0) return true;
  return false;
}
static void rememberCmdId(const char* id) {
  if (!id || !id[0]) return;
  strncpy(cmdIdHistory[cmdIdHistoryPos], id, CMDID_LEN);
  cmdIdHistory[cmdIdHistoryPos][CMDID_LEN] = 0;
  cmdIdHistoryPos = (cmdIdHistoryPos + 1) % CMDID_HISTORY;
}

// ==========================================
// Encoder interrupts (unchanged)
// ==========================================
void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 1) verticalPulseCount++;
  else if (verticalMoveDirection == -1) verticalPulseCount--;
}
void IRAM_ATTR handleRotateEncoder() {
  static uint8_t lastState = 0;
  if (rotateMoveDirection == 0) return;
  uint8_t cur = (digitalRead(ENC_ROTATE_IMPULSE_1) << 1) | digitalRead(ENC_ROTATE_IMPULSE_2);
  rotatePulseCount += encoder_table[(lastState << 2) | cur];
  lastState = cur;
}
void IRAM_ATTR handleHorizontalEncoder() {
  static uint8_t lastState = 0;
  if (horizontalMoveDirection == 0) return;
  uint8_t cur = (digitalRead(ENC_HORZ_AXIS_IMPULSE_1) << 1) | digitalRead(ENC_HORZ_AXIS_IMPULSE_2);
  horizontalPulseCount -= encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

// ==========================================
// Output: one whole line per call, serialized between tasks, mirrored to MQTT
// ==========================================
// See the HBW station's say() for the full note on why mqttMutex is
// RECURSIVE and why the 50 ms timeout keeps a busy MQTT link from ever
// meaningfully delaying a motor wait loop.
static void __attribute__((format(printf, 1, 2))) say(const char* fmt, ...) {
  char buf[380];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  if (n <= 0) return;
  if (n >= (int)sizeof buf) n = (int)sizeof buf - 1;
  if (printMutex) xSemaphoreTake(printMutex, portMAX_DELAY);
  Serial.write((const uint8_t*)buf, (size_t)n);
  if (printMutex) xSemaphoreGive(printMutex);

  if (mqttMutex && xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC_EVENT, (const uint8_t*)buf, (unsigned int)n, false);
    xSemaphoreGiveRecursive(mqttMutex);
  }
}
static void setPhase(Phase p) {
  phase = p;
  say("{\"event\":\"phase\",\"phase\":\"%s\"}\n", phaseName(p));
}
static void setHold(Hold h) {
  if (holding == h) return;
  holding = h;
  say("{\"event\":\"hold\",\"state\":\"%s\"}\n", holdName(h));
}

// ==========================================
// Sensors
// ==========================================
// Double-read confirmation (anti-glitch): a switch/barrier value is accepted only
// if two reads SENSOR_CONFIRM_MS apart agree. If they disagree (spike/noise),
// retry; if still no agreement, keep the last confirmed value for that pin.
const uint32_t SENSOR_CONFIRM_MS = 5;
static int8_t lastStable[40] = {
  -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
  -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1 };
static int readConfirmed(uint8_t p) {
  for (int tries = 0; tries < 3; tries++) {
    int a = digitalRead(p);
    delay(SENSOR_CONFIRM_MS);
    int b = digitalRead(p);
    if (a == b) { if (p < 40) lastStable[p] = (int8_t)a; return a; }
  }
  if (p < 40 && lastStable[p] >= 0) return lastStable[p];
  return digitalRead(p);
}
static inline bool isHigh(uint8_t p) { return readConfirmed(p) != LOW; }
static inline bool isLow(uint8_t p)  { return readConfirmed(p) == LOW; }
static inline bool rawHigh(uint8_t p) { return digitalRead(p) != LOW; }

static void safeOff() {
  for (uint8_t i = 0; i < sizeof(SAFE_OFF_PINS); i++) digitalWrite(SAFE_OFF_PINS[i], LOW);
  verticalMoveDirection = 0; horizontalMoveDirection = 0; rotateMoveDirection = 0;
}

// ==========================================
// Wait helpers
// ==========================================
#define WAIT_SWITCH(cond, ms)                                                  \
  do {                                                                         \
    uint32_t _t0 = millis();                                                   \
    for (;;) {                                                                 \
      if (abortFlag) { safeOff(); return GF_ABORTED; }                         \
      if (millis() - _t0 > (uint32_t)(ms)) { safeOff(); return GF_TIMEOUT; }   \
      if (!(cond)) {                                                           \
        uint32_t _c0 = millis(); bool _stable = true;                          \
        while (millis() - _c0 < CONFIRM_MS) {                                  \
          if (abortFlag) { safeOff(); return GF_ABORTED; }                     \
          if (cond) { _stable = false; break; }                                \
          delay(1);                                                            \
        }                                                                      \
        if (_stable) break;                                                    \
      }                                                                        \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define WAIT_AXIS(cond, counter, ms)                                           \
  do {                                                                         \
    uint32_t _t0 = millis(), _tp = _t0;                                        \
    int _last = (counter);                                                     \
    while (cond) {                                                             \
      if (abortFlag) { safeOff(); return GF_ABORTED; }                         \
      uint32_t _now = millis();                                                \
      if (_now - _t0 > (uint32_t)(ms)) { safeOff(); return GF_TIMEOUT; }       \
      int _c = (counter);                                                      \
      if (_c != _last) { _last = _c; _tp = _now; }                             \
      else if (_now - _tp > STALL_MS) { safeOff(); return GF_STALL; }          \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define TRY(call)                                                              \
  do {                                                                         \
    uint32_t _s = millis();                                                    \
    Fault _f = (call);                                                         \
    if (verbose) say("  %-16s %6lu ms  V=%d H=%d R=%d\n", #call,               \
        (unsigned long)(millis() - _s), (int)verticalPulseCount,               \
        (int)horizontalPulseCount, (int)rotatePulseCount);                     \
    if (_f != GF_OK) { if (!faultStep) faultStep = #call; return _f; }         \
  } while (0)

static Fault waitMs(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    if (abortFlag) return GF_ABORTED;
    delay(1);
  }
  return GF_OK;
}

// ==========================================
// Primitives (each = one WAIT_WHILE from the original code)
// ==========================================
static Fault vertAxisHomeUp() {
  motionStarted = true;
  digitalWrite(MOTOR_VERT_AXIS_UP, HIGH); verticalMoveDirection = 1;
  WAIT_SWITCH(isLow(REF_SWITCH_VERTICAL_AXIS), TO_HOME_MS);
  digitalWrite(MOTOR_VERT_AXIS_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);
  return GF_OK;
}
static Fault horzAxisHomeBack() {
  motionStarted = true;
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, HIGH); horizontalMoveDirection = 1;
  WAIT_SWITCH(isLow(REF_SWITCH_HORIZONTAL_AXIS), TO_HOME_MS);
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);
  return GF_OK;
}
static Fault rotateHomeCW() {
  motionStarted = true;
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH); rotateMoveDirection = 1;
  WAIT_SWITCH(isLow(REF_SWITCH_ROTATE), TO_HOME_MS);
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW); rotatePulseCount = 0; rotateMoveDirection = 0; delay(10);
  putsSinceRotateHome = 0;
  return GF_OK;
}
static Fault rotateCCWTo(int target) {
  motionStarted = true;
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, HIGH); rotateMoveDirection = -1;
  WAIT_AXIS(rotatePulseCount > target, rotatePulseCount, TO_MOVE_MS);
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, LOW); rotateMoveDirection = 0; delay(10);
  return GF_OK;
}
static Fault rotateCWTo(int target) {
  motionStarted = true;
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH); rotateMoveDirection = 1;
  WAIT_AXIS(rotatePulseCount < target, rotatePulseCount, TO_MOVE_MS);
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW); rotateMoveDirection = 0; delay(10);
  return GF_OK;
}
static Fault horzFwdTo(int target) {
  motionStarted = true;
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD, HIGH); horizontalMoveDirection = -1;
  WAIT_AXIS(horizontalPulseCount > target, horizontalPulseCount, TO_MOVE_MS);
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD, LOW); horizontalMoveDirection = 0; delay(10);
  return GF_OK;
}
static Fault vertDownTo(int target) {
  motionStarted = true;
  digitalWrite(MOTOR_VERT_AXIS_DOWN, HIGH); verticalMoveDirection = -1;
  WAIT_AXIS(verticalPulseCount > target, verticalPulseCount, TO_MOVE_MS);
  digitalWrite(MOTOR_VERT_AXIS_DOWN, LOW); verticalMoveDirection = 0; delay(10);
  return GF_OK;
}
static Fault vacuumOn() {
  digitalWrite(COMPRESSOR, HIGH);
  digitalWrite(VALVE_VACUUM, HIGH);
  TRY(waitMs(100));
  return GF_OK;
}
static Fault vacuumOff() {
  digitalWrite(COMPRESSOR, LOW);
  digitalWrite(VALVE_VACUUM, LOW);
  TRY(waitMs(100));
  return GF_OK;
}

// ==========================================
// High-level operations
// ==========================================
static Fault doHome() {
  homed = false;
  setPhase(PH_HOMING);
  TRY(vertAxisHomeUp());
  TRY(horzAxisHomeBack());
  TRY(rotateHomeCW());
  homed = true;
  setPhase(PH_IDLE);
  return GF_OK;
}

static Fault doPick() {
  if (!homed) return GF_NOT_HOMED;
  if (holding != HOLD_EMPTY) return GF_STATE;
  setPhase(PH_PICKING);
  TRY(rotateCCWTo(PICK_ROTATE_TARGET));
  TRY(horzFwdTo(PICK_HORZ_TARGET));
  TRY(vertDownTo(PICK_VERT_TARGET));
  setHold(HOLD_UNKNOWN);
  TRY(vacuumOn());
  TRY(vertAxisHomeUp());
  TRY(horzAxisHomeBack());
  setHold(HOLD_FULL);
  setPhase(PH_IDLE);
  return GF_OK;
}

static Fault doPut(bool withRotateHoming) {
  if (!homed) return GF_NOT_HOMED;
  if (holding != HOLD_FULL) return GF_STATE;
  setPhase(PH_PUTTING);
  TRY(rotateCWTo(PUT_ROTATE_TARGET));
  TRY(horzFwdTo(PUT_HORZ_TARGET));
  TRY(vertDownTo(PUT_VERT_TARGET));
  setHold(HOLD_UNKNOWN);
  TRY(vacuumOff());
  setHold(HOLD_EMPTY);
  TRY(vertAxisHomeUp());
  TRY(horzAxisHomeBack());
  if (putsSinceRotateHome < 255) putsSinceRotateHome++;
  if (withRotateHoming || putsSinceRotateHome >= ROTATE_REHOME_EVERY) TRY(rotateHomeCW());
  setPhase(PH_IDLE);
  return GF_OK;
}

static Fault doAutoCycles(int n) {
  if (n < 1 || n > 1000) return GF_BAD_ARG;
  if (!homed) return GF_NOT_HOMED;
  if (holding != HOLD_EMPTY) return GF_STATE;
  for (int cycle = 1; cycle <= n; cycle++) {
    setPhase(PH_WAIT_PIECE);
    TRY(waitMs(HBW_PIECE_WAIT_MS));
    TRY(doPick());
    TRY(doPut(cycle % 3 == 0));
    cyclesDone++;
  }
  return GF_OK;
}

static Fault doJog(char which, int ms) {
  if (toupper((unsigned char)which) == 'V') {
    if (ms < 50) ms = 150;
    if (ms > 500) ms = 500;
    digitalWrite(COMPRESSOR, HIGH);
    digitalWrite(VALVE_VACUUM, HIGH);
    TRY(waitMs((uint32_t)ms));
    digitalWrite(VALVE_VACUUM, LOW);
    digitalWrite(COMPRESSOR, LOW);
    return GF_OK;
  }
  if (ms < 50) ms = 300;
  if (ms > 3000) ms = 3000;
  int pin;
  int8_t* dirVar = nullptr; int8_t dirVal = 0;
  switch (toupper((unsigned char)which)) {
    case 'U': pin = MOTOR_VERT_AXIS_UP;             dirVar = (int8_t*)&verticalMoveDirection;   dirVal =  1; break;
    case 'D': pin = MOTOR_VERT_AXIS_DOWN;           dirVar = (int8_t*)&verticalMoveDirection;   dirVal = -1; break;
    case 'F': pin = MOTOR_HORZ_AXIS_FORWARD;        dirVar = (int8_t*)&horizontalMoveDirection; dirVal = -1; break;
    case 'K': pin = MOTOR_HORZ_AXIS_BACKWARD;       dirVar = (int8_t*)&horizontalMoveDirection; dirVal =  1; break;
    case 'C': pin = MOTOR_ROTATE_CLOCKWISE;         dirVar = (int8_t*)&rotateMoveDirection;     dirVal =  1; break;
    case 'Q': pin = MOTOR_ROTATE_COUNTERCLOCKWISE;  dirVar = (int8_t*)&rotateMoveDirection;     dirVal = -1; break;
    default: return GF_BAD_ARG;
  }
  motionStarted = true;
  *dirVar = dirVal;
  digitalWrite(pin, HIGH);
  TRY(waitMs((uint32_t)ms));
  digitalWrite(pin, LOW);
  *dirVar = 0;
  return GF_OK;
}

// ==========================================
// Command execution (runs in the motion task)
// ==========================================
static Fault runCommand(const Cmd& c) {
  switch (c.type) {
    case 'H': return doHome();
    case 'P': return doPick();
    case 'O': return doPut(false);
    case 'R': return doPut(true);
    case 'A': return doAutoCycles(9);
    case 'N': return doAutoCycles(c.count);
    case 'J': return doJog((char)c.arg2, c.count);
  }
  return GF_BAD_ARG;
}

void executeAndReport(const Cmd& c) {
  faultStep = nullptr;
  motionStarted = false;
  uint32_t t0 = millis();
  Fault f = runCommand(c);
  uint32_t dt = millis() - t0;
  safeOff();
  lastFault = f;

  if (f == GF_OK) {
    say("{\"event\":\"done\",\"cmd\":\"%c\",\"count\":%d,\"ms\":%lu,\"command_id\":\"%s\"}\n",
        c.type, c.count, (unsigned long)dt, c.cmd_id);
  } else {
    if (motionStarted) homed = false;
    say("{\"event\":\"fault\",\"cmd\":\"%c\",\"code\":\"%s\",\"step\":\"%s\",\"phase\":\"%s\",\"hold\":\"%s\",\"ms\":%lu,\"command_id\":\"%s\"}\n",
        c.type, faultName(f), faultStep ? faultStep : "-", phaseName(phase), holdName((Hold)holding),
        (unsigned long)dt, c.cmd_id);
  }
  busy = false;
}

void motionTask(void*) {
  Cmd c;
  for (;;) {
    if (xQueueReceive(cmdQueue, &c, portMAX_DELAY) == pdTRUE) executeAndReport(c);
  }
}

// ==========================================
// Serial console (runs in loop())
// ==========================================
static int buildStatusJson(char* out, size_t outSize) {
  return snprintf(out, outSize,
      "{\"event\":\"status\",\"busy\":%s,\"homed\":%s,\"phase\":\"%s\",\"hold\":\"%s\",\"cycles_done\":%lu,"
      "\"last_fault\":\"%s\",\"puts_since_rehome\":%u,\"v\":%d,\"h\":%d,\"r\":%d,\"verbose\":%s}\n",
      busy ? "true" : "false", homed ? "true" : "false", phaseName(phase), holdName((Hold)holding),
      (unsigned long)cyclesDone, faultName((Fault)lastFault), (unsigned)putsSinceRotateHome,
      (int)verticalPulseCount, (int)horizontalPulseCount, (int)rotatePulseCount, verbose ? "true" : "false");
}
static void printStatus() {
  char buf[380];
  buildStatusJson(buf, sizeof buf);
  say("%s", buf);
}
static void printHelp() {
  say("Commands: H | P | O | R | A | N <count> | S | ? | V | D | L <E|F|?> | J <U|D|F|K|C|Q|V> [ms]\n");
}
static void printRaw() {
  say("{\"event\":\"raw\",\"ref_vert\":%d,\"ref_horz\":%d,\"ref_rotate\":%d,\"v\":%d,\"h\":%d,\"r\":%d}\n",
      digitalRead(REF_SWITCH_VERTICAL_AXIS), digitalRead(REF_SWITCH_HORIZONTAL_AXIS), digitalRead(REF_SWITCH_ROTATE),
      (int)verticalPulseCount, (int)horizontalPulseCount, (int)rotatePulseCount);
}
static void reject(char type, int arg, const char* why, const char* cmd_id = "") {
  say("{\"event\":\"rejected\",\"cmd\":\"%c\",\"arg\":%d,\"code\":\"%s\",\"command_id\":\"%s\"}\n",
      type, arg, why, cmd_id ? cmd_id : "");
}
static void doStopWithId(const char* id) {
  safeOff();
  abortFlag = true;
  say("{\"event\":\"stop\",\"command_id\":\"%s\"}\n", (id && id[0]) ? id : "");
}
static void doStop() { doStopWithId(""); }

static void submit(char type, int count, int arg2 = 0, const char* cmd_id = "") {
  if (busy) { reject(type, count, "BUSY", cmd_id); return; }
  Cmd c = { type, count, arg2, {0} };
  if (cmd_id && cmd_id[0]) strncpy(c.cmd_id, cmd_id, CMDID_LEN);
  abortFlag = false;
  busy = true;
  if (type == 'J') say("{\"event\":\"started\",\"cmd\":\"J\",\"which\":\"%c\",\"ms\":%d,\"command_id\":\"%s\"}\n",
                        (char)toupper(arg2), count, c.cmd_id);
  else              say("{\"event\":\"started\",\"cmd\":\"%c\",\"count\":%d,\"command_id\":\"%s\"}\n", type, count, c.cmd_id);
  if (xQueueSend(cmdQueue, &c, 0) != pdPASS) { busy = false; reject(type, count, "QUEUE_FULL", cmd_id); }
}

static void declareHold(char x, const char* cmd_id = "") {
  Hold h;
  switch (x) {
    case 'E': h = HOLD_EMPTY; break;
    case 'F': h = HOLD_FULL; break;
    case '?': h = HOLD_UNKNOWN; break;
    default: reject('L', 0, "BAD_ARG", cmd_id); return;
  }
  if (busy) { reject('L', 0, "BUSY", cmd_id); return; }
  setHold(h);
  printStatus();
}

void handleLine(char* line) {
  while (*line == ' ') line++;
  if (!*line) return;
  char c = (char)toupper((unsigned char)*line);
  int arg = atoi(line + 1);
  switch (c) {
    case 'S': doStop(); break;
    case '?': printStatus(); break;
    case 'V': verbose = !verbose; say("{\"event\":\"verbose\",\"value\":%s}\n", verbose ? "true" : "false"); break;
    case 'D': printRaw(); break;
    case 'H': submit('H', 0); break;
    case 'P': submit('P', 0); break;
    case 'O': submit('O', 0); break;
    case 'R': submit('R', 0); break;
    case 'A': submit('A', 9); break;
    case 'N':
      if (arg < 1 || arg > 1000) { reject('N', arg, "BAD_ARG"); break; }
      submit('N', arg);
      break;
    case 'L': {
      char* p = line + 1;
      while (*p == ' ') p++;
      declareHold((char)toupper((unsigned char)*p));
      break;
    }
    case 'J': {
      char* p = line + 1;
      while (*p == ' ') p++;
      char which = (char)toupper((unsigned char)*p);
      if (!strchr("UDFKCQV", which)) { reject('J', 0, "BAD_ARG"); break; }
      p++;
      while (*p == ' ') p++;
      int ms = atoi(p);
      submit('J', ms > 0 ? ms : (which == 'V' ? 150 : 300), which);
      break;
    }
    default: printHelp(); break;
  }
}

// ==========================================
// MQTT - tiny manual JSON field extraction (flat objects only, no nesting)
// ==========================================
static bool jsonFindString(const char* json, const char* key, char* out, size_t outSize) {
  char pat[24]; snprintf(pat, sizeof pat, "\"%s\"", key);
  const char* p = strstr(json, pat);
  if (!p) return false;
  p = strchr(p + strlen(pat), ':');
  if (!p) return false;
  p++;
  while (*p == ' ') p++;
  if (*p != '"') return false;
  p++;
  size_t i = 0;
  while (*p && *p != '"' && i < outSize - 1) out[i++] = *p++;
  out[i] = 0;
  return true;
}
static bool jsonFindInt(const char* json, const char* key, int* out) {
  char pat[24]; snprintf(pat, sizeof pat, "\"%s\"", key);
  const char* p = strstr(json, pat);
  if (!p) return false;
  p = strchr(p + strlen(pat), ':');
  if (!p) return false;
  p++;
  while (*p == ' ') p++;
  *out = atoi(p);
  return true;
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  if (length >= 250) { reject('?', 0, "PAYLOAD_TOO_LONG"); return; }
  char buf[256];
  memcpy(buf, payload, length);
  buf[length] = 0;

  char cmdType[4] = {0};
  char cmdId[CMDID_LEN + 1] = {0};
  char motorStr[4] = {0};
  char locStr[4] = {0};
  int  count = 0;
  int  ms    = 0;

  jsonFindString(buf, "cmd", cmdType, sizeof cmdType);
  jsonFindString(buf, "command_id", cmdId, sizeof cmdId);
  jsonFindInt(buf, "count", &count);
  jsonFindInt(buf, "ms", &ms);
  jsonFindString(buf, "motor", motorStr, sizeof motorStr);
  jsonFindString(buf, "loc", locStr, sizeof locStr);

  if (!cmdType[0]) { reject('?', 0, "BAD_JSON", cmdId); return; }
  char c = (char)toupper((unsigned char)cmdType[0]);

  if (isDuplicateCmdId(cmdId)) { reject(c, 0, "DUPLICATE", cmdId); return; }

  switch (c) {
    case 'H': case 'P': case 'O': case 'R':
      rememberCmdId(cmdId);
      submit(c, 0, 0, cmdId);
      break;
    case 'A':
      rememberCmdId(cmdId);
      submit('A', 9, 0, cmdId);
      break;
    case 'N':
      if (count < 1 || count > 1000) { reject('N', count, "BAD_ARG", cmdId); break; }
      rememberCmdId(cmdId);
      submit('N', count, 0, cmdId);
      break;
    case 'S':
      rememberCmdId(cmdId);
      doStopWithId(cmdId);
      break;
    case 'D':
      rememberCmdId(cmdId);
      printRaw();
      break;
    case 'L':
      rememberCmdId(cmdId);
      declareHold(locStr[0] ? (char)toupper((unsigned char)locStr[0]) : '?', cmdId);
      break;
    case 'J': {
      char which = motorStr[0] ? (char)toupper((unsigned char)motorStr[0]) : 0;
      if (!strchr("UDFKCQV", which)) { reject('J', 0, "BAD_ARG", cmdId); break; }
      rememberCmdId(cmdId);
      submit('J', ms > 0 ? ms : (which == 'V' ? 150 : 300), which, cmdId);
      break;
    }
    default:
      reject(c, 0, "BAD_ARG", cmdId);
  }
}

static void publishHeartbeat() {
  char buf[380];
  buildStatusJson(buf, sizeof buf);
  if (xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC_STATUS, (const uint8_t*)buf, (unsigned int)strlen(buf), true);
    xSemaphoreGiveRecursive(mqttMutex);
  }
}

static void maintainNetwork() {
  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - lastWifiAttempt > WIFI_RETRY_MS) {
      lastWifiAttempt = millis();
      WiFi.disconnect();
      WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
      WiFi.setSleep(false);   // re-assert after reconnect - some cores reset this on begin()
      say("{\"event\":\"wifi_connecting\"}\n");
    }
    return;
  }
  if (xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (!mqttClient.connected()) {
      if (millis() - lastMqttAttempt > MQTT_RETRY_MS) {
        lastMqttAttempt = millis();
        say("{\"event\":\"mqtt_connecting\"}\n");
        if (mqttClient.connect(MQTT_CLIENT_ID, nullptr, nullptr, TOPIC_LWT, 1, true, "offline")) {
          mqttClient.subscribe(TOPIC_CMD);
          mqttClient.publish(TOPIC_LWT, "online", true);
          say("{\"event\":\"mqtt_connected\"}\n");
        } else {
          say("{\"event\":\"mqtt_connect_failed\",\"rc\":%d}\n", mqttClient.state());
        }
      }
    } else {
      mqttClient.loop();
    }
    xSemaphoreGiveRecursive(mqttMutex);
  }
}

// ==========================================
// Arduino entry points
// ==========================================
void setup() {
  Serial.begin(115200);
  printMutex = xSemaphoreCreateMutex();
  mqttMutex  = xSemaphoreCreateRecursiveMutex();

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);   // disable WiFi modem-sleep: it was adding 100s-1000+ms of
                          // scheduling jitter to the motion/encoder timing loops
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  mqttClient.setServer(MQTT_HOST, MQTT_PORT);
  mqttClient.setCallback(mqttCallback);
  mqttClient.setBufferSize(512);
  lastWifiAttempt = millis();

  pinMode(REF_SWITCH_VERTICAL_AXIS,   INPUT_PULLUP);
  pinMode(REF_SWITCH_HORIZONTAL_AXIS, INPUT_PULLUP);
  pinMode(REF_SWITCH_ROTATE,          INPUT_PULLUP);

  pinMode(ENC_VERT_AXIS_IMPULSE_1, INPUT);
  pinMode(ENC_VERT_AXIS_IMPULSE_2, INPUT);
  pinMode(ENC_HORZ_AXIS_IMPULSE_1, INPUT);
  pinMode(ENC_HORZ_AXIS_IMPULSE_2, INPUT);
  pinMode(ENC_ROTATE_IMPULSE_1,    INPUT);
  pinMode(ENC_ROTATE_IMPULSE_2,    INPUT);

  pinMode(MOTOR_VERT_AXIS_UP,              OUTPUT);
  pinMode(MOTOR_VERT_AXIS_DOWN,            OUTPUT);
  pinMode(MOTOR_HORZ_AXIS_BACKWARD,        OUTPUT);
  pinMode(MOTOR_HORZ_AXIS_FORWARD,         OUTPUT);
  pinMode(MOTOR_ROTATE_CLOCKWISE,          OUTPUT);
  pinMode(MOTOR_ROTATE_COUNTERCLOCKWISE,   OUTPUT);
  pinMode(COMPRESSOR,                      OUTPUT);
  pinMode(VALVE_VACUUM,                    OUTPUT);

  safeOff();
  digitalWrite(COMPRESSOR, LOW);
  digitalWrite(VALVE_VACUUM, LOW);

  attachInterrupt(digitalPinToInterrupt(ENC_VERT_AXIS_IMPULSE_1), handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_VERT_AXIS_IMPULSE_2), handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_ROTATE_IMPULSE_1),    handleRotateEncoder,     CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_ROTATE_IMPULSE_2),    handleRotateEncoder,     CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_HORZ_AXIS_IMPULSE_1), handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_HORZ_AXIS_IMPULSE_2), handleHorizontalEncoder, CHANGE);

  cmdQueue = xQueueCreate(1, sizeof(Cmd));
  xTaskCreatePinnedToCore(motionTask, "motion", 8192, NULL, 2, NULL, 1);

  say("{\"event\":\"boot\",\"station\":\"Grabber\",\"homed\":false}\n");
  printHelp();
}

void loop() {
  maintainNetwork();
  if (millis() - lastHeartbeat > HEARTBEAT_MS) { lastHeartbeat = millis(); publishHeartbeat(); }

  static char buf[24];
  static uint8_t n = 0;
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (n == 0 && (ch == 's' || ch == 'S')) { doStop(); continue; }
    if (ch == '\n' || ch == '\r') {
      if (n) { buf[n] = 0; handleLine(buf); n = 0; }
    } else if (n < sizeof(buf) - 1) {
      buf[n++] = ch;
    }
  }
  delay(1);
}
