/*
 * ============================================================================
 *  ColorSorter station - Controller firmware  (Step 1 + 2, same pattern as
 *  the HBW / Grabber / Oven stations)
 * ============================================================================
 *  Built on ColorSorter_standalone.ino: the color-reading logic, thresholds,
 *  pulse targets and timing are preserved exactly (this station's original
 *  logic was already careful and well isolated - the changes here are about
 *  safety and control, not about how color is read).
 *
 *   * Every unbounded wait (piece arrival, piece passing the color sensor,
 *     pulses to the sorting point) now has a TIMEOUT, and every fixed
 *     delay() is an abortable waitMs(), so STOP works at any moment.
 *   * The two light-barrier waits require the sensor to read "reached"
 *     continuously for CONFIRM_MS before it is trusted (same fix as the
 *     Oven station needed on real hardware: a single instantaneous read can
 *     be wrong). The pulse counter wait does NOT need this - it is a
 *     monotonic interrupt-driven count, so it can only be too slow, never
 *     falsely "arrived".
 *   * Per-color counters (white / red / blue / unclassified) are kept and
 *     reported in "?", useful for comparing the real color distribution
 *     against what was expected - the unclassified counter in particular
 *     flags a piece whose color never crossed any threshold (originally
 *     silent: the piece just passed through unsorted with no record of it).
 *   * Motion runs in its own FreeRTOS task; loop() only reads the serial
 *     console.
 *   * SAFETY ON FAULT/ABORT: belt, compressor and all three valves are
 *     turned off immediately. After any fault a fresh "H"-equivalent is not
 *     needed here (this station has no axis to re-home), but the current
 *     cycle's piece may be stuck at any point on the belt - check by hand
 *     before running another cycle.
 *
 *  Nothing runs automatically at boot: the station waits for commands.
 *
 *  Serial console (115200 baud, end each command with Enter):
 *    C          run ONE sorting cycle (wait for a piece, read color, sort)
 *    N <n>      run n cycles back to back (same as the old standalone's 9)
 *    S          STOP immediately (single key press, no Enter needed)
 *    ?          status (JSON, includes per-color counts)
 *    V          toggle verbose step log
 *    D          raw sensor dump (read-only, safe anytime, no motion)
 *    J B [ms]   jog the belt motor only, default 300 ms, max 5000 ms
 *    J W/R/U [ms]  fire compressor + one valve briefly (W=white R=red
 *                  U=blue "U" for "blUe", since B is taken by the belt),
 *                  default 150 ms, max 500 ms - for testing a solenoid
 *                  without running a full cycle
 *
 *  Replies are single-line JSON so the same format can go over MQTT later.
 *
 *  IMPORTANT: the software STOP is NOT a safety function. Keep a hardware
 *  power cut-off within reach, especially given the compressed-air valves.
 * ============================================================================
 */
#include <Arduino.h>
#include <ctype.h>
#include <stdarg.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

// ==========================================
// Settings
// ==========================================
// Timeouts (ms). MEASURED on the real machine on 2026-09-22 (three clean
// cycles, one per color): readColorWhilePassing ~4.0-4.4s, runToSortPoint
// scales with pulses (110->0.6s, 280->1.7s, 480->2.7s). Each timeout below
// is roughly 1.5-2x its measured worst case. Re-check after a few more real
// cycles and tighten further once you're confident the numbers are stable.
const uint32_t TO_PIECE_ARRIVE_MS = 300000;  // waiting for a piece at SENSOR_BEFORE - intentionally long
const uint32_t TO_COLOR_PASS_MS   = 8000;    // piece traveling past the color sensor (measured ~4.0-4.4s)
const uint32_t TO_SORT_PULSE_MS   = 5000;    // belt pulses to the sorting point (measured up to ~2.7s at 480 pulses)
const uint32_t CONFIRM_MS         = 10;      // a light barrier must read "seen" continuously this long to be trusted

// ==========================================
// Pins (unchanged from the standalone version)
// ==========================================
#define BELT_MOTOR     13
#define COMPRESSOR     12
#define VALVE_WHITE    14
#define VALVE_RED      27
#define VALVE_BLUE     26

#define PULSE_COUNTER  36
#define SENSOR_BEFORE  39
#define SENSOR_AFTER   34
#define COLOR_SENSOR   25

// ==========================================
// Color calibration constants (unchanged)
// ==========================================
const float WHITE_MIN_V = 0.8002f;
const float RED_MIN_V   = 1.6222f;
const float BLUE_MIN_V  = 2.0000f;

const float THRESHOLD_RED_WHITE = (RED_MIN_V + WHITE_MIN_V) / 2.0f;
const float THRESHOLD_BLUE_RED  = (BLUE_MIN_V + RED_MIN_V) / 2.0f;
const float THRESHOLD_WHITE_MIN = 0.4500f;

const float VOLTAGE_FACTOR = 0.000805861f;

static const uint8_t SAFE_OFF_PINS[] = { BELT_MOTOR, COMPRESSOR, VALVE_WHITE, VALVE_RED, VALVE_BLUE };

// ==========================================
// Types (above every function, so the Arduino IDE's auto-generated
// prototypes can see them)
// ==========================================
enum Fault : uint8_t { CF_OK = 0, CF_TIMEOUT, CF_ABORTED, CF_BAD_ARG };

enum Phase : uint8_t { PH_IDLE = 0, PH_WAIT_PIECE, PH_READING_COLOR, PH_SORTING };

struct Cmd { char type; int count; int arg2; };   // arg2: valve/motor letter for 'J' (jog), unused otherwise

static const char* faultName(Fault f) {
  switch (f) {
    case CF_OK:      return "OK";
    case CF_TIMEOUT: return "TIMEOUT";
    case CF_ABORTED: return "ABORTED";
    case CF_BAD_ARG: return "BAD_ARG";
  }
  return "UNKNOWN";
}

static const char* phaseName(Phase p) {
  switch (p) {
    case PH_IDLE:          return "idle";
    case PH_WAIT_PIECE:    return "wait_piece";
    case PH_READING_COLOR: return "reading_color";
    case PH_SORTING:       return "sorting";
  }
  return "unknown";
}

// ==========================================
// Shared state
// ==========================================
volatile unsigned int pulseCount = 0;

volatile bool     abortFlag  = false;
volatile bool     busy       = false;
volatile Phase    phase      = PH_IDLE;
volatile uint8_t  lastFault  = CF_OK;
volatile uint32_t cyclesDone = 0;
volatile uint32_t countWhite = 0, countRed = 0, countBlue = 0, countUnclassified = 0;
bool              verbose    = true;
const char*       faultStep  = nullptr;

float pieceMinVoltage = 3.3f;
int   targetPulse     = 0;
int   targetValve     = -1;
float lastVoltage      = 0.0f;   // last piece's minimum voltage, kept for diagnostics after the cycle ends

QueueHandle_t     cmdQueue   = nullptr;
SemaphoreHandle_t printMutex = nullptr;

void IRAM_ATTR countPulse() {
  pulseCount++;
}

// ==========================================
// Output: one whole line per call, serialized between tasks
// ==========================================
static void __attribute__((format(printf, 1, 2))) say(const char* fmt, ...) {
  char buf[300];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  if (n <= 0) return;
  if (n >= (int)sizeof buf) n = (int)sizeof buf - 1;
  if (printMutex) xSemaphoreTake(printMutex, portMAX_DELAY);
  Serial.write((const uint8_t*)buf, (size_t)n);
  if (printMutex) xSemaphoreGive(printMutex);
}

static void setPhase(Phase p) {
  phase = p;
  say("{\"event\":\"phase\",\"phase\":\"%s\"}\n", phaseName(p));
}

// ==========================================
// Sensors
// ==========================================
static inline bool isHigh(uint8_t p) { return digitalRead(p) != LOW; }
static inline bool isLow(uint8_t p)  { return digitalRead(p) == LOW; }

static void safeOff() {
  for (uint8_t i = 0; i < sizeof(SAFE_OFF_PINS); i++) digitalWrite(SAFE_OFF_PINS[i], LOW);
}

// ==========================================
// Wait helpers
// ==========================================
// For the two light barriers: require the sensor to read "reached"
// continuously for CONFIRM_MS before trusting it (a single instantaneous
// read can be a false flicker).
#define WAIT_WHILE(cond, ms)                                                   \
  do {                                                                         \
    uint32_t _t0 = millis();                                                   \
    for (;;) {                                                                 \
      if (abortFlag) { safeOff(); return CF_ABORTED; }                         \
      if (millis() - _t0 > (uint32_t)(ms)) { safeOff(); return CF_TIMEOUT; }   \
      if (!(cond)) {                                                           \
        uint32_t _c0 = millis(); bool _stable = true;                          \
        while (millis() - _c0 < CONFIRM_MS) {                                  \
          if (abortFlag) { safeOff(); return CF_ABORTED; }                     \
          if (cond) { _stable = false; break; }                                \
          delay(1);                                                            \
        }                                                                      \
        if (_stable) break;                                                    \
      }                                                                        \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

// For the pulse counter: monotonic, interrupt-driven, cannot flicker - a
// plain timeout + abort is enough, no confirm needed.
#define WAIT_PULSES(target, ms)                                                \
  do {                                                                         \
    uint32_t _t0 = millis();                                                   \
    while (pulseCount <= (unsigned int)(target)) {                             \
      if (abortFlag) { safeOff(); return CF_ABORTED; }                         \
      if (millis() - _t0 > (uint32_t)(ms)) { safeOff(); return CF_TIMEOUT; }   \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define TRY(call)                                                              \
  do {                                                                         \
    uint32_t _s = millis();                                                    \
    Fault _f = (call);                                                         \
    if (verbose) say("  %-24s %6lu ms\n", #call, (unsigned long)(millis() - _s)); \
    if (_f != CF_OK) { if (!faultStep) faultStep = #call; return _f; }         \
  } while (0)

static Fault waitMs(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    if (abortFlag) return CF_ABORTED;
    delay(1);
  }
  return CF_OK;
}

// ==========================================
// Primitives (each = one wait from the original runColorSorterCycle())
// ==========================================
static Fault waitPieceBefore() {
  WAIT_WHILE(isHigh(SENSOR_BEFORE), TO_PIECE_ARRIVE_MS);
  return CF_OK;
}

// Runs the belt while the piece passes under the color sensor, sampling the
// minimum voltage exactly like the original (a lower voltage marks a color
// hit; only readings above the 0.05V noise floor count).
static Fault readColorWhilePassing() {
  digitalWrite(BELT_MOTOR, HIGH);
  uint32_t t0 = millis();
  for (;;) {
    if (abortFlag) { safeOff(); return CF_ABORTED; }
    if (millis() - t0 > TO_COLOR_PASS_MS) { safeOff(); return CF_TIMEOUT; }
    if (isLow(SENSOR_AFTER)) {
      // confirm the barrier is really clear, not a flicker, before stopping
      uint32_t c0 = millis(); bool stable = true;
      while (millis() - c0 < CONFIRM_MS) {
        if (abortFlag) { safeOff(); return CF_ABORTED; }
        if (isHigh(SENSOR_AFTER)) { stable = false; break; }
        int sv = analogRead(COLOR_SENSOR);
        float v = sv * VOLTAGE_FACTOR;
        if (v > 0.05f && v < pieceMinVoltage) pieceMinVoltage = v;
        delay(1);
      }
      if (stable) break;
    }
    int sv = analogRead(COLOR_SENSOR);
    float v = sv * VOLTAGE_FACTOR;
    if (v > 0.05f && v < pieceMinVoltage) pieceMinVoltage = v;
    delay(10);
  }
  digitalWrite(BELT_MOTOR, LOW);
  return CF_OK;
}

static Fault runToSortPoint(int target) {
  pulseCount = 0;
  digitalWrite(BELT_MOTOR, HIGH);
  WAIT_PULSES(target, TO_SORT_PULSE_MS);
  digitalWrite(BELT_MOTOR, LOW);
  return CF_OK;
}

// ==========================================
// High-level operation
// ==========================================
static Fault doCycle() {
  pieceMinVoltage = 3.3f;
  targetPulse = 0;
  targetValve = -1;

  setPhase(PH_WAIT_PIECE);
  TRY(waitPieceBefore());

  setPhase(PH_READING_COLOR);
  TRY(readColorWhilePassing());
  lastVoltage = pieceMinVoltage;

  if (pieceMinVoltage > THRESHOLD_BLUE_RED)      { targetPulse = 480; targetValve = VALVE_BLUE; }
  else if (pieceMinVoltage > THRESHOLD_RED_WHITE) { targetPulse = 280; targetValve = VALVE_RED; }
  else if (pieceMinVoltage > THRESHOLD_WHITE_MIN) { targetPulse = 110; targetValve = VALVE_WHITE; }

  if (verbose) say("  color_read voltage=%.4f target_valve=%d target_pulse=%d\n",
                    (double)pieceMinVoltage, targetValve, targetPulse);

  if (targetValve != -1) {
    setPhase(PH_SORTING);
    TRY(runToSortPoint(targetPulse));
    digitalWrite(COMPRESSOR, HIGH);
    digitalWrite(targetValve, HIGH);
    TRY(waitMs(200));
    digitalWrite(targetValve, LOW);
    digitalWrite(COMPRESSOR, LOW);
    if (targetValve == VALVE_WHITE) countWhite++;
    else if (targetValve == VALVE_RED) countRed++;
    else countBlue++;
  } else {
    countUnclassified++;
    say("{\"event\":\"unclassified\",\"voltage\":%.4f}\n", (double)pieceMinVoltage);
  }

  pieceMinVoltage = 3.3f;
  targetPulse = 0;
  targetValve = -1;
  setPhase(PH_IDLE);
  TRY(waitMs(500));
  cyclesDone++;
  return CF_OK;
}

// Jog the belt for a short capped time - diagnostic only.
static Fault doJogBelt(int ms) {
  if (ms < 50) ms = 300;
  if (ms > 5000) ms = 5000;
  digitalWrite(BELT_MOTOR, HIGH);
  TRY(waitMs((uint32_t)ms));
  digitalWrite(BELT_MOTOR, LOW);
  return CF_OK;
}

// Fire compressor + one valve for a short capped burst - diagnostic only,
// to test a solenoid without running a full sort.
static Fault doJogValve(char which, int ms) {
  if (ms < 50) ms = 150;
  if (ms > 500) ms = 500;
  int pin;
  switch (toupper((unsigned char)which)) {
    case 'W': pin = VALVE_WHITE; break;
    case 'R': pin = VALVE_RED;   break;
    case 'U': pin = VALVE_BLUE;  break;
    default: return CF_BAD_ARG;
  }
  digitalWrite(COMPRESSOR, HIGH);
  digitalWrite(pin, HIGH);
  TRY(waitMs((uint32_t)ms));
  digitalWrite(pin, LOW);
  digitalWrite(COMPRESSOR, LOW);
  return CF_OK;
}

static Fault doN(int n) {
  if (n < 1 || n > 1000) return CF_BAD_ARG;
  for (int i = 0; i < n; i++) TRY(doCycle());
  return CF_OK;
}

// ==========================================
// Command execution (runs in the motion task)
// ==========================================
static Fault runCommand(const Cmd& c) {
  switch (c.type) {
    case 'C': return doCycle();
    case 'N': return doN(c.count);
    case 'J': return (char)c.arg2 == 'B' ? doJogBelt(c.count) : doJogValve((char)c.arg2, c.count);
  }
  return CF_BAD_ARG;
}

void executeAndReport(const Cmd& c) {
  faultStep = nullptr;
  uint32_t t0 = millis();
  Fault f = runCommand(c);
  uint32_t dt = millis() - t0;
  safeOff();
  lastFault = f;

  if (f == CF_OK) {
    say("{\"event\":\"done\",\"cmd\":\"%c\",\"count\":%d,\"ms\":%lu}\n", c.type, c.count, (unsigned long)dt);
  } else {
    say("{\"event\":\"fault\",\"cmd\":\"%c\",\"code\":\"%s\",\"step\":\"%s\",\"phase\":\"%s\",\"ms\":%lu}\n",
        c.type, faultName(f), faultStep ? faultStep : "-", phaseName(phase), (unsigned long)dt);
  }
  busy = false;
}

void motionTask(void*) {
  Cmd c;
  for (;;) {
    if (xQueueReceive(cmdQueue, &c, portMAX_DELAY) == pdTRUE) executeAndReport(c);
  }
}

// ==========================================
// Serial console (runs in loop())
// ==========================================
static void printStatus() {
  say("{\"event\":\"status\",\"busy\":%s,\"phase\":\"%s\",\"cycles_done\":%lu,\"last_fault\":\"%s\","
      "\"counts\":{\"white\":%lu,\"red\":%lu,\"blue\":%lu,\"unclassified\":%lu},"
      "\"last_voltage\":%.4f,\"piece_before\":%s,\"piece_after\":%s,\"verbose\":%s}\n",
      busy ? "true" : "false", phaseName(phase), (unsigned long)cyclesDone, faultName((Fault)lastFault),
      (unsigned long)countWhite, (unsigned long)countRed, (unsigned long)countBlue, (unsigned long)countUnclassified,
      (double)lastVoltage, isLow(SENSOR_BEFORE) ? "true" : "false", isLow(SENSOR_AFTER) ? "true" : "false",
      verbose ? "true" : "false");
}

static void printHelp() {
  say("Commands: C | N <count> | S | ? | V | D (raw sensor dump) | J B [ms, max 5000] | J <W|R|U> [ms, max 500]\n");
}

static void printRaw() {
  int sv = analogRead(COLOR_SENSOR);
  say("{\"event\":\"raw\",\"sensor_before\":%d,\"sensor_after\":%d,\"color_raw\":%d,\"color_voltage\":%.4f,\"pulse_count\":%u}\n",
      digitalRead(SENSOR_BEFORE), digitalRead(SENSOR_AFTER), sv, (double)(sv * VOLTAGE_FACTOR), pulseCount);
}

static void reject(char type, int arg, const char* why) {
  say("{\"event\":\"rejected\",\"cmd\":\"%c\",\"arg\":%d,\"code\":\"%s\"}\n", type, arg, why);
}

static void doStop() {
  safeOff();
  abortFlag = true;
  say("{\"event\":\"stop\"}\n");
}

static void submit(char type, int count, int arg2 = 0) {
  if (busy) { reject(type, count, "BUSY"); return; }
  Cmd c = { type, count, arg2 };
  abortFlag = false;
  busy = true;
  if (type == 'J') say("{\"event\":\"started\",\"cmd\":\"J\",\"which\":\"%c\",\"ms\":%d}\n", (char)toupper(arg2), count);
  else              say("{\"event\":\"started\",\"cmd\":\"%c\",\"count\":%d}\n", type, count);
  if (xQueueSend(cmdQueue, &c, 0) != pdPASS) { busy = false; reject(type, count, "QUEUE_FULL"); }
}

void handleLine(char* line) {
  while (*line == ' ') line++;
  if (!*line) return;
  char c = (char)toupper((unsigned char)*line);
  int arg = atoi(line + 1);
  switch (c) {
    case 'S': doStop(); break;
    case '?': printStatus(); break;
    case 'V': verbose = !verbose; say("{\"event\":\"verbose\",\"value\":%s}\n", verbose ? "true" : "false"); break;
    case 'D': printRaw(); break;
    case 'C': submit('C', 1); break;
    case 'N':
      if (arg < 1 || arg > 1000) { reject('N', arg, "BAD_ARG"); break; }
      submit('N', arg);
      break;
    case 'J': {
      char* p = line + 1;
      while (*p == ' ') p++;
      char which = (char)toupper((unsigned char)*p);
      if (!strchr("BWRU", which)) { reject('J', 0, "BAD_ARG"); break; }
      p++;
      while (*p == ' ') p++;
      int ms = atoi(p);
      submit('J', ms > 0 ? ms : (which == 'B' ? 300 : 150), which);
      break;
    }
    default: printHelp(); break;
  }
}

// ==========================================
// Arduino entry points
// ==========================================
void setup() {
  Serial.begin(115200);
  printMutex = xSemaphoreCreateMutex();

  pinMode(BELT_MOTOR, OUTPUT);
  pinMode(COMPRESSOR, OUTPUT);
  pinMode(VALVE_WHITE, OUTPUT);
  pinMode(VALVE_RED, OUTPUT);
  pinMode(VALVE_BLUE, OUTPUT);

  pinMode(PULSE_COUNTER, INPUT);
  pinMode(SENSOR_BEFORE, INPUT);
  pinMode(SENSOR_AFTER, INPUT);
  pinMode(COLOR_SENSOR, INPUT);

  safeOff();
  attachInterrupt(digitalPinToInterrupt(PULSE_COUNTER), countPulse, CHANGE);

  cmdQueue = xQueueCreate(1, sizeof(Cmd));
  xTaskCreatePinnedToCore(motionTask, "motion", 8192, NULL, 2, NULL, 1);

  say("{\"event\":\"boot\",\"station\":\"ColorSorter\"}\n");
  printHelp();
}

void loop() {
  static char buf[24];
  static uint8_t n = 0;
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (n == 0 && (ch == 's' || ch == 'S')) { doStop(); continue; }
    if (ch == '\n' || ch == '\r') {
      if (n) { buf[n] = 0; handleLine(buf); n = 0; }
    } else if (n < sizeof(buf) - 1) {
      buf[n++] = ch;
    }
  }
  delay(1);
}
