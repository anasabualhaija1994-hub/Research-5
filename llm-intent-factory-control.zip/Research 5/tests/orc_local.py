"""Runs ../orchestrator_service.py against a local broker (127.0.0.1) without the HTTP API."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import orchestrator_service as o
o.BROKER_HOST = "127.0.0.1"; o.HTTP_PORT = 0; o.PREFLIGHT_WAIT_S = 8
o.LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
o.main()
