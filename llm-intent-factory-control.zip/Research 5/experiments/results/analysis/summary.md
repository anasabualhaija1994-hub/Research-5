# Physical experiments - summary

## Throughput (9-piece order, same slots and pieces)

| Mode | OK / attempts | Makespan (s) | Per piece (s) | Steady-state cycle (s) | Piece latency (s) | Makespan speed-up | Throughput gain |
|---|---|---|---|---|---|---|---|
| Sequential (one job per piece) | 3/4 | 852.8 ± 3.9 | 94.8 ± 0.4 | 94.9 ± 0.5 | 92.5 ± 0.2 | 1.00x | 1.00x |
| Pipelined | 3/15 | 621.6 ± 0.9 | 69.1 ± 0.1 | 65.8 ± 0.0 | 94.6 ± 0.4 | 1.37x | 1.44x |
| Pipelined + early drop | 3/5 | 624.4 ± 5.0 | 69.4 ± 0.6 | 66.0 ± 0.6 | 94.9 ± 0.6 | 1.37x | 1.44x |

Pipelined: makespan -27.1% vs sequential, steady-state cycle 65.8 s vs 94.9 s (1.44x throughput).

Pipelined + early drop: makespan -26.8% vs sequential, steady-state cycle 66.0 s vs 94.9 s (1.44x throughput).

Steady-state cycle = mean time between consecutive piece completions. Piece latency = mean time of one piece from retrieval to sorting.

Failed attempts with a results folder: 1 (all aborted attempts: see aborted_attempts.csv)
- early (early_r3): hbw went offline

## Fault injection

Repetitions: 5, station fault observed in 5.

| Metric | Mean ± SD | Max |
|---|---|---|
| Fault $\rightarrow$ STOP at all 4 stations (s) | 0.004 ± 0.001 | 0.006 |
| Fault $\rightarrow$ error shown to operator (s) | 0.166 ± 0.017 | 0.186 |
| Fault $\rightarrow$ all stations idle (s)* | 3.081 ± 0.591 | 3.792 |
| Recovery: home after fault removed (s) | 12.1 ± 1.5 | 13.8 |
| Motion commands sent after the fault (total) | 0 | - |
| Recovered by a single home | 5/5 | - |

*bounded by the station heartbeat period (5 s).

Faults: hbw:NO_BOX, hbw:NO_BOX, hbw:NO_BOX, hbw:NO_BOX, hbw:NO_BOX

Other stations active at the fault: fault rep 1: colorsorter:C, fault rep 2: colorsorter:C, fault rep 3: colorsorter:C, fault rep 4: colorsorter:C, fault rep 5: colorsorter:C

## End-to-end from the n8n chat

| Model | Command | n | LLM + validation (s) | Dispatch + preflight (s) | Factory execution (s) | Total (s) | LLM share |
|---|---|---|---|---|---|---|---|
| claude | status | 2 | 1.32 | 0.92 | 0.0 | 2.2 | - |
| claude | home | 2 | 2.17 | 3.41 | 5.9 | 11.5 | 29.3% |
| claude | run | 1 | 1.96 | 1.98 | 99.2 | 103.1 | 1.9% |
| claude | stop | 1 | 2.15 | 0.12 | 0.0 | 2.3 | - |
| deepseek | status | 2 | 1.85 | 0.44 | 0.0 | 2.3 | - |
| deepseek | home | 2 | 2.67 | 1.42 | 7.7 | 11.7 | 27.1% |
| deepseek | run | 1 | 1.30 | 3.95 | 98.4 | 103.6 | 1.3% |
| deepseek | stop | 1 | 1.12 | -0.12 | 0.0 | 1.0 | - |

Medians over completed commands. LLM share is given only for commands that move the line. LLM + validation is measured on one clock (n8n); dispatch spans the n8n and logger clocks (offset up to 0.13 s, visible as negative values).
Outcomes: status_sent=4, home_done=4, job_done=2, stopped=2, job_failed=2

LLM + validation over all 14 chat commands: median 1.97 s, max 3.78 s.

## Operator STOP issued from the chat during a running job

| Run | Stations active at STOP | STOP fan-out spread (ms) | Last station ack (ms) | Motion cmds after |
|---|---|---|---|---|
| claude | colorsorter C (wait_piece), hbw T, oven C (unload_oven) | 0.0 | 17 | 0 |
| deepseek | colorsorter C (wait_piece), hbw T, oven C (unload_oven) | 1.0 | 20 | 0 |

Fan-out = time between the first and last STOP published by the orchestrator; ack = station 'stop' event, relative to the first STOP.

## Station utilisation, pipelined runs

Window = first to last piece completion; active = executing a command, wait_piece phases excluded.

| Run | Window (s) | HBW (%) | Grabber (%) | Oven (%) | Sorter (%) |
|---|---|---|---|---|---|
| pipe_r1 | 526.3 | 82.8 | 45.7 | 62.8 | 10.3 |
| pipe_r2 | 526.1 | 82.7 | 46.1 | 63.6 | 10.6 |
| pipe_r3 | 526.3 | 82.6 | 46.1 | 63.4 | 10.5 |
| mean | 526.2 | 82.7 | 46.0 | 63.3 | 10.5 |

## Aborted attempts (final protocol)

| Experiment | Attempts | Completed | Aborted by unplanned faults | Unplanned faults | Commands after fault |
|---|---|---|---|---|---|
| throughput, sequential | 4 | 3 | 1 | 1 | 0 |
| throughput, pipelined | 15 | 3 | 12 | 13 | 0 |
| throughput, pipelined + early drop | 5 | 3 | 2 | 2 | 0 |
| fault injection | 7 | 5 | 2 | 2 | 0 |
| end-to-end | 3 | 2 | 1 | 1 | 0 |

Fault-injection 'completed' = attempts in which the injected NO_BOX fault was reached. End-to-end counts run commands only. A station fault that is not ABORTED counts as its own fault (firmware checks the abort flag before the stall/timeout check).

