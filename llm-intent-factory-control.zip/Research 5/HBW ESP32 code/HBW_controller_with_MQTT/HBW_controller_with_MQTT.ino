/*
 * ============================================================================
 *  HBW (High-Bay Warehouse) - Controller firmware  (Step 1 + 2 + 3a + MQTT)
 * ============================================================================
 *  Built on HBW_standalone.ino: motion sequences and calibrated positions are
 *  preserved (verified identical on a simulator).
 *
 *   STEP 1/2 (unchanged): timeouts, stall detection, interlocks, generic
 *     retrieve/return driven by SLOTS[], FreeRTOS motion task, serial console.
 *
 *   STEP 3a - box state model + recovery
 *    * The station tracks WHERE EACH OF THE 9 BOXES IS:
 *          R = in its rack slot     C = on the conveyor
 *          A = on the cantilever    ? = unknown
 *      (box n always belongs to slot n)
 *    * Write-ahead marking: a box is marked '?' BEFORE every step in which its
 *      location changes (lifting from the shelf, pushing onto the conveyor,
 *      lifting from the conveyor, lowering into the shelf) and given its new
 *      location only after that step succeeds. After any fault or STOP the
 *      state therefore never lies: it is either right or '?'.
 *    * The state is stored in flash (NVS) and survives a reset.
 *    * RECOVERY without manual lifting:
 *        - box on the cantilever ('A')  -> "T n" puts it into the rack,
 *                                          "R n" continues to the conveyor
 *        - box on the conveyor ('C')    -> "T n" goes back to the conveyor
 *                                          pose, fetches it and returns it
 *      (after "H"). Recovery poses are NOT part of your original sequence:
 *      test them slowly, hand on the power switch.
 *    * Cross-checks with the light barriers: retrieve is refused if a box is
 *      already detected on the conveyor; a box declared 'C' must be detected.
 *    * Homing error log: encoder counts when the reference switch is hit
 *      (should be 0). Shows drift / lost pulses. See "home_err" in status.
 *    * Serial lines are built whole and sent under a mutex (no interleaving).
 *
 *   MQTT (new) - this station now speaks MQTT in addition to Serial:
 *    * Every line normally printed over Serial (say()) is ALSO mirrored,
 *      unchanged, to the MQTT event topic - no new event format was needed,
 *      the JSON was already MQTT-ready.
 *    * Commands can arrive over MQTT as JSON on the command topic, in
 *      addition to the Serial console. Each incoming command MAY carry a
 *      "command_id" (any short string); the station remembers the last 16
 *      command_ids it executed and silently rejects (event "rejected",
 *      code "DUPLICATE") a repeat of one already seen, so a retried publish
 *      from n8n/the broker never runs the same physical action twice. A
 *      command with no command_id is never deduplicated (this is how the
 *      Serial console still works exactly as before).
 *    * A retained heartbeat/status JSON is published every HEARTBEAT_MS to
 *      the status topic, and a Last Will and Testament marks the station
 *      "offline" (retained) the instant its MQTT connection drops, with an
 *      "online" retained message published right after each successful
 *      connect - so anything watching the station knows immediately if it
 *      disappears.
 *    * WiFi/MQTT connect and reconnect are entirely non-blocking (state
 *      checked once per loop() iteration against a retry timer) - motion,
 *      Serial and STOP are completely unaffected by a slow or absent network.
 *    * Fill in WIFI_PASSWORD below before flashing.
 *
 *  Serial console (115200 baud, end each command with Enter):
 *    H          home all axes
 *    R <n>      retrieve box n (1..9) to the outside conveyor
 *    T <n>      return box n into slot n
 *    A          auto demo = old standalone sequence (needs all boxes 'R')
 *    S          STOP immediately (single key press, no Enter needed)
 *    ?          status (JSON)
 *    V          toggle verbose step log
 *    L <n> <x>  declare box n location, x = R | C | A | ?
 *    L * R      declare ALL boxes in their racks (do this once after the
 *               first flash, and whenever you refill the rack by hand)
 *
 *  MQTT command topic payload examples (see TOPIC_CMD below):
 *    {"cmd":"H","command_id":"c-1"}
 *    {"cmd":"R","slot":3,"command_id":"c-2"}
 *    {"cmd":"T","slot":3,"command_id":"c-3"}
 *    {"cmd":"A","command_id":"c-4"}
 *    {"cmd":"S","command_id":"c-5"}
 *    {"cmd":"L","slot":3,"loc":"R","command_id":"c-6"}
 *    {"cmd":"L","all":true,"loc":"R","command_id":"c-7"}
 *
 *  Replies are single-line JSON, identical over Serial and MQTT.
 *
 *  IMPORTANT: the software STOP is NOT a safety function. Keep a hardware
 *  power cut-off for the motors within reach at all times.
 * ============================================================================
 */
#include <Arduino.h>
#include <ctype.h>
#include <stdarg.h>
#include <Preferences.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

// ==========================================
// Settings
// ==========================================
const uint32_t HOMING_SETTLE_MS     = 1000;
const uint32_t GRABBER_PICK_WAIT_MS = 2000;   // fixed wait for the Grabber (replaced by an MQTT event in step 3b)
const uint32_t AFTER_PICK_DELAY_MS  = 1000;

// Timeouts (ms). Measured on the real machine: cantilever stroke ~4.0 s,
// horizontal full travel ~12.3 s, vertical full travel ~6.7 s, conveyor ~0.7 s.
const uint32_t TO_CANTILEVER_MS  = 8000;
const uint32_t TO_VERT_MS        = 15000;
const uint32_t TO_HORZ_MS        = 25000;
const uint32_t TO_CONVEYOR_MS    = 3000;
const uint32_t TO_BOX_ARRIVE_MS  = 3000;   // box must be at the inside barrier
const uint32_t STALL_MS          = 600;    // motor ON and no encoder pulse for this long -> STALL

// Positions (encoder counts) - unchanged from the standalone version
const int H_CONVEYOR    = 61;
const int V_CONVEYOR    = 2800;   // height at the conveyor (box placed / picked)
const int V_RETURN_LIFT = 2400;   // lift height after taking the box off the conveyor
const int H_TOL         = 150;    // "at station" tolerance for the cantilever interlock

struct Slot { int h; int vRet; int vStore; };
//                    H     V_Ret  V_Store (0 = home switch)
const Slot SLOTS[9] = {
  { 2901,  500,    0 },   // slot 1
  { 2901, 1850, 1500 },   // slot 2
  { 2901, 3450, 3000 },   // slot 3
  { 5251,  500,    0 },   // slot 4
  { 5251, 1850, 1500 },   // slot 5
  { 5251, 3450, 3000 },   // slot 6
  { 7571,  500,    0 },   // slot 7
  { 7571, 1850, 1500 },   // slot 8
  { 7571, 3450, 3000 },   // slot 9
};
const uint8_t AUTO_ORDER[9] = { 1, 4, 7, 2, 5, 8, 3, 6, 9 };

// ==========================================
// Pins (unchanged)
// ==========================================
#define REF_SWITCH_HORIZONTAL    36
#define LIGHT_BARRIER_INSIDE     39
#define LIGHT_BARRIER_OUTSIDE    34
#define REF_SWITCH_VERTICAL      35

#define ENCODER_HORZ_IMP1        32
#define ENCODER_HORZ_IMP2        33
#define ENCODER_VERT_IMP1        25
#define ENCODER_VERT_IMP2        26

#define REF_SWITCH_CANTILEVER_FRONT 27
#define REF_SWITCH_CANTILEVER_BACK  14

#define MOTOR_CONVEYOR_FWD     23
#define MOTOR_CONVEYOR_BWD     22
#define MOTOR_HORZ_TO_RACK     21
#define MOTOR_HORZ_TO_CONVEYOR 19
#define MOTOR_VERT_DOWN        18
#define MOTOR_VERT_UP          4
#define MOTOR_CANTILEVER_FWD   17
#define MOTOR_CANTILEVER_BWD   16

static const uint8_t ALL_MOTORS[8] = {
  MOTOR_CONVEYOR_FWD, MOTOR_CONVEYOR_BWD, MOTOR_HORZ_TO_RACK, MOTOR_HORZ_TO_CONVEYOR,
  MOTOR_VERT_DOWN, MOTOR_VERT_UP, MOTOR_CANTILEVER_FWD, MOTOR_CANTILEVER_BWD
};

// ==========================================
// MQTT settings - FILL IN WIFI_PASSWORD BEFORE FLASHING
// ==========================================
const char* WIFI_SSID      = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD  = "YOUR_WIFI_PASSWORD";

const char* MQTT_HOST      = "192.168.0.249";
const uint16_t MQTT_PORT   = 1883;
const char* MQTT_CLIENT_ID = "hbw-esp32";

const char* TOPIC_CMD    = "factory/hbw/cmd";     // subscribe: commands in
const char* TOPIC_EVENT  = "factory/hbw/event";   // publish: every say() line, mirrored
const char* TOPIC_STATUS = "factory/hbw/status";  // publish, retained: periodic heartbeat/status
const char* TOPIC_LWT    = "factory/hbw/lwt";     // publish, retained: "online" / "offline"

const uint32_t WIFI_RETRY_MS = 5000;
const uint32_t MQTT_RETRY_MS = 5000;
const uint32_t HEARTBEAT_MS  = 5000;

#define CMDID_LEN     40
#define CMDID_HISTORY 16

// ==========================================
// Types (all above the first function, so the Arduino IDE's auto-generated
// prototypes can see them). Names avoid libc macros such as F_OK.
// ==========================================
enum Fault : uint8_t {
  HF_OK = 0,
  HF_TIMEOUT,
  HF_STALL,
  HF_ABORTED,
  HF_NO_BOX,
  HF_INTERLOCK_CANTILEVER,   // horizontal move requested while the cantilever is not fully back
  HF_INTERLOCK_STATION,      // cantilever extension requested away from a station
  HF_NOT_HOMED,
  HF_STATE,                  // command not allowed in the current box state
  HF_BAD_ARG,
  HF_CONVEYOR_BUSY           // light barriers detect a box on the conveyor
};

enum BoxLoc : uint8_t { LOC_UNKNOWN = 0, LOC_RACK = 1, LOC_CONVEYOR = 2, LOC_ARM = 3 };

struct Cmd { char type; int slot; char cmd_id[CMDID_LEN + 1]; char motor; int ms; };   // motor/ms: only used by the 'J' jog diagnostic

static const char* faultName(Fault f) {
  switch (f) {
    case HF_OK:                   return "OK";
    case HF_TIMEOUT:              return "TIMEOUT";
    case HF_STALL:                return "STALL";
    case HF_ABORTED:              return "ABORTED";
    case HF_NO_BOX:               return "NO_BOX";
    case HF_INTERLOCK_CANTILEVER: return "INTERLOCK_CANTILEVER";
    case HF_INTERLOCK_STATION:    return "INTERLOCK_STATION";
    case HF_NOT_HOMED:            return "NOT_HOMED";
    case HF_STATE:                return "BAD_STATE";
    case HF_BAD_ARG:              return "BAD_ARG";
    case HF_CONVEYOR_BUSY:        return "CONVEYOR_BUSY";
  }
  return "UNKNOWN";
}

static const char* locName(uint8_t l) {
  switch (l) {
    case LOC_RACK:     return "rack";
    case LOC_CONVEYOR: return "conveyor";
    case LOC_ARM:      return "arm";
  }
  return "unknown";
}
static char locChar(uint8_t l) {
  switch (l) {
    case LOC_RACK:     return 'R';
    case LOC_CONVEYOR: return 'C';
    case LOC_ARM:      return 'A';
  }
  return '?';
}

// ==========================================
// Shared state
// ==========================================
volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;

volatile bool    abortFlag     = false;  // set by STOP, checked in every wait loop
volatile bool    homed         = false;  // axis counters are valid
volatile bool    homingTrusted = false;  // a homing run started from a valid position (error log is meaningful)
volatile bool    busy          = false;  // a command is queued or running
volatile bool    motionStarted = false;  // a motor was driven during the current command
volatile uint8_t boxLoc[9]     = {0};    // location of box 1..9 (BoxLoc), persisted in flash
bool             verbose       = true;
const char*      faultStep     = nullptr; // first primitive that failed in the current command
volatile uint8_t lastFault     = HF_OK;  // result of the last finished command

// homing error log (encoder counts when the reference switch is hit; ideal = 0)
volatile int      homeErrVLast = 0, homeErrHLast = 0, homeErrVMax = 0, homeErrHMax = 0;
volatile uint32_t homeErrN     = 0;

QueueHandle_t     cmdQueue   = nullptr;
SemaphoreHandle_t printMutex = nullptr;
Preferences       prefs;

const int8_t encoder_table[16] = {
  0, -1,  1, 0,
  1,  0,  0, -1,
 -1,  0,  0,  1,
  0,  1, -1, 0
};

// ==========================================
// MQTT globals
// ==========================================
WiFiClient        wifiClient;
PubSubClient      mqttClient(wifiClient);
SemaphoreHandle_t mqttMutex   = nullptr;   // RECURSIVE mutex - see note on say() below
uint32_t          lastWifiAttempt = 0;
uint32_t          lastMqttAttempt = 0;
uint32_t          lastHeartbeat   = 0;

char    cmdIdHistory[CMDID_HISTORY][CMDID_LEN + 1];
uint8_t cmdIdHistoryPos = 0;

static bool isDuplicateCmdId(const char* id) {
  if (!id || !id[0]) return false;   // no id given -> never deduplicated (Serial console behavior)
  for (uint8_t i = 0; i < CMDID_HISTORY; i++)
    if (cmdIdHistory[i][0] && strncmp(cmdIdHistory[i], id, CMDID_LEN) == 0) return true;
  return false;
}
static void rememberCmdId(const char* id) {
  if (!id || !id[0]) return;
  strncpy(cmdIdHistory[cmdIdHistoryPos], id, CMDID_LEN);
  cmdIdHistory[cmdIdHistoryPos][CMDID_LEN] = 0;
  cmdIdHistoryPos = (cmdIdHistoryPos + 1) % CMDID_HISTORY;
}

// ==========================================
// Encoder interrupts (unchanged)
// ==========================================
void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t cur = (digitalRead(ENCODER_VERT_IMP1) << 1) | digitalRead(ENCODER_VERT_IMP2);
  verticalPulseCount += encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

void IRAM_ATTR handleHorizontalEncoder() {
  if (horizontalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t cur = (digitalRead(ENCODER_HORZ_IMP1) << 1) | digitalRead(ENCODER_HORZ_IMP2);
  if (cur != lastState) {
    horizontalPulseCount -= encoder_table[(lastState << 2) | cur];
    lastState = cur;
  }
}

// ==========================================
// Output: one whole line per call, serialized between tasks, mirrored to MQTT
// ==========================================
// NOTE ON THREAD SAFETY: say() can be called from the motion task (core 1,
// priority 2) AND, via mqttCallback(), from the Arduino loop() task while it
// is itself inside maintainNetwork() already holding mqttMutex. mqttMutex is
// a RECURSIVE mutex so that re-entrant case does not deadlock; the timeout
// below (50 ms) means a busy MQTT link can never meaningfully delay a motor
// wait loop - if the mutex isn't free in time, that one line is simply not
// published to MQTT (it still always reaches Serial).
static void __attribute__((format(printf, 1, 2))) say(const char* fmt, ...) {
  char buf[480];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  if (n <= 0) return;
  if (n >= (int)sizeof buf) n = (int)sizeof buf - 1;
  if (printMutex) xSemaphoreTake(printMutex, portMAX_DELAY);
  Serial.write((const uint8_t*)buf, (size_t)n);
  if (printMutex) xSemaphoreGive(printMutex);

  if (mqttMutex && xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC_EVENT, (const uint8_t*)buf, (unsigned int)n, false);
    xSemaphoreGiveRecursive(mqttMutex);
  }
}

// ==========================================
// Sensors (same logic as the original tests)
// ==========================================
// Double-read confirmation (anti-glitch): a switch/barrier value is accepted only
// if two reads SENSOR_CONFIRM_MS apart agree. If they disagree (spike/noise),
// retry; if still no agreement, keep the last confirmed value for that pin.
const uint32_t SENSOR_CONFIRM_MS = 5;
static int8_t lastStable[40] = {
  -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
  -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1 };
static int readConfirmed(uint8_t p) {
  for (int tries = 0; tries < 3; tries++) {
    int a = digitalRead(p);
    delay(SENSOR_CONFIRM_MS);
    int b = digitalRead(p);
    if (a == b) { if (p < 40) lastStable[p] = (int8_t)a; return a; }
  }
  if (p < 40 && lastStable[p] >= 0) return lastStable[p];
  return digitalRead(p);
}
static inline bool isHigh(uint8_t p) { return readConfirmed(p) != LOW; }
static inline bool isLow(uint8_t p)  { return readConfirmed(p) == LOW; }
static inline bool rawHigh(uint8_t p) { return digitalRead(p) != LOW; }

// Plausibility: the cantilever cannot be at both ends at once. If both switches
// read HIGH, the inputs are floating/noisy -> treat as NOT reached.
static inline bool cantFrontAtLimit() { return isHigh(REF_SWITCH_CANTILEVER_FRONT) && !isHigh(REF_SWITCH_CANTILEVER_BACK); }
static inline bool cantBackAtLimit()  { return isHigh(REF_SWITCH_CANTILEVER_BACK) && !isHigh(REF_SWITCH_CANTILEVER_FRONT); }
// true only if fn() stays true for 'ms' (sampled every 1 ms)
static bool stableTrue(bool (*fn)(), uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) { if (!fn()) return false; delay(1); }
  return true;
}
const uint32_t CANT_CONFIRM_MS = 40;
static inline bool vertAtHome()       { return isHigh(REF_SWITCH_VERTICAL); }
static inline bool horzAtHome()       { return isHigh(REF_SWITCH_HORIZONTAL); }
static inline bool boxInside()        { return isLow(LIGHT_BARRIER_INSIDE); }
static inline bool boxOutside()       { return isLow(LIGHT_BARRIER_OUTSIDE); }

// ==========================================
// Box state model (persisted)
// ==========================================
// Flash writes only happen between motions (all motors OFF).
static void stateSave() {
  uint8_t tmp[9];
  for (uint8_t i = 0; i < 9; i++) tmp[i] = boxLoc[i];
  prefs.putBytes("boxes", tmp, sizeof tmp);
}

static void stateLoad() {
  uint8_t tmp[9] = {0};
  prefs.begin("hbw", false);
  size_t n = prefs.getBytes("boxes", tmp, sizeof tmp);   // 0 bytes if never written
  for (uint8_t i = 0; i < 9; i++) boxLoc[i] = (n == sizeof tmp && tmp[i] <= LOC_ARM) ? tmp[i] : (uint8_t)LOC_UNKNOWN;
}

static void setLoc(int box, BoxLoc loc) {
  if (boxLoc[box - 1] == loc) return;
  boxLoc[box - 1] = loc;
  stateSave();
  say("{\"event\":\"box\",\"box\":%d,\"loc\":\"%s\"}\n", box, locName(loc));
}

static inline BoxLoc locOf(int box) { return (BoxLoc)boxLoc[box - 1]; }

static bool othersOutOfRack(int box) {          // any OTHER box not safely in its rack slot
  for (int j = 1; j <= 9; j++) if (j != box && locOf(j) != LOC_RACK) return true;
  return false;
}
static bool allInRack() {
  for (int j = 1; j <= 9; j++) if (locOf(j) != LOC_RACK) return false;
  return true;
}
static int carryingBox() {
  for (int j = 1; j <= 9; j++) if (locOf(j) == LOC_ARM) return j;
  return 0;
}
static void boxesStr(char* out) {
  for (uint8_t i = 0; i < 9; i++) out[i] = locChar(boxLoc[i]);
  out[9] = 0;
}

// ==========================================
// Motor helpers
// ==========================================
void allMotorsOff() {
  for (uint8_t i = 0; i < 8; i++) digitalWrite(ALL_MOTORS[i], LOW);
  verticalMoveDirection = 0;
  horizontalMoveDirection = 0;
}

// Drive one direction; the opposite direction of the same motor is forced OFF first.
static inline void run(uint8_t on, uint8_t opposite) {
  digitalWrite(opposite, LOW);
  digitalWrite(on, HIGH);
  motionStarted = true;
}
static inline void halt(uint8_t p) { digitalWrite(p, LOW); }

// ==========================================
// Wait helpers (timeout + abort [+ stall])
// ==========================================
#define WAIT_WHILE(cond, ms, onTimeout)                                        \
  do {                                                                         \
    uint32_t _t0 = millis();                                                   \
    while (cond) {                                                             \
      if (abortFlag) { allMotorsOff(); return HF_ABORTED; }                    \
      if (millis() - _t0 > (uint32_t)(ms)) { allMotorsOff(); return (onTimeout); } \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define WAIT_AXIS(cond, counter, ms)                                           \
  do {                                                                         \
    uint32_t _t0 = millis(), _tp = _t0;                                        \
    int _last = (counter);                                                     \
    while (cond) {                                                             \
      if (abortFlag) { allMotorsOff(); return HF_ABORTED; }                    \
      uint32_t _now = millis();                                                \
      if (_now - _t0 > (uint32_t)(ms)) { allMotorsOff(); return HF_TIMEOUT; } \
      int _c = (counter);                                                      \
      if (_c != _last) { _last = _c; _tp = _now; }                             \
      else if (_now - _tp > STALL_MS) { allMotorsOff(); return HF_STALL; }     \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define TRY(call)                                                              \
  do {                                                                         \
    uint32_t _s = millis();                                                    \
    Fault _f = (call);                                                         \
    if (verbose) say("  %-34s %6lu ms  V=%d H=%d\n", #call,                    \
        (unsigned long)(millis() - _s), (int)verticalPulseCount, (int)horizontalPulseCount); \
    if (_f != HF_OK) { if (!faultStep) faultStep = #call; return _f; }         \
  } while (0)

static Fault waitMs(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    if (abortFlag) return HF_ABORTED;
    delay(1);
  }
  return HF_OK;
}

// ==========================================
// Interlock helper + homing error log
// ==========================================
static bool atStation() {
  int h = horizontalPulseCount;
  if (abs(h - H_CONVEYOR) <= H_TOL) return true;
  for (uint8_t i = 0; i < 9; i++) if (abs(h - SLOTS[i].h) <= H_TOL) return true;
  return false;
}

// counts = encoder counter at the moment the reference switch was reached (ideal 0)
static void recordHomeErr(bool vertical, int counts) {
  if (!(homed || homingTrusted)) return;        // counters were meaningless before this homing
  int a = abs(counts);
  if (vertical) { homeErrVLast = counts; if (a > homeErrVMax) homeErrVMax = a; }
  else          { homeErrHLast = counts; if (a > homeErrHMax) homeErrHMax = a; }
  homeErrN++;
  if (verbose) say("  home_error %s %d counts\n", vertical ? "vertical" : "horizontal", counts);
}

// ==========================================
// Primitives (each returns a Fault)
// ==========================================
// --- Cantilever ---
static Fault cantileverFront() {
  if (stableTrue(cantFrontAtLimit, CANT_CONFIRM_MS)) return HF_OK;
  if (!homed)             return HF_NOT_HOMED;
  if (!atStation())       return HF_INTERLOCK_STATION;
  run(MOTOR_CANTILEVER_FWD, MOTOR_CANTILEVER_BWD);
  { uint32_t _t0 = millis();
    for (;;) {
      if (abortFlag) { allMotorsOff(); return HF_ABORTED; }
      if (millis() - _t0 > TO_CANTILEVER_MS) { allMotorsOff(); return HF_TIMEOUT; }
      if (cantFrontAtLimit() && stableTrue(cantFrontAtLimit, CANT_CONFIRM_MS)) break;
      delay(1);
    } }
  halt(MOTOR_CANTILEVER_FWD); delay(10);
  return HF_OK;
}

static Fault cantileverBack() {
  if (stableTrue(cantBackAtLimit, CANT_CONFIRM_MS)) return HF_OK;
  run(MOTOR_CANTILEVER_BWD, MOTOR_CANTILEVER_FWD);
  { uint32_t _t0 = millis();
    for (;;) {
      if (abortFlag) { allMotorsOff(); return HF_ABORTED; }
      if (millis() - _t0 > TO_CANTILEVER_MS) { allMotorsOff(); return HF_TIMEOUT; }
      if (cantBackAtLimit() && stableTrue(cantBackAtLimit, CANT_CONFIRM_MS)) break;
      delay(1);
    } }
  halt(MOTOR_CANTILEVER_BWD); delay(10);
  return HF_OK;
}

// --- Vertical axis ---
// Reference switches on GPIO 35/36 have NO internal pull resistor (input-only pins):
// a floating/noisy line can look "pressed". A home is accepted only if the switch
// stays pressed for REF_CONFIRM_MS. The motor is stopped at the first trigger and the
// switch is confirmed while standing still (a glitch resumes the move). The counter is
// zeroed at the trigger point, so the small coast after the stop does not shift slots.
const uint32_t REF_CONFIRM_MS = 25;
static Fault homeAxis(bool vertical) {
  bool (*atHome)() = vertical ? vertAtHome : horzAtHome;
  volatile int& cnt = vertical ? verticalPulseCount : horizontalPulseCount;
  volatile int8_t& dir = vertical ? verticalMoveDirection : horizontalMoveDirection;
  uint8_t on  = vertical ? MOTOR_VERT_UP : MOTOR_HORZ_TO_CONVEYOR;
  uint8_t opp = vertical ? MOTOR_VERT_DOWN : MOTOR_HORZ_TO_RACK;
  uint32_t to = vertical ? TO_VERT_MS : TO_HORZ_MS;
  if (stableTrue(atHome, REF_CONFIRM_MS)) { recordHomeErr(vertical, cnt); cnt = 0; return HF_OK; }
  dir = -1;
  run(on, opp);
  int trig = 0;
  uint32_t t0 = millis(), tp = t0;
  int last = cnt;
  for (;;) {
    if (abortFlag) { allMotorsOff(); dir = 0; return HF_ABORTED; }
    uint32_t now = millis();
    if (now - t0 > to) { allMotorsOff(); dir = 0; return HF_TIMEOUT; }
    int c = cnt;
    if (c != last) { last = c; tp = now; }
    else if (now - tp > STALL_MS) { allMotorsOff(); dir = 0; return HF_STALL; }
    if (atHome()) {
      halt(on);                          // stop at the FIRST trigger: no drive into the switch
      trig = cnt;
      if (stableTrue(atHome, REF_CONFIRM_MS)) break;   // confirm while standing still
      if (verbose) say("  ref glitch ignored (%s)\n", vertical ? "vertical" : "horizontal");
      run(on, opp);                      // it was a glitch: resume homing
      tp = millis();
    }
    delay(1);
  }
  halt(on);
  int over = cnt - trig;                 // counts travelled during the confirmation
  dir = 0;
  recordHomeErr(vertical, trig);
  cnt = over;                            // 0 = switch trigger point
  delay(10);
  return HF_OK;
}

static Fault vertHome() { return homeAxis(true); }

// Move to an absolute count, direction chosen automatically. Target 0 = home switch.
static Fault moveVertTo(int target) {
  if (target <= 0) return vertHome();
  if (!homed) return HF_NOT_HOMED;
  int c = verticalPulseCount;
  if (c < target) {
    verticalMoveDirection = 1;
    run(MOTOR_VERT_DOWN, MOTOR_VERT_UP);
    WAIT_AXIS(verticalPulseCount < target, verticalPulseCount, TO_VERT_MS);
    halt(MOTOR_VERT_DOWN); verticalMoveDirection = 0; delay(10);
  } else if (c > target) {
    verticalMoveDirection = -1;
    run(MOTOR_VERT_UP, MOTOR_VERT_DOWN);
    WAIT_AXIS(verticalPulseCount > target, verticalPulseCount, TO_VERT_MS);
    halt(MOTOR_VERT_UP); verticalMoveDirection = 0; delay(10);
  }
  return HF_OK;
}

// --- Horizontal axis ---
static Fault horzHome() {
  if (!cantBackAtLimit()) return HF_INTERLOCK_CANTILEVER;
  return homeAxis(false);
}

static Fault moveHorzTo(int target) {
  if (!homed) return HF_NOT_HOMED;
  int c = horizontalPulseCount;
  if (c == target) return HF_OK;                    // nothing to do (cantilever may be extended)
  if (!cantBackAtLimit()) return HF_INTERLOCK_CANTILEVER;
  if (c < target) {
    horizontalMoveDirection = 1;
    run(MOTOR_HORZ_TO_RACK, MOTOR_HORZ_TO_CONVEYOR);
    WAIT_AXIS(horizontalPulseCount < target, horizontalPulseCount, TO_HORZ_MS);
    halt(MOTOR_HORZ_TO_RACK); horizontalMoveDirection = 0; delay(10);
  } else {
    horizontalMoveDirection = -1;
    run(MOTOR_HORZ_TO_CONVEYOR, MOTOR_HORZ_TO_RACK);
    WAIT_AXIS(horizontalPulseCount > target, horizontalPulseCount, TO_HORZ_MS);
    halt(MOTOR_HORZ_TO_CONVEYOR); horizontalMoveDirection = 0; delay(10);
  }
  return HF_OK;
}

// --- Conveyor ---
// Wait for the box at the inside barrier, push it out until the outside barrier.
static Fault conveyorToOutside() {
  WAIT_WHILE(!boxInside(), TO_BOX_ARRIVE_MS, HF_NO_BOX);
  run(MOTOR_CONVEYOR_FWD, MOTOR_CONVEYOR_BWD);
  WAIT_WHILE(!boxOutside(), TO_CONVEYOR_MS, HF_TIMEOUT);
  halt(MOTOR_CONVEYOR_FWD);
  return HF_OK;
}

// Pull the box back until the inside barrier.
static Fault conveyorToInside() {
  run(MOTOR_CONVEYOR_BWD, MOTOR_CONVEYOR_FWD);
  WAIT_WHILE(!boxInside(), TO_CONVEYOR_MS, HF_TIMEOUT);
  halt(MOTOR_CONVEYOR_BWD); delay(10);
  return HF_OK;
}

// ==========================================
// High-level operations
// ==========================================
static Fault doHome() {
  homingTrusted = homed;      // was the position valid when this homing started?
  homed = false;
  TRY(cantileverBack());
  TRY(vertHome());
  TRY(horzHome());
  homed = true;
  homingTrusted = false;
  return HF_OK;
}

// rack -> conveyor outside. If the box is already on the cantilever
// (recovery), the rack pick-up part is skipped.
static Fault doRetrieve(int slot) {
  if (slot < 1 || slot > 9)  return HF_BAD_ARG;
  if (!homed)                return HF_NOT_HOMED;
  BoxLoc where = locOf(slot);
  if (where != LOC_RACK && where != LOC_ARM) return HF_STATE;
  if (othersOutOfRack(slot)) return HF_STATE;
  if (boxInside() || boxOutside()) return HF_CONVEYOR_BUSY;
  const Slot& s = SLOTS[slot - 1];

  if (where == LOC_RACK) {
    TRY(moveHorzTo(s.h));
    TRY(moveVertTo(s.vRet));
    TRY(cantileverFront());
    setLoc(slot, LOC_UNKNOWN);          // the box leaves the shelf somewhere in the next move
    TRY(moveVertTo(s.vStore));
    setLoc(slot, LOC_ARM);
    TRY(cantileverBack());
  }
  TRY(moveHorzTo(H_CONVEYOR));
  TRY(moveVertTo(V_CONVEYOR));
  setLoc(slot, LOC_UNKNOWN);            // the box is pushed onto the conveyor
  TRY(cantileverFront());
  TRY(conveyorToOutside());
  setLoc(slot, LOC_CONVEYOR);
  say("{\"event\":\"progress\",\"state\":\"box_outside\",\"slot\":%d}\n", slot);
  return HF_OK;
}

// empty box conveyor -> rack. From 'A' (recovery) only the rack part runs.
static Fault doReturn(int slot) {
  if (slot < 1 || slot > 9)  return HF_BAD_ARG;
  if (!homed)                return HF_NOT_HOMED;
  BoxLoc where = locOf(slot);
  if (where != LOC_CONVEYOR && where != LOC_ARM) return HF_STATE;
  if (othersOutOfRack(slot)) return HF_STATE;
  if (where == LOC_CONVEYOR && !boxInside() && !boxOutside()) return HF_NO_BOX;   // state says C, sensors disagree
  const Slot& s = SLOTS[slot - 1];

  if (where == LOC_CONVEYOR) {
    TRY(moveHorzTo(H_CONVEYOR));        // no-ops in the normal flow (already there);
    TRY(moveVertTo(V_CONVEYOR));        // needed when returning after a recovery
    TRY(conveyorToInside());
    TRY(cantileverFront());
    setLoc(slot, LOC_UNKNOWN);          // the box is lifted off the conveyor
    TRY(moveVertTo(V_RETURN_LIFT));
    setLoc(slot, LOC_ARM);
    TRY(cantileverBack());
    TRY(vertHome());
    TRY(horzHome());
  }
  TRY(moveHorzTo(s.h));
  TRY(moveVertTo(s.vStore));
  TRY(cantileverFront());
  setLoc(slot, LOC_UNKNOWN);            // the box is lowered onto the shelf
  TRY(moveVertTo(s.vRet));
  setLoc(slot, LOC_RACK);
  TRY(cantileverBack());
  return HF_OK;
}

// Diagnostic jog: run ONE motor briefly while sampling the cantilever switches,
// so a dead/flickering switch can be told apart from a weak/jammed motor
// without needing a successful homing first.
//   B/F  cantilever back/front  (stops early once its end switch has read
//        "reached" for 150 ms continuously; up to 8000 ms)
//   U/D  vertical up/down       L/C  horizontal toward rack/conveyor
//   I/O  conveyor inward/outward         (these: 50-3000 ms, default 300)
// Same interlocks as the real moves: L/C need the cantilever fully back, F
// needs a homed station position. U/D/L/C invalidate homing (run H after).
static Fault doJog(char which, int ms) {
  uint8_t on = 0, opp = 0;
  bool watchBack = false, watchFront = false, axisMove = false;
  int maxMs = 3000;
  switch (which) {
    case 'B': on = MOTOR_CANTILEVER_BWD;   opp = MOTOR_CANTILEVER_FWD;   watchBack = true;  maxMs = 8000; break;
    case 'F': on = MOTOR_CANTILEVER_FWD;   opp = MOTOR_CANTILEVER_BWD;   watchFront = true; maxMs = 8000; break;
    case 'U': on = MOTOR_VERT_UP;          opp = MOTOR_VERT_DOWN;        axisMove = true; break;
    case 'D': on = MOTOR_VERT_DOWN;        opp = MOTOR_VERT_UP;          axisMove = true; break;
    case 'L': on = MOTOR_HORZ_TO_RACK;     opp = MOTOR_HORZ_TO_CONVEYOR; axisMove = true; break;
    case 'C': on = MOTOR_HORZ_TO_CONVEYOR; opp = MOTOR_HORZ_TO_RACK;     axisMove = true; break;
    case 'I': on = MOTOR_CONVEYOR_BWD;     opp = MOTOR_CONVEYOR_FWD;     break;
    case 'O': on = MOTOR_CONVEYOR_FWD;     opp = MOTOR_CONVEYOR_BWD;     break;
    default:  return HF_BAD_ARG;
  }
  if (ms < 50) ms = 300;
  if (ms > maxMs) ms = maxMs;
  if ((which == 'L' || which == 'C') && !cantBackAtLimit()) return HF_INTERLOCK_CANTILEVER;
  if (which == 'F' && !(homed && atStation()))              return HF_INTERLOCK_STATION;
  if (axisMove) homed = false;

  bool b0 = rawHigh(REF_SWITCH_CANTILEVER_BACK), f0 = rawHigh(REF_SWITCH_CANTILEVER_FRONT);
  int changes = 0;
  int32_t stableSince = -1, reachedAt = -1;
  bool reached = false;
  uint32_t t0 = millis(), lastPrint = 0;
  run(on, opp);
  for (;;) {
    uint32_t now = millis() - t0;
    if (abortFlag) { allMotorsOff(); return HF_ABORTED; }
    bool b = rawHigh(REF_SWITCH_CANTILEVER_BACK), f = rawHigh(REF_SWITCH_CANTILEVER_FRONT);
    if (b != b0) { changes++; b0 = b; }
    if (f != f0) { changes++; f0 = f; }
    if (watchBack || watchFront) {
      bool hit = watchBack ? cantBackAtLimit() : cantFrontAtLimit();
      if (hit) {
        if (stableSince < 0) stableSince = (int32_t)now;
        if ((int32_t)now - stableSince >= 150) { reached = true; reachedAt = stableSince; break; }
      } else {
        stableSince = -1;
      }
    }
    if (now >= (uint32_t)ms) break;
    if (now - lastPrint >= 250) {
      lastPrint = now;
      say("{\"event\":\"jog_sample\",\"t\":%lu,\"cant_back\":%d,\"cant_front\":%d}\n", (unsigned long)now, b ? 1 : 0, f ? 1 : 0);
    }
    delay(5);
  }
  allMotorsOff();
  say("{\"event\":\"jog_end\",\"which\":\"%c\",\"ms\":%lu,\"reached\":%s,\"reached_at_ms\":%ld,\"cant_back\":%d,\"cant_front\":%d,\"switch_changes\":%d}\n",
      which, (unsigned long)(millis() - t0), reached ? "true" : "false", (long)reachedAt,
      rawHigh(REF_SWITCH_CANTILEVER_BACK) ? 1 : 0, rawHigh(REF_SWITCH_CANTILEVER_FRONT) ? 1 : 0, changes);
  return HF_OK;
}

// the old standalone sequence
static Fault doAuto() {
  if (!allInRack())                return HF_STATE;
  if (boxInside() || boxOutside()) return HF_CONVEYOR_BUSY;
  TRY(doHome());
  TRY(waitMs(HOMING_SETTLE_MS));
  for (uint8_t i = 0; i < 9; i++) {
    int slot = AUTO_ORDER[i];
    TRY(doRetrieve(slot));
    TRY(waitMs(GRABBER_PICK_WAIT_MS + AFTER_PICK_DELAY_MS));   // Grabber picks the piece
    TRY(doReturn(slot));
  }
  TRY(doHome());
  return HF_OK;
}

// ==========================================
// Command execution (runs in the motion task)
// ==========================================
static Fault runCommand(const Cmd& c) {
  switch (c.type) {
    case 'H': return doHome();
    case 'R': return doRetrieve(c.slot);
    case 'T': return doReturn(c.slot);
    case 'A': return doAuto();
    case 'J': return doJog(c.motor, c.ms);
  }
  return HF_BAD_ARG;
}

void executeAndReport(const Cmd& c) {
  faultStep = nullptr;
  motionStarted = false;
  homingTrusted = false;
  uint32_t t0 = millis();
  Fault f = runCommand(c);
  uint32_t dt = millis() - t0;
  allMotorsOff();
  lastFault = f;

  if (f == HF_OK) {
    say("{\"event\":\"done\",\"cmd\":\"%c\",\"slot\":%d,\"ms\":%lu,\"command_id\":\"%s\"}\n",
        c.type, c.slot, (unsigned long)dt, c.cmd_id);
  } else {
    if (motionStarted) homed = false;    // positions can no longer be trusted (box states are already conservative)
    char boxes[10]; boxesStr(boxes);
    say("{\"event\":\"fault\",\"cmd\":\"%c\",\"slot\":%d,\"code\":\"%s\",\"step\":\"%s\",\"ms\":%lu,\"homed\":%s,\"boxes\":\"%s\",\"command_id\":\"%s\"}\n",
        c.type, c.slot, faultName(f), faultStep ? faultStep : "-", (unsigned long)dt,
        homed ? "true" : "false", boxes, c.cmd_id);
  }
  busy = false;
}

void motionTask(void*) {
  Cmd c;
  for (;;) {
    if (xQueueReceive(cmdQueue, &c, portMAX_DELAY) == pdTRUE) executeAndReport(c);
  }
}

// ==========================================
// Serial console (runs in loop())
// ==========================================
static int buildStatusJson(char* out, size_t outSize) {
  char boxes[10]; boxesStr(boxes);
  const char* cant = cantFrontAtLimit() ? "front" : (cantBackAtLimit() ? "back" : "between");
  return snprintf(out, outSize,
      "{\"event\":\"status\",\"busy\":%s,\"homed\":%s,\"boxes\":\"%s\",\"carrying\":%d,\"v\":%d,\"h\":%d,"
      "\"cantilever\":\"%s\",\"box_inside\":%s,\"box_outside\":%s,\"last_fault\":\"%s\","
      "\"home_err\":{\"v_last\":%d,\"v_max\":%d,\"h_last\":%d,\"h_max\":%d,\"n\":%lu},\"verbose\":%s}\n",
      busy ? "true" : "false", homed ? "true" : "false", boxes, carryingBox(),
      (int)verticalPulseCount, (int)horizontalPulseCount, cant,
      boxInside() ? "true" : "false", boxOutside() ? "true" : "false", faultName((Fault)lastFault),
      (int)homeErrVLast, (int)homeErrVMax, (int)homeErrHLast, (int)homeErrHMax, (unsigned long)homeErrN,
      verbose ? "true" : "false");
}

static void printStatus() {
  char buf[420];
  buildStatusJson(buf, sizeof buf);
  say("%s", buf);
}

static void printHelp() {
  say("Commands: H | R <1-9> | T <1-9> | A | S | ? | V | L <1-9> <R|C|A|?> | L * R | D (raw switches) | J <B|F|U|D|L|C|I|O> [ms]\n");
}

// Raw read of every switch/barrier, plus 200 ms of sampling on the two
// cantilever switches to expose flicker (loose wire / noise). No motion.
static void printRaw() {
  int backHi = 0, frontHi = 0, backChg = 0, frontChg = 0, vHi = 0, vChg = 0, hHi = 0, hChg = 0;
  bool bl = rawHigh(REF_SWITCH_CANTILEVER_BACK), fl = rawHigh(REF_SWITCH_CANTILEVER_FRONT);
  bool vl = rawHigh(REF_SWITCH_VERTICAL), hl = rawHigh(REF_SWITCH_HORIZONTAL);
  for (int i = 0; i < 100; i++) {
    bool b = rawHigh(REF_SWITCH_CANTILEVER_BACK), f = rawHigh(REF_SWITCH_CANTILEVER_FRONT);
    bool v = rawHigh(REF_SWITCH_VERTICAL), h = rawHigh(REF_SWITCH_HORIZONTAL);
    if (b) backHi++;
    if (f) frontHi++;
    if (v) vHi++;
    if (h) hHi++;
    if (b != bl) { backChg++; bl = b; }
    if (f != fl) { frontChg++; fl = f; }
    if (v != vl) { vChg++; vl = v; }
    if (h != hl) { hChg++; hl = h; }
    delay(2);
  }
  say("{\"event\":\"raw\",\"cant_back\":%d,\"cant_front\":%d,\"vert_home\":%d,\"horz_home\":%d,"
      "\"box_inside\":%d,\"box_outside\":%d,\"v\":%d,\"h\":%d,"
      "\"back_hi\":%d,\"back_chg\":%d,\"front_hi\":%d,\"front_chg\":%d,"
      "\"vert_hi\":%d,\"vert_chg\":%d,\"horz_hi\":%d,\"horz_chg\":%d}\n",
      rawHigh(REF_SWITCH_CANTILEVER_BACK) ? 1 : 0, rawHigh(REF_SWITCH_CANTILEVER_FRONT) ? 1 : 0, vertAtHome() ? 1 : 0, horzAtHome() ? 1 : 0,
      boxInside() ? 1 : 0, boxOutside() ? 1 : 0, (int)verticalPulseCount, (int)horizontalPulseCount,
      backHi, backChg, frontHi, frontChg, vHi, vChg, hHi, hChg);
}

static void reject(char type, int arg, const char* why, const char* cmd_id = "") {
  say("{\"event\":\"rejected\",\"cmd\":\"%c\",\"arg\":%d,\"code\":\"%s\",\"command_id\":\"%s\"}\n",
      type, arg, why, cmd_id ? cmd_id : "");
}

static void doStopWithId(const char* id) {
  allMotorsOff();
  abortFlag = true;
  say("{\"event\":\"stop\",\"command_id\":\"%s\"}\n", (id && id[0]) ? id : "");
}
static void doStop() { doStopWithId(""); }

static void submit(char type, int slot, const char* cmd_id = "", char motor = 0, int ms = 0) {
  if ((type == 'R' || type == 'T') && (slot < 1 || slot > 9)) { reject(type, slot, "BAD_ARG", cmd_id); return; }
  if (type == 'J' && (!motor || !strchr("BFUDLCIO", motor))) { reject(type, ms, "BAD_ARG", cmd_id); return; }
  if (busy) { reject(type, slot, "BUSY", cmd_id); return; }
  Cmd c = { type, slot, {0}, motor, ms };
  if (cmd_id && cmd_id[0]) strncpy(c.cmd_id, cmd_id, CMDID_LEN);
  abortFlag = false;
  busy = true;
  say("{\"event\":\"started\",\"cmd\":\"%c\",\"slot\":%d,\"command_id\":\"%s\"}\n", type, slot, c.cmd_id);
  if (xQueueSend(cmdQueue, &c, 0) != pdPASS) { busy = false; reject(type, slot, "QUEUE_FULL", cmd_id); }
}

// Operator declares where a box really is (checked against the light barriers)
static void declareBox(int box, bool all, char l) {
  BoxLoc loc;
  switch (l) {
    case 'R': loc = LOC_RACK; break;
    case 'C': loc = LOC_CONVEYOR; break;
    case 'A': loc = LOC_ARM; break;
    case '?': loc = LOC_UNKNOWN; break;
    default:  reject('L', box, "BAD_ARG"); return;
  }
  if (busy) { reject('L', box, "BUSY"); return; }
  if (!all && (box < 1 || box > 9)) { reject('L', box, "BAD_ARG"); return; }
  if (all && loc != LOC_RACK && loc != LOC_UNKNOWN) { reject('L', 0, "BAD_ARG"); return; }
  bool sensorBox = boxInside() || boxOutside();
  if (loc == LOC_CONVEYOR && !sensorBox) { reject('L', box, "SENSOR_MISMATCH"); return; }   // no box detected on the conveyor
  if (all && loc == LOC_RACK && sensorBox) { reject('L', 0, "SENSOR_MISMATCH"); return; }  // a box IS on the conveyor
  if (!all && (loc == LOC_CONVEYOR || loc == LOC_ARM)) {
    for (int j = 1; j <= 9; j++)
      if (j != box && (locOf(j) == LOC_CONVEYOR || locOf(j) == LOC_ARM)) { reject('L', box, "CONFLICT"); return; }
  }
  if (all) { for (int i = 1; i <= 9; i++) setLoc(i, loc); }
  else     { setLoc(box, loc); }
  printStatus();
}

// ==========================================
// MQTT - tiny manual JSON field extraction (flat objects only, no nesting).
// Kept dependency-free (no ArduinoJson) since the command schema is fixed
// and small; safe against a missing field (helpers just return false/no-op).
// ==========================================
static bool jsonFindString(const char* json, const char* key, char* out, size_t outSize) {
  char pat[24]; snprintf(pat, sizeof pat, "\"%s\"", key);
  const char* p = strstr(json, pat);
  if (!p) return false;
  p = strchr(p + strlen(pat), ':');
  if (!p) return false;
  p++;
  while (*p == ' ') p++;
  if (*p != '"') return false;
  p++;
  size_t i = 0;
  while (*p && *p != '"' && i < outSize - 1) out[i++] = *p++;
  out[i] = 0;
  return true;
}
static bool jsonFindInt(const char* json, const char* key, int* out) {
  char pat[24]; snprintf(pat, sizeof pat, "\"%s\"", key);
  const char* p = strstr(json, pat);
  if (!p) return false;
  p = strchr(p + strlen(pat), ':');
  if (!p) return false;
  p++;
  while (*p == ' ') p++;
  *out = atoi(p);
  return true;
}
static bool jsonFindBool(const char* json, const char* key, bool* out) {
  char pat[24]; snprintf(pat, sizeof pat, "\"%s\"", key);
  const char* p = strstr(json, pat);
  if (!p) return false;
  p = strchr(p + strlen(pat), ':');
  if (!p) return false;
  p++;
  while (*p == ' ') p++;
  *out = (strncmp(p, "true", 4) == 0);
  return true;
}

// Runs inside mqttClient.loop() (Arduino loop() task, already holding
// mqttMutex - recursive, so calls below into say()/submit() are safe).
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  if (length >= 250) { reject('?', 0, "PAYLOAD_TOO_LONG"); return; }
  char buf[256];
  memcpy(buf, payload, length);
  buf[length] = 0;

  char cmdType[4] = {0};
  char cmdId[CMDID_LEN + 1] = {0};
  char locStr[4] = {0};
  char whichStr[4] = {0};
  int  slot = 0;
  int  ms   = 0;
  bool all  = false;

  jsonFindString(buf, "cmd", cmdType, sizeof cmdType);
  jsonFindString(buf, "command_id", cmdId, sizeof cmdId);
  jsonFindInt(buf, "slot", &slot);
  jsonFindInt(buf, "ms", &ms);
  jsonFindBool(buf, "all", &all);
  jsonFindString(buf, "loc", locStr, sizeof locStr);
  jsonFindString(buf, "which", whichStr, sizeof whichStr);

  if (!cmdType[0]) { reject('?', 0, "BAD_JSON", cmdId); return; }
  char c = (char)toupper((unsigned char)cmdType[0]);

  if (isDuplicateCmdId(cmdId)) { reject(c, slot, "DUPLICATE", cmdId); return; }

  switch (c) {
    case 'S':
      rememberCmdId(cmdId);
      doStopWithId(cmdId);
      break;
    case 'H': case 'A':
      rememberCmdId(cmdId);
      submit(c, 0, cmdId);
      break;
    case 'R': case 'T':
      rememberCmdId(cmdId);
      submit(c, slot, cmdId);
      break;
    case 'D':
      rememberCmdId(cmdId);
      printRaw();
      break;
    case 'J': {
      char which = whichStr[0] ? (char)toupper((unsigned char)whichStr[0]) : 0;
      rememberCmdId(cmdId);
      submit('J', 0, cmdId, which, ms);
      break;
    }
    case 'L': {
      rememberCmdId(cmdId);
      char loc = locStr[0] ? (char)toupper((unsigned char)locStr[0]) : '?';
      declareBox(slot, all, loc);
      break;
    }
    default:
      reject(c, 0, "BAD_ARG", cmdId);
  }
}

static void publishHeartbeat() {
  char buf[420];
  buildStatusJson(buf, sizeof buf);
  if (xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC_STATUS, (const uint8_t*)buf, (unsigned int)strlen(buf), true);
    xSemaphoreGiveRecursive(mqttMutex);
  }
}

// Fully non-blocking: called once per loop() iteration. Never delays motion
// or Serial handling even while WiFi/MQTT are down or reconnecting.
static void maintainNetwork() {
  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - lastWifiAttempt > WIFI_RETRY_MS) {
      lastWifiAttempt = millis();
      WiFi.disconnect();
      WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
      WiFi.setSleep(false);   // re-assert after reconnect - some cores reset this on begin()
      say("{\"event\":\"wifi_connecting\"}\n");
    }
    return;   // don't touch MQTT until WiFi is up
  }
  if (xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (!mqttClient.connected()) {
      if (millis() - lastMqttAttempt > MQTT_RETRY_MS) {
        lastMqttAttempt = millis();
        say("{\"event\":\"mqtt_connecting\"}\n");
        if (mqttClient.connect(MQTT_CLIENT_ID, nullptr, nullptr, TOPIC_LWT, 1, true, "offline")) {
          mqttClient.subscribe(TOPIC_CMD);
          mqttClient.publish(TOPIC_LWT, "online", true);
          say("{\"event\":\"mqtt_connected\"}\n");
        } else {
          say("{\"event\":\"mqtt_connect_failed\",\"rc\":%d}\n", mqttClient.state());
        }
      }
    } else {
      mqttClient.loop();
    }
    xSemaphoreGiveRecursive(mqttMutex);
  }
}

void handleLine(char* line) {
  while (*line == ' ') line++;
  if (!*line) return;
  char c = (char)toupper((unsigned char)*line);
  int arg = atoi(line + 1);
  switch (c) {
    case 'S': doStop(); break;
    case '?': printStatus(); break;
    case 'V': verbose = !verbose; say("{\"event\":\"verbose\",\"value\":%s}\n", verbose ? "true" : "false"); break;
    case 'L': {
      char* p = line + 1;
      while (*p == ' ') p++;
      bool all = false; int box = 0;
      if (*p == '*') { all = true; p++; }
      else { box = atoi(p); while (isdigit((unsigned char)*p)) p++; }
      while (*p == ' ') p++;
      declareBox(box, all, (char)toupper((unsigned char)*p));
      break;
    }
    case 'H': case 'A': submit(c, 0); break;
    case 'R': case 'T': submit(c, arg); break;
    case 'D': printRaw(); break;
    case 'J': {
      char* p = line + 1;
      while (*p == ' ') p++;
      char which = (char)toupper((unsigned char)*p);
      if (*p) p++;
      while (*p == ' ') p++;
      submit('J', 0, "", which, atoi(p));
      break;
    }
    default: printHelp(); break;
  }
}

// ==========================================
// Arduino entry points
// ==========================================
void setup() {
  Serial.begin(115200);
  printMutex = xSemaphoreCreateMutex();
  mqttMutex  = xSemaphoreCreateRecursiveMutex();

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);   // disable WiFi modem-sleep: it was adding 100s-1000+ms of
                          // scheduling jitter to the motion/encoder timing loops
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  mqttClient.setServer(MQTT_HOST, MQTT_PORT);
  mqttClient.setCallback(mqttCallback);
  mqttClient.setBufferSize(512);
  lastWifiAttempt = millis();

  pinMode(REF_SWITCH_HORIZONTAL, INPUT); pinMode(LIGHT_BARRIER_INSIDE, INPUT);
  pinMode(LIGHT_BARRIER_OUTSIDE, INPUT); pinMode(REF_SWITCH_VERTICAL, INPUT);
  pinMode(ENCODER_HORZ_IMP1, INPUT); pinMode(ENCODER_HORZ_IMP2, INPUT);
  pinMode(ENCODER_VERT_IMP1, INPUT); pinMode(ENCODER_VERT_IMP2, INPUT);
  pinMode(REF_SWITCH_CANTILEVER_FRONT, INPUT_PULLDOWN); pinMode(REF_SWITCH_CANTILEVER_BACK, INPUT_PULLDOWN);

  for (uint8_t i = 0; i < 8; i++) pinMode(ALL_MOTORS[i], OUTPUT);
  allMotorsOff();   // every motor OFF at start

  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP1), handleVerticalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP2), handleVerticalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP1), handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP2), handleHorizontalEncoder, CHANGE);

  stateLoad();
  cmdQueue = xQueueCreate(1, sizeof(Cmd));
  xTaskCreatePinnedToCore(motionTask, "motion", 8192, NULL, 2, NULL, 1);

  say("{\"event\":\"boot\",\"station\":\"HBW\",\"homed\":false}\n");
  printStatus();
  printHelp();
}

void loop() {
  maintainNetwork();
  if (millis() - lastHeartbeat > HEARTBEAT_MS) { lastHeartbeat = millis(); publishHeartbeat(); }

  static char buf[32];
  static uint8_t n = 0;
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (n == 0 && (ch == 's' || ch == 'S')) { doStop(); continue; }   // instant STOP, no Enter needed
    if (ch == '\n' || ch == '\r') {
      if (n) { buf[n] = 0; handleLine(buf); n = 0; }
    } else if (n < sizeof(buf) - 1) {
      buf[n++] = ch;
    }
  }
  delay(1);
}
