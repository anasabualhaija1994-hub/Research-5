#!/usr/bin/env python3
"""
Analysis of the physical check of the post-review fixes (PROTOCOL.md section 5).
Everything is computed from raw_mqtt.csv (one clock: the logger's); e2e.csv is NOT used for timing because
it subtracts n8n timestamps from the logger clock (clocks are not synchronised).

  python analyze_review_check.py review_check/raw_mqtt.csv [out_dir]

Experiment 1  stop during the preflight   (stop_in_preflight.py: job ids pfstop-run-* / pfstop-stop-*)
Experiment 2  stop words from the chat    (n8n-stop-* jobs that abort a running cli-run-* job)
Experiment 3  a station goes offline during a run (oven/lwt = offline while a job is running)
"""
import csv
import json
import os
import sys

STATIONS = ("hbw", "grabber", "oven", "colorsorter")
path = sys.argv[1] if len(sys.argv) > 1 else "review_check/raw_mqtt.csv"
out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(path)), "analysis")
os.makedirs(out, exist_ok=True)

rows = []
for r in csv.DictReader(open(path, encoding="utf-8")):
    r["t"] = float(r["t_unix"])
    rows.append(r)
rows.sort(key=lambda r: r["t"])


def js(r):
    try:
        return json.loads(r["payload"])
    except ValueError:
        return {}


def station_of(topic):
    p = topic.split("/")
    return p[1] if len(p) > 1 and p[1] in STATIONS else None


def motion_cmds(t_from, t_to):
    """station commands other than STOP published in (t_from, t_to]"""
    return [(r["topic"], js(r).get("cmd")) for r in rows
            if t_from < r["t"] <= t_to and r["topic"].endswith("/cmd") and station_of(r["topic"])
            and js(r).get("cmd") != "S"]


def stop_confirmations(t0, window=2.0):
    """ms from t0 to the first 'stop' event of each station"""
    got = {}
    for r in rows:
        if t0 <= r["t"] <= t0 + window and r["topic"].endswith("/event") and station_of(r["topic"]):
            if js(r).get("event") == "stop":
                got.setdefault(station_of(r["topic"]), round((r["t"] - t0) * 1000))
    return got


def orch_events(job_id):
    return [(r["t"], js(r)) for r in rows if r["topic"] == "factory/orchestrator/event" and js(r).get("job_id") == job_id]


result = []

# ---- experiment 1 ------------------------------------------------------------------------------------------
for r in rows:
    p = js(r)
    if r["topic"] == "factory/orchestrator/cmd" and p.get("cmd") == "run" and str(p.get("job_id", "")).startswith("pfstop-run-"):
        run_id, t_run = p["job_id"], r["t"]
        stop = next((x for x in rows if x["topic"] == "factory/orchestrator/cmd" and x["t"] >= t_run
                     and js(x).get("cmd") == "stop" and str(js(x).get("job_id", "")).startswith("pfstop-stop-")), None)
        if not stop:
            continue
        ev = orch_events(run_id)
        names = [e["event"] for _, e in ev]
        rej = next((e for _, e in ev if e["event"] == "job_rejected"), {})
        t_end = max([t for t, _ in ev] + [stop["t"]]) + 1.0
        mot = motion_cmds(t_run, t_end)
        ok = rej.get("reason") == "stopped" and "job_accepted" not in names and not mot
        conf = stop_confirmations(stop["t"])
        result.append({"experiment": 1, "case": run_id, "stop_after_run_ms": round((stop["t"] - t_run) * 1000),
                       "outcome": rej.get("reason", names), "job_accepted": "job_accepted" in names,
                       "motion_cmds_after_run": len(mot),
                       "stop_confirm_ms_min": min(conf.values()) if conf else "", "stop_confirm_ms_max": max(conf.values()) if conf else "",
                       "stations_confirmed": len(conf), "pass": ok})

# ---- experiment 2 ------------------------------------------------------------------------------------------
for r in rows:
    p = js(r)
    if r["topic"] == "factory/orchestrator/event" and p.get("event") == "stopped" and str(p.get("job_id", "")).startswith("n8n-stop-") \
            and p.get("aborted_job"):
        t_stop = r["t"]
        # first station S command of this stop (published together with the event)
        t_s = min([x["t"] for x in rows if t_stop - 0.05 <= x["t"] <= t_stop + 0.01 and x["topic"].endswith("/cmd")
                   and station_of(x["topic"]) and js(x).get("cmd") == "S"] or [t_stop])
        ev = orch_events(p["aborted_job"])
        failed = next((e for _, e in ev if e["event"] == "job_failed"), {})
        mot = motion_cmds(t_stop, t_stop + 5.0)
        conf = stop_confirmations(t_s)
        hbw_abort = next((round((x["t"] - t_s) * 1000) for x in rows if t_s <= x["t"] <= t_s + 2 and x["topic"] == "factory/hbw/event"
                          and js(x).get("code") == "ABORTED"), "")
        result.append({"experiment": 2, "case": p["job_id"], "aborted_job": p["aborted_job"],
                       "outcome": failed.get("error", ""), "motion_cmds_after_stop": len(mot),
                       "stop_confirm_ms_min": min(conf.values()) if conf else "", "stop_confirm_ms_max": max(conf.values()) if conf else "",
                       "stations_confirmed": len(conf), "hbw_aborted_ms": hbw_abort,
                       "pass": failed.get("error") == "stop requested" and not mot and len(conf) == 4})

# ---- experiment 3 ------------------------------------------------------------------------------------------
for r in rows:
    if r["topic"].endswith("/lwt") and station_of(r["topic"]) and r["payload"] == "offline":
        st, t_lwt = station_of(r["topic"]), r["t"]
        failed = next(((t, e) for t, e in
                       [(x["t"], js(x)) for x in rows if t_lwt <= x["t"] <= t_lwt + 5 and x["topic"] == "factory/orchestrator/event"]
                       if e.get("event") == "job_failed" and "offline" in str(e.get("error", ""))), None)
        if not failed:
            continue
        acc = max((x for x in rows if x["t"] < t_lwt and x["topic"] == "factory/orchestrator/event"
                   and js(x).get("event") == "job_accepted" and js(x).get("job_id") == failed[1]["job_id"]), key=lambda x: x["t"])
        beats = [x["t"] for x in rows if x["t"] < t_lwt and x["topic"] == f"factory/{st}/status"]
        first_s = min([x["t"] for x in rows if t_lwt <= x["t"] <= t_lwt + 1 and x["topic"].endswith("/cmd")
                       and station_of(x["topic"]) and js(x).get("cmd") == "S"] or [t_lwt])
        conf = stop_confirmations(first_s)
        mot = motion_cmds(t_lwt, t_lwt + 15)
        result.append({"experiment": 3, "case": failed[1]["job_id"], "station_offline": st,
                       "outcome": failed[1].get("error"), "job_running_s_before_lwt": round(t_lwt - acc["t"], 1),
                       "last_heartbeat_to_lwt_s": round(t_lwt - beats[-1], 1) if beats else "",
                       "lwt_to_stop_ms": round((first_s - t_lwt) * 1000), "lwt_to_job_failed_ms": round((failed[0] - t_lwt) * 1000),
                       "motion_cmds_after_lwt": len(mot), "stop_confirm_ms_min": min(conf.values()) if conf else "",
                       "stop_confirm_ms_max": max(conf.values()) if conf else "", "stations_confirmed": len(conf),
                       "pass": not mot and len(conf) >= 3})

cols = []
for x in result:
    for k in x:
        if k not in cols:
            cols.append(k)
with open(os.path.join(out, "review_check_summary.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(result)
for x in result:
    print({k: v for k, v in x.items()})
print()
for e in (1, 2, 3):
    xs = [x for x in result if x["experiment"] == e]
    print(f"experiment {e}: {sum(1 for x in xs if x['pass'])}/{len(xs)} pass")
