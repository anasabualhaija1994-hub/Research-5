# Prompt ablation of the count rule

Workflows: `workflow_ablation_no_count.json` (webhook `factory-intent-no-count`) and
`workflow_ablation_explicit_count.json` (webhook `factory-intent-explicit-count`), imported into n8n
next to the main workflow (webhook `factory-intent`), with the same OpenRouter credential and `BASE`.
The factory was idle, homed and had all nine boxes in the rack. The webhook is always a dry-run.

```
cd benchmark
python benchmark_runner.py --url http://localhost/webhook/factory-intent                --cases ablation/cases_ablation.json --repeats 3 --out ablation/results_original_rerun.csv
python benchmark_runner.py --url http://localhost/webhook/factory-intent-no-count       --cases ablation/cases_ablation.json --repeats 3 --out ablation/results_no_count.csv
python benchmark_runner.py --url http://localhost/webhook/factory-intent-explicit-count --cases ablation/cases_ablation.json --repeats 3 --out ablation/results_explicit_count.csv
cd ablation && python analyze_ablation.py results_original_rerun.csv results_no_count.csv results_explicit_count.csv
```

## Released workflow on the full benchmark

The remaining 110 commands were run on the same webhook (`factory-intent-explicit-count`, identical to the
released workflow) and merged with `results_explicit_count.csv` into `results_released_prompt.csv`
(140 commands x 6 models x 3 repetitions):

```
python benchmark_runner.py --url http://localhost/webhook/factory-intent-explicit-count --cases ablation/cases_rest.json --repeats 3 --out ablation/results_explicit_count_rest.csv
python analyze_results.py --results ablation/results_released_prompt.csv --out ablation/analysis_released
```
