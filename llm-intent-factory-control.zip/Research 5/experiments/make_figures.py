"""Figures for the paper. python make_figures.py <results_dir> <benchmark_table_overall.csv> <out_dir>"""
import csv
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import pandas as pd

RES, BENCH, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#ffffff"
S1, S2, S3, S4 = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False})


# ---------------------------------------------------------------- Fig 1 architecture
def box(ax, x, y, w, h, title, lines, fc, ec=INK2, dashed=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec, lw=1.1,
                                ls="--" if dashed else "-"))
    ax.text(x + w / 2, y + h - 0.16, title, ha="center", va="top", fontsize=8.6, weight="bold", color=INK)
    for i, ln in enumerate(lines):
        ax.text(x + w / 2, y + h - 0.5 - i * 0.28, ln, ha="center", va="top", fontsize=7.2, color=INK2)


def arrow(ax, a, b, txt="", off=(0, 0.12), both=False):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="<|-|>" if both else "-|>", mutation_scale=10, lw=1.1, color=INK2))
    if txt:
        ax.text((a[0] + b[0]) / 2 + off[0], (a[1] + b[1]) / 2 + off[1], txt, ha="center", fontsize=6.9, color=INK2,
                style="italic")


fig, ax = plt.subplots(figsize=(7.2, 4.6))
ax.set_xlim(0, 14.4); ax.set_ylim(0, 9.2); ax.axis("off")
box(ax, 0.1, 6.5, 2.6, 1.5, "Operator", ["chat, Arabic or English", "e.g. \"run boxes 2 and 3\""], "#f3f2ee")
# n8n frame
ax.add_patch(FancyBboxPatch((3.1, 4.55), 11.1, 3.85, boxstyle="round,pad=0.02,rounding_size=0.1", fc="none",
                            ec=INK2, lw=0.8, ls=":"))
ax.text(3.3, 8.25, "n8n low-code workflow", fontsize=8, color=INK2, weight="bold", va="top")
box(ax, 3.4, 6.3, 2.3, 1.35, "Normalize", ["+ live factory status", "stop words → STOP", "(no LLM call)"], "#f3f2ee")
box(ax, 6.0, 6.0, 2.9, 1.65, "LLM intent parser", ["any OpenRouter model", "JSON intent only", "temperature 0"], "#e8f0fb", ec=S1, dashed=True)
box(ax, 9.25, 6.0, 2.6, 1.65, "Layer 1 validator", ["whitelist, types, 1..9", "rack/idle checks", "fail-closed → clarify"], "#fdeee6", ec=S2)
box(ax, 12.15, 6.0, 1.95, 1.65, "Reply", ["result or", "reason"], "#f3f2ee")
ax.text(7.45, 5.30, "LLM proposes; deterministic code decides", ha="center", va="center", fontsize=7.0, color=S1, style="italic")
box(ax, 3.6, 2.75, 7.6, 1.45, "Layer 2: orchestrator service (Python)",
    ["whitelist + slot envelope · preflight (online, idle, homed, rack, gripper)",
     "pipelined scheduling · station fault or offline → STOP to all stations"], "#fdeee6", ec=S2)
# MQTT bus
ax.plot([0.3, 14.1], [2.15, 2.15], color=INK2, lw=2.2, solid_capstyle="round")
ax.text(0.3, 2.3, "MQTT broker (Mosquitto)", fontsize=7.0, ha="left",
        color=INK2, va="bottom")
st = ["HBW", "Grabber", "Oven + saw", "Colour sorter"]
for i, n in enumerate(st):
    x = 0.1 + i * 3.6
    box(ax, x, 0.25, 3.3, 1.4, f"{n} (ESP32)", ["Layer 3: interlocks,", "timeouts, stall, STOP"], "#eef8f3", ec=S3)
    arrow(ax, (x + 1.65, 1.65), (x + 1.65, 2.1), both=True)
arrow(ax, (7.7, 2.75), (7.7, 2.15), both=True)
arrow(ax, (10.3, 6.0), (9.3, 4.2), "validated request", off=(-1.25, -0.3))
arrow(ax, (11.2, 3.9), (13.1, 6.0), "events / result", off=(0.85, -0.25))
# request flow inside the workflow
arrow(ax, (2.7, 7.1), (3.4, 7.1))
arrow(ax, (5.7, 6.9), (6.0, 6.9))
arrow(ax, (8.9, 6.85), (9.25, 6.85))
arrow(ax, (11.85, 6.85), (12.15, 6.85))
arrow(ax, (4.4, 4.2), (4.4, 6.3))
ax.text(4.5, 5.55, "live status", ha="left", fontsize=6.9, color=INK2, style="italic")
# deterministic stop path: Normalize -> orchestrator, bypassing the LLM and Layer 1
ax.add_patch(FancyArrowPatch((3.85, 6.3), (3.85, 4.2), arrowstyle="-|>", mutation_scale=10, lw=1.3, color=S2))
ax.text(3.0, 5.05, "stop words:\nstop sent directly\n(no LLM, no Layer 1)", ha="right", va="center", fontsize=6.9, color=S2, style="italic")
# reply back to the operator (outside the workflow frame)
ax.plot([13.1, 13.1, 1.4], [7.65, 8.85, 8.85], color=INK2, lw=1.1)
arrow(ax, (1.4, 8.85), (1.4, 8.0))
ax.text(7.3, 8.95, "reply in the chat (result, question or reason for refusal)", ha="center", fontsize=6.9, color=INK2, style="italic")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "fig1_architecture.png"), dpi=300)
plt.close(fig)

# ---------------------------------------------------------------- Fig 2 benchmark accuracy vs latency
b = pd.read_csv(BENCH)
fig, ax = plt.subplots(figsize=(6.0, 3.4))
open_w = {"DeepSeek V4.1 Flash"}
for _, r in b.iterrows():
    x, y = r.latency_median_ms / 1000, r["exact_acc_%"]
    ax.errorbar(x, y, yerr=[[y - r.exact_CI95_lo], [r.exact_CI95_hi - y]], fmt="o" if r.model not in open_w else "s",
                ms=7, color=S1, mfc=S1 if r.model not in open_w else SURF, mec=S1, ecolor=INK2, elinewidth=0.9, capsize=2.5,
                zorder=3)
    pos = {"GPT-6.1 Sol": (3.55, 100.2, "left"), "Claude Sonnet 5.5": (2.2, 100.2, "right"),
           "GPT-6 Luna": (2.95, 96.4, "left"), "DeepSeek V4.1 Flash": (1.15, 98.3, "left")}
    if r.model in pos:
        tx, ty, ha = pos[r.model]
        ax.annotate(r.model.replace("V4.1 Flash", "V4.1\nFlash"), (x, y), (tx, ty), fontsize=7.6, color=INK, ha=ha, va="center",
                    arrowprops=dict(arrowstyle="-", color=INK2, lw=0.6, shrinkA=2, shrinkB=5))
    else:
        ax.text(x + 0.15, y + 0.3, r.model, fontsize=7.6, color=INK)
ax.set_xlabel("Median latency per command (s)")
ax.set_ylabel("Exact-match accuracy (%)")
ax.set_ylim(93, 100.5); ax.set_xlim(0, 7); ax.set_yticks(range(93, 101))
ax.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
ax.text(6.95, 93.25, "open square = open-weight model; bars = Wilson 95% CI over the 140 commands",
        ha="right", fontsize=6.8, color=INK2)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig2_benchmark.png"), dpi=300); plt.close(fig)


# ---------------------------------------------------------------- Fig 3 Gantt seq vs pipe
def intervals(run_dir, t_from=None):
    rows = list(csv.reader(open(os.path.join(RES, run_dir, "raw_mqtt.csv"), encoding="utf-8")))[1:]
    js = lambda x: (json.loads(x) if x.strip().startswith("{") else {})
    t0 = None
    for r in rows:
        if r[2] == "factory/orchestrator/event":
            try:
                e = json.loads(r[4])
            except Exception:
                continue
            if e.get("event") == "job_accepted" and e.get("cmd") == "run":
                t0 = float(r[0]); break
    out = {k: [] for k in ("hbw", "grabber", "oven", "colorsorter")}
    open_, wait_ = {}, {}
    for r in rows:
        t = float(r[0]); p = r[2].split("/")
        if len(p) != 3 or p[1] not in out or p[2] != "event" or t < t0 - 1:
            continue
        try:
            e = js(r[4])
        except Exception:
            continue
        ev = e.get("event")
        if ev == "started" and e.get("cmd") != "H":
            open_[p[1]] = t; wait_[p[1]] = None
        elif ev == "phase" and p[1] in open_:
            if e.get("phase") == "wait_piece":
                wait_[p[1]] = t
            elif wait_.get(p[1]) is not None:
                out[p[1]].append((wait_[p[1]] - t0, t - wait_[p[1]], "wait")); wait_[p[1]] = None
                open_[p[1]] = t
        elif ev in ("done", "fault", "stop") and p[1] in open_:
            s = open_.pop(p[1])
            if wait_.get(p[1]) is not None:
                out[p[1]].append((wait_[p[1]] - t0, t - wait_[p[1]], "wait"))
            else:
                out[p[1]].append((s - t0, t - s, "work"))
    return out


fig, axs = plt.subplots(2, 1, figsize=(7.0, 3.6), sharex=True)
lab = {"hbw": "HBW", "grabber": "Grabber", "oven": "Oven", "colorsorter": "Sorter"}
col = {"hbw": S1, "grabber": S2, "oven": S3, "colorsorter": S4}
for ax, (rd, title) in zip(axs, [("seq_r1", "Sequential (one job per piece)"), ("pipe_r1", "Pipelined")]):
    iv = intervals(rd)
    for i, st in enumerate(["colorsorter", "oven", "grabber", "hbw"]):
        work = [(a, w) for a, w, k in iv[st] if k == "work" and a < 330]
        wait = [(a, w) for a, w, k in iv[st] if k == "wait" and a < 330]
        ax.broken_barh(wait, (i - 0.32, 0.64), facecolors="none", edgecolors=col[st], hatch="////", lw=0.6)
        ax.broken_barh(work, (i - 0.32, 0.64), facecolors=col[st], edgecolors=SURF, lw=1.0)
    ax.set_yticks(range(4)); ax.set_yticklabels([lab[s] for s in ["colorsorter", "oven", "grabber", "hbw"]])
    ax.set_title(title, fontsize=8.6, loc="left", color=INK)
    ax.grid(True, axis="x", color=GRID, lw=0.6); ax.set_axisbelow(True)
    ax.set_xlim(0, 320)
axs[1].set_xlabel("Time since the (first) job was accepted (s) - first 320 s of the 9-piece order")
axs[0].text(320, 3.75, "solid = executing a command; hatched = station waiting for a piece", ha="right", fontsize=6.8,
            color=INK2)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig3_gantt.png"), dpi=300); plt.close(fig)

# ---------------------------------------------------------------- Fig 4 throughput
t = pd.read_csv(os.path.join(RES, "analysis", "throughput_all.csv"))
ok = t[t.result == "ok"]
names = {"seq": "Sequential", "pipe": "Pipelined", "early": "Pipelined +\nearly drop"}
fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.8))
for ax, colname, ylab in [(axs[0], "makespan_s", "Makespan, 9 pieces (s)"), (axs[1], "steady_cycle_s", "Steady-state cycle (s/piece)")]:
    for i, m in enumerate(["seq", "pipe", "early"]):
        v = ok[ok["mode"] == m][colname]
        ax.bar(i, v.mean(), width=0.58, linewidth=0, color=S1 if m == "seq" else S2, zorder=2)
        ax.scatter([i] * len(v), v, s=12, color=INK, zorder=3)
        ax.text(i, v.max() * 1.03, f"{v.mean():.1f}", ha="center", va="bottom", fontsize=7.6, color=INK)
    ax.set_xticks(range(3)); ax.set_xticklabels([names[m] for m in ["seq", "pipe", "early"]], fontsize=7.8)
    ax.set_ylabel(ylab); ax.grid(True, axis="y", color=GRID, lw=0.6); ax.set_axisbelow(True)
    ax.set_ylim(0, ok[colname].max() * 1.15)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig4_throughput.png"), dpi=300); plt.close(fig)
print("ok")
