#!/usr/bin/env python3
"""Replays the orchestrator's heartbeat watchdog on recorded MQTT logs.

For every job (job_accepted .. final event) it finds the first moment at which a station had sent no live
status for longer than the threshold (counted from the later of its last status and the job start), and
compares it with the end of the job and with any Last Will.

    python replay_watchdog.py 7 results/*/raw_mqtt.csv results_commissioning/raw_mqtt.csv review_check/raw_mqtt.csv
"""
import csv, json, sys

STATIONS = ("hbw", "grabber", "oven", "colorsorter")
FINAL = {"job_done", "job_failed", "home_done", "home_failed", "stopped", "job_rejected"}


def replay(path, th):
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    last, jobs, cur, lwt = {}, [], None, []
    gaps = []
    for r in rows:
        t, topic = float(r["t_unix"]), r["topic"]
        parts = topic.split("/")
        if topic == "factory/orchestrator/event":
            ev = json.loads(r["payload"])
            if ev["event"] == "job_accepted" and cur is None:
                cur = {"job_id": ev.get("job_id"), "start": t, "end": None, "fire": None, "lwt": None, "result": None}
            elif ev["event"] in FINAL and cur is not None:
                cur["end"], cur["result"] = t, ev["event"] + (": " + ev["error"] if ev.get("error") else "")
                jobs.append(cur); cur = None
            continue
        if len(parts) != 3 or parts[1] not in STATIONS:
            continue
        st, kind = parts[1], parts[2]
        if cur is not None and cur["fire"] is None:
            # check every station up to this moment
            for s in STATIONS:
                ref = max(last.get(s, 0.0), cur["start"])
                if t - ref > th:
                    cur["fire"] = (ref + th, s, ref + th - last.get(s, 0.0) if s in last else None)
                    break
        if kind == "lwt" and r["payload"] != "online" and r["retained"] == "0":
            lwt.append((t, st))
            if cur is not None and cur["lwt"] is None:
                cur["lwt"] = (t, st, t - last.get(st, t))
        if kind == "status" and r["retained"] == "0":
            if cur is not None and st in last:
                gaps.append(t - max(last[st], cur["start"]))
            last[st] = t
    return jobs, gaps


def main():
    th = float(sys.argv[1])
    alljobs, allgaps, dur = [], [], 0.0
    for p in sys.argv[2:]:
        jobs, gaps = replay(p, th)
        allgaps += gaps
        for j in jobs:
            j["file"] = p
            dur += j["end"] - j["start"]
        alljobs += jobs
    fired = [j for j in alljobs if j["fire"] and j["fire"][0] < j["end"]]
    print(f"threshold {th:.1f} s: {len(alljobs)} jobs, {dur / 3600:.2f} h of job time, "
          f"{len(allgaps)} status intervals during jobs, longest {max(allgaps):.2f} s")
    print(f"watchdog would have fired in {len(fired)} job(s):")
    for j in fired:
        t, s, since = j["fire"]
        line = f"  {j['file']}  {j['job_id']}  {s} silent since {since:.1f} s before firing"
        line += f"; job actually ended {j['end'] - t:+.1f} s later ({j['result']})"
        if j["lwt"]:
            line += f"; Last Will {j['lwt'][0] - t:+.1f} s after the watchdog ({j['lwt'][2]:.1f} s after its last status)"
        print(line)


if __name__ == "__main__":
    main()
