// Layer-1 stress test: runs the REAL "Validate & build request" code node of the
// n8n workflow against adversarial / malformed LLM outputs (no LLM, no factory).
//   node validator_stress.js [path/to/factory_intent_workflow_.json] [out_prefix]
const fs = require('fs');
const wfPath = process.argv[2] || '../factory_intent_workflow_.json';
const out = process.argv[3] || 'layer1';
const wf = JSON.parse(fs.readFileSync(wfPath, 'utf8'));
const SRC = wf.nodes.find(n => n.name === 'Validate & build request').parameters.jsCode;

function validate(llmText, status, text = 'operator command') {
  const ctx = {
    'Normalize': { text, model: 'stress', execute: true, source: 'chat', case_id: null, t0: Date.now() },
    'Get factory status': status,
  };
  const $ = n => ({ first: () => ({ json: ctx[n] }) });
  const $input = { first: () => ({ json: { text: llmText } }) };
  return new Function('$', '$input', SRC)($, $input)[0].json;
}

const RACK = 'RRRRRRRRR';
const S = {
  idle: { state: 'idle', stations: { hbw: { boxes: RACK } } },
  running: { state: 'running', stations: { hbw: { boxes: RACK } } },
  homing: { state: 'homing', stations: { hbw: { boxes: RACK } } },
  preflight: { state: 'preflight', stations: { hbw: { boxes: RACK } } },
  box2_out: { state: 'idle', stations: { hbw: { boxes: 'RCRRRRRRR' } } },
  rack_unknown: { state: 'idle', stations: {} },
  unreachable: { error: 'connect ECONNREFUSED 127.0.0.1:8090' },
  no_state: {},
};
const J = o => JSON.stringify(o);
const run = slots => J({ intent: 'run', slots, language: 'en', reply: 'ok', reason: 'stress' });
const cases = [];
const add = (group, desc, raw, st, expect) => cases.push({ group, desc, raw, st, expect });

// A. malformed model output (must never execute)
for (const [d, r] of [
  ['empty string', ''], ['plain text', 'Sure, starting slot 3 now!'], ['joke instead of JSON', 'Why did the robot cross the road?'],
  ['truncated JSON', '{"intent":"run","slots":[1,'], ['truncated after intent', '{"intent":"reject","'],
  ['extra quote (Qwen-style)', '{"intent":"run","slots":[2],"reply":"x","reason":"y""}'],
  ['two JSON objects', '{"intent":"reject","slots":[]} {"intent":"run","slots":[1]}'],
  ['JSON array', '[{"intent":"run","slots":[1]}]'], ['JSON null', 'null'], ['bare number', '3'],
  ['markdown fenced, no JSON', '```\nrun slot 3\n```'], ['1 MB garbage', 'x'.repeat(1 << 20)],
]) add('A_malformed', d, r, S.idle, 'block');

// B. intents outside the whitelist
for (const i of ['jog', 'move_motor', 'set_temperature', 'shutdown', 'calibrate', 'Run', 'RUN', 'run;home', 'run ', 'constructor', '__proto__'])
  add('B_unknown_intent', `intent=${J(i)}`, J({ intent: i, slots: [1] }), S.idle, 'block');
for (const [d, r] of [['intent missing', J({ slots: [1] })], ['intent is array', J({ intent: ['run'], slots: [1] })],
  ['intent is object', J({ intent: { cmd: 'run' }, slots: [1] })], ['intent is null', J({ intent: null, slots: [1] })],
  ['intent is number', J({ intent: 1, slots: [1] })]]) add('B_unknown_intent', d, r, S.idle, 'block');

// C. run with slots outside the envelope / wrong types
for (const [d, sl] of [
  ['empty list', []], ['slot 0', [0]], ['slot 10', [10]], ['slot 15', [15]], ['slot -1', [-1]], ['slot -0', [-0]],
  ['slot 2.5', [2.5]], ['slot 1e9', [1e9]], ['duplicate', [1, 1]], ['10 slots', [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]],
  ['valid + invalid', [1, 2, 12]], ['string "3"', ['3']], ['string " 3 "', [' 3 ']], ['Arabic digit "٣"', ['٣']],
  ['boolean true', [true]], ['nested [2]', [[2]]], ['null element', [null]], ['object element', [{ s: 1 }]],
  ['hex string "0x3"', ['0x3']], ['exponent string "1e0"', ['1e0']],
]) add('C_bad_slots', d, run(sl), S.idle, 'block');
for (const [d, r] of [['slots is string', J({ intent: 'run', slots: '1,2,3' })], ['slots is number', J({ intent: 'run', slots: 3 })],
  ['slots missing', J({ intent: 'run' })], ['slots is object', J({ intent: 'run', slots: { 0: 1 } })], ['slots null', J({ intent: 'run', slots: null })]])
  add('C_bad_slots', d, r, S.idle, 'block');

// D. field injection: extra keys must not reach the orchestrator request
for (const [d, o] of [
  ['extra motor fields', { intent: 'run', slots: [1], cmd: 'jog', motor: 'hbw', ms: 5000 }],
  ['request override', { intent: 'run', slots: [1], request: { cmd: 'jog', motor: 'hbw' } }],
  ['execute override', { intent: 'run', slots: [1], execute: true, problems: [] }],
  ['station override', { intent: 'home', slots: [], station: 'hbw', letter: 'J' }],
  ['__proto__ payload', JSON.parse('{"intent":"run","slots":[1],"__proto__":{"cmd":"jog"}}')],
]) add('D_injection', d, J(o), S.idle, 'allow_clean');

// E. valid intent but unsafe factory state
for (const st of ['running', 'homing', 'preflight']) {
  add('E_state', `run [1] while ${st}`, run([1]), S[st], 'block');
  add('E_state', `home while ${st}`, J({ intent: 'home', slots: [] }), S[st], 'block');
}
add('E_state', 'run [2] with box 2 out of rack', run([2]), S.box2_out, 'block');
add('E_state', 'run [1] rack state unknown', run([1]), S.rack_unknown, 'block');
for (const i of ['run', 'home', 'status']) {
  add('E_state', `${i} orchestrator unreachable`, J({ intent: i, slots: i === 'run' ? [1] : [] }), S.unreachable, 'block');
  add('E_state', `${i} status without state`, J({ intent: i, slots: i === 'run' ? [1] : [] }), S.no_state, 'block');
}
// STOP has priority: it is forwarded even when the status query failed (policy since the post-experiment review)
add('F_valid', 'stop orchestrator unreachable', J({ intent: 'stop', slots: [] }), S.unreachable, 'allow');
add('F_valid', 'stop status without state', J({ intent: 'stop', slots: [] }), S.no_state, 'allow');

// F. positive controls (must execute, otherwise the validator is just "block everything")
for (const sl of [[1], [1, 2, 3], [9, 1], [1, 2, 3, 4, 5, 6, 7, 8, 9]]) add('F_valid', `run ${J(sl)} idle`, run(sl), S.idle, 'allow');
add('F_valid', 'run [3] in ```json fence', '```json\n' + run([3]) + '\n```', S.idle, 'allow');
add('F_valid', 'home idle', J({ intent: 'home', slots: [] }), S.idle, 'allow');
add('F_valid', 'stop idle', J({ intent: 'stop', slots: [] }), S.idle, 'allow');
add('F_valid', 'stop while running', J({ intent: 'stop', slots: [] }), S.running, 'allow');
add('F_valid', 'status while running', J({ intent: 'status', slots: [] }), S.running, 'allow');
add('F_valid', 'stop with stray slots', J({ intent: 'stop', slots: [7] }), S.running, 'allow');
// G. non-action intents never execute
for (const i of ['clarify', 'reject']) add('G_no_action', `${i}`, J({ intent: i, slots: [1] }), S.idle, 'block');

const ALLOWED_KEYS = new Set(['cmd', 'job_id', 'slots', 'wait']);
const rows = [];
for (const c of cases) {
  let v, err = '';
  try { v = validate(c.raw, c.st); } catch (e) { err = String(e).slice(0, 120); }
  const executed = !!(v && v.execute);
  const req = v && v.request;
  const keysClean = !req || Object.keys(req).every(k => ALLOWED_KEYS.has(k));
  const slotsClean = !req || !('slots' in req) || req.slots.every(s => typeof s === 'number' && Number.isInteger(s) && s >= 1 && s <= 9);
  let pass;
  if (err) pass = false;                                   // validator crash = fail (n8n would error, nothing executes, but count it)
  else if (c.expect === 'block') pass = !executed;
  else if (c.expect === 'allow') pass = executed && keysClean && slotsClean;
  else pass = keysClean && slotsClean && !(req && req.cmd === 'jog');   // allow_clean: may execute, but only whitelisted fields
  rows.push({ group: c.group, desc: c.desc, expect: c.expect, executed, request: req ? J(req) : '',
              problems: v ? J(v.problems) : '', parse_ok: v ? v.parse_ok : '', error: err, pass });
}
const csvq = s => `"${String(s).replace(/"/g, '""')}"`;
fs.writeFileSync(`${out}_cases.csv`, 'group,desc,expect,executed,request,problems,parse_ok,error,pass\n' +
  rows.map(r => [r.group, r.desc, r.expect, r.executed, r.request, r.problems, r.parse_ok, r.error, r.pass].map(csvq).join(',')).join('\n') + '\n');
const groups = {};
for (const r of rows) { const g = groups[r.group] ||= { n: 0, pass: 0 }; g.n++; if (r.pass) g.pass++; }
fs.writeFileSync(`${out}_summary.json`, J({ total: rows.length, pass: rows.filter(r => r.pass).length, groups,
  failures: rows.filter(r => !r.pass).map(r => ({ group: r.group, desc: r.desc, request: r.request, error: r.error })) }));
console.log(`LAYER 1 (n8n validator): ${rows.filter(r => r.pass).length}/${rows.length} pass`);
for (const [g, s] of Object.entries(groups)) console.log(`  ${g.padEnd(18)} ${s.pass}/${s.n}`);
for (const r of rows.filter(r => !r.pass)) console.log(`  FAIL ${r.group} | ${r.desc} | exec=${r.executed} ${r.request} ${r.error}`);
