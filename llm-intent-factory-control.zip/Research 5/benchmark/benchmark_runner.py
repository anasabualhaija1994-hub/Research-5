#!/usr/bin/env python3
"""
Runs the intent benchmark through the REAL n8n workflow (Webhook -> status -> LLM -> validator),
in dry-run mode (execute=false: the factory is never moved).

  python benchmark_runner.py --check-models          # verify model ids exist on OpenRouter
  python benchmark_runner.py --limit 6               # smoke test (6 cases x all models)
  python benchmark_runner.py                         # full run, 1 repeat
  python benchmark_runner.py --repeats 3             # 3 repeats (variance)
  python benchmark_runner.py --models anthropic/claude-sonnet-5.5,openai/gpt-6-luna

Resumable: re-run the same command and finished (model, case, repeat) rows are skipped.
Cases are interleaved across models (and the model order rotates) so API load drift
does not bias latency toward one model.
"""
import argparse, csv, difflib, json, os, sys, time, urllib.request, urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
FIELDS = ["ts", "model", "case_id", "repeat", "category", "lang", "text", "expected_intent", "expected_slots",
          "pred_intent", "pred_slots", "parse_ok", "problems", "n8n_latency_ms", "wall_ms", "http_status", "error", "llm_raw"]


def post(url, payload, timeout):
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST", headers={"Content-Type": "application/json; charset=utf-8"})
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", "replace")
            return r.status, body, (time.perf_counter() - t0) * 1000
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), (time.perf_counter() - t0) * 1000
    except Exception as e:
        return 0, str(e), (time.perf_counter() - t0) * 1000


def check_models(models):
    try:
        with urllib.request.urlopen("https://openrouter.ai/api/v1/models", timeout=30) as r:
            ids = [m["id"] for m in json.loads(r.read())["data"]]
    except Exception as e:
        print("could not fetch the OpenRouter model list:", e); return False
    ok = True
    for m in models:
        if m["id"] in ids:
            print(f"  OK       {m['id']}")
        else:
            ok = False
            print(f"  MISSING  {m['id']}   closest: {difflib.get_close_matches(m['id'], ids, n=4, cutoff=0.5)}")
    return ok


def load_done(path):
    done = set()
    if os.path.exists(path):
        with open(path, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                if not r["error"]:
                    done.add((r["model"], r["case_id"], r["repeat"]))
    return done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost/webhook/factory-intent")
    ap.add_argument("--cases", default=os.path.join(HERE, "cases.json"))
    ap.add_argument("--models-file", default=os.path.join(HERE, "models.json"))
    ap.add_argument("--models", default="", help="comma separated ids (overrides models.json)")
    ap.add_argument("--out", default=os.path.join(HERE, "results.csv"))
    ap.add_argument("--repeats", type=int, default=1)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--sleep", type=float, default=0.2)
    ap.add_argument("--timeout", type=float, default=90)
    ap.add_argument("--check-models", action="store_true")
    a = ap.parse_args()

    models = json.load(open(a.models_file, encoding="utf-8"))
    if a.models:
        keep = set(a.models.split(","))
        models = [m for m in models if m["id"] in keep] or [{"id": i, "label": i} for i in keep]
    if a.check_models:
        sys.exit(0 if check_models(models) else 1)
    cases = json.load(open(a.cases, encoding="utf-8"))
    if a.limit:
        cases = cases[:a.limit]

    done = load_done(a.out)
    new = not os.path.exists(a.out)
    f = open(a.out, "a", newline="", encoding="utf-8")
    w = csv.DictWriter(f, fieldnames=FIELDS)
    if new:
        w.writeheader()

    jobs = []
    for rep in range(1, a.repeats + 1):
        for i, c in enumerate(cases):
            order = models[i % len(models):] + models[:i % len(models)]
            for m in order:
                if (m["id"], c["id"], str(rep)) not in done:
                    jobs.append((rep, c, m))
    print(f"{len(jobs)} calls to make ({len(models)} models x {len(cases)} cases x {a.repeats} repeats, minus finished)")
    t_start = time.time()
    for n, (rep, c, m) in enumerate(jobs, 1):
        payload = {"text": c["text"], "model": m["id"], "case_id": c["id"], "execute": False}
        status, body, wall = post(a.url, payload, a.timeout)
        if status in (0, 429, 500, 502, 503, 504):          # one retry (rate limit / transient)
            time.sleep(3)
            status, body, wall = post(a.url, payload, a.timeout)
        row = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "model": m["id"], "case_id": c["id"], "repeat": rep,
               "category": c["category"], "lang": c["lang"], "text": c["text"], "expected_intent": c["expected_intent"],
               "expected_slots": json.dumps(c["expected_slots"]), "wall_ms": round(wall), "http_status": status,
               "pred_intent": "", "pred_slots": "", "parse_ok": "", "problems": "", "n8n_latency_ms": "", "error": "", "llm_raw": ""}
        try:
            r = json.loads(body)
            if status != 200 or "intent" not in r:
                raise ValueError(body[:200])
            row.update(pred_intent=r["intent"], pred_slots=json.dumps(r.get("slots", [])), parse_ok=int(bool(r.get("parse_ok"))),
                       problems=json.dumps(r.get("problems", []), ensure_ascii=False), n8n_latency_ms=r.get("latency_ms", ""),
                       llm_raw=(r.get("llm_raw") or "").replace("\n", " ")[:600])
        except Exception as e:
            row["error"] = f"HTTP {status}: {e}"[:300]
        w.writerow(row); f.flush()
        flag = "ERR " if row["error"] else ("ok  " if row["pred_intent"] == c["expected_intent"] else "DIFF")
        eta = (time.time() - t_start) / n * (len(jobs) - n)
        print(f"[{n}/{len(jobs)}] {flag} {m['id']:34s} {c['id']} exp={c['expected_intent']:8s} got={row['pred_intent'] or '-':8s} {wall:6.0f}ms  eta {eta/60:4.1f}m", flush=True)
        time.sleep(a.sleep)
    f.close()
    print("done ->", a.out)


if __name__ == "__main__":
    main()
