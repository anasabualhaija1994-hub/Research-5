/*
 * ============================================================================
 *  HBW (High-Bay Warehouse) - Controller firmware  (Step 1 + 2 + 3a)
 * ============================================================================
 *  Built on HBW_standalone.ino: motion sequences and calibrated positions are
 *  preserved (verified identical on a simulator).
 *
 *   STEP 1/2 (unchanged): timeouts, stall detection, interlocks, generic
 *     retrieve/return driven by SLOTS[], FreeRTOS motion task, serial console.
 *
 *   STEP 3a - box state model + recovery
 *    * The station tracks WHERE EACH OF THE 9 BOXES IS:
 *          R = in its rack slot     C = on the conveyor
 *          A = on the cantilever    ? = unknown
 *      (box n always belongs to slot n)
 *    * Write-ahead marking: a box is marked '?' BEFORE every step in which its
 *      location changes (lifting from the shelf, pushing onto the conveyor,
 *      lifting from the conveyor, lowering into the shelf) and given its new
 *      location only after that step succeeds. After any fault or STOP the
 *      state therefore never lies: it is either right or '?'.
 *    * The state is stored in flash (NVS) and survives a reset.
 *    * RECOVERY without manual lifting:
 *        - box on the cantilever ('A')  -> "T n" puts it into the rack,
 *                                          "R n" continues to the conveyor
 *        - box on the conveyor ('C')    -> "T n" goes back to the conveyor
 *                                          pose, fetches it and returns it
 *      (after "H"). Recovery poses are NOT part of your original sequence:
 *      test them slowly, hand on the power switch.
 *    * Cross-checks with the light barriers: retrieve is refused if a box is
 *      already detected on the conveyor; a box declared 'C' must be detected.
 *    * Homing error log: encoder counts when the reference switch is hit
 *      (should be 0). Shows drift / lost pulses. See "home_err" in status.
 *    * Serial lines are built whole and sent under a mutex (no interleaving).
 *
 *  Serial console (115200 baud, end each command with Enter):
 *    H          home all axes
 *    R <n>      retrieve box n (1..9) to the outside conveyor
 *    T <n>      return box n into slot n
 *    A          auto demo = old standalone sequence (needs all boxes 'R')
 *    S          STOP immediately (single key press, no Enter needed)
 *    ?          status (JSON)
 *    V          toggle verbose step log
 *    L <n> <x>  declare box n location, x = R | C | A | ?
 *    L * R      declare ALL boxes in their racks (do this once after the
 *               first flash, and whenever you refill the rack by hand)
 *
 *  Replies are single-line JSON so the same format can go over MQTT later.
 *
 *  IMPORTANT: the software STOP is NOT a safety function. Keep a hardware
 *  power cut-off for the motors within reach at all times.
 * ============================================================================
 */
#include <Arduino.h>
#include <ctype.h>
#include <stdarg.h>
#include <Preferences.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

// ==========================================
// Settings
// ==========================================
const uint32_t HOMING_SETTLE_MS     = 1000;
const uint32_t GRABBER_PICK_WAIT_MS = 2000;   // fixed wait for the Grabber (replaced by an MQTT event in step 3b)
const uint32_t AFTER_PICK_DELAY_MS  = 1000;

// Timeouts (ms). Measured on the real machine: cantilever stroke ~4.0 s,
// horizontal full travel ~12.3 s, vertical full travel ~6.7 s, conveyor ~0.7 s.
const uint32_t TO_CANTILEVER_MS  = 8000;
const uint32_t TO_VERT_MS        = 15000;
const uint32_t TO_HORZ_MS        = 25000;
const uint32_t TO_CONVEYOR_MS    = 3000;
const uint32_t TO_BOX_ARRIVE_MS  = 3000;   // box must be at the inside barrier
const uint32_t STALL_MS          = 600;    // motor ON and no encoder pulse for this long -> STALL

// Positions (encoder counts) - unchanged from the standalone version
const int H_CONVEYOR    = 60;
const int V_CONVEYOR    = 2800;   // height at the conveyor (box placed / picked)
const int V_RETURN_LIFT = 2400;   // lift height after taking the box off the conveyor
const int H_TOL         = 150;    // "at station" tolerance for the cantilever interlock

struct Slot { int h; int vRet; int vStore; };
//                    H     V_Ret  V_Store (0 = home switch)
const Slot SLOTS[9] = {
  { 2900,  500,    0 },   // slot 1
  { 2900, 1850, 1500 },   // slot 2
  { 2900, 3450, 3000 },   // slot 3
  { 5250,  500,    0 },   // slot 4
  { 5250, 1850, 1500 },   // slot 5
  { 5250, 3450, 3000 },   // slot 6
  { 7570,  500,    0 },   // slot 7
  { 7570, 1850, 1500 },   // slot 8
  { 7570, 3450, 3000 },   // slot 9
};
const uint8_t AUTO_ORDER[9] = { 1, 4, 7, 2, 5, 8, 3, 6, 9 };

// ==========================================
// Pins (unchanged)
// ==========================================
#define REF_SWITCH_HORIZONTAL    36
#define LIGHT_BARRIER_INSIDE     39
#define LIGHT_BARRIER_OUTSIDE    34
#define REF_SWITCH_VERTICAL      35

#define ENCODER_HORZ_IMP1        32
#define ENCODER_HORZ_IMP2        33
#define ENCODER_VERT_IMP1        25
#define ENCODER_VERT_IMP2        26

#define REF_SWITCH_CANTILEVER_FRONT 27
#define REF_SWITCH_CANTILEVER_BACK  14

#define MOTOR_CONVEYOR_FWD     23
#define MOTOR_CONVEYOR_BWD     22
#define MOTOR_HORZ_TO_RACK     21
#define MOTOR_HORZ_TO_CONVEYOR 19
#define MOTOR_VERT_DOWN        18
#define MOTOR_VERT_UP          4
#define MOTOR_CANTILEVER_FWD   17
#define MOTOR_CANTILEVER_BWD   16

static const uint8_t ALL_MOTORS[8] = {
  MOTOR_CONVEYOR_FWD, MOTOR_CONVEYOR_BWD, MOTOR_HORZ_TO_RACK, MOTOR_HORZ_TO_CONVEYOR,
  MOTOR_VERT_DOWN, MOTOR_VERT_UP, MOTOR_CANTILEVER_FWD, MOTOR_CANTILEVER_BWD
};

// ==========================================
// Types (all above the first function, so the Arduino IDE's auto-generated
// prototypes can see them). Names avoid libc macros such as F_OK.
// ==========================================
enum Fault : uint8_t {
  HF_OK = 0,
  HF_TIMEOUT,
  HF_STALL,
  HF_ABORTED,
  HF_NO_BOX,
  HF_INTERLOCK_CANTILEVER,   // horizontal move requested while the cantilever is not fully back
  HF_INTERLOCK_STATION,      // cantilever extension requested away from a station
  HF_NOT_HOMED,
  HF_STATE,                  // command not allowed in the current box state
  HF_BAD_ARG,
  HF_CONVEYOR_BUSY           // light barriers detect a box on the conveyor
};

enum BoxLoc : uint8_t { LOC_UNKNOWN = 0, LOC_RACK = 1, LOC_CONVEYOR = 2, LOC_ARM = 3 };

struct Cmd { char type; int slot; };

static const char* faultName(Fault f) {
  switch (f) {
    case HF_OK:                   return "OK";
    case HF_TIMEOUT:              return "TIMEOUT";
    case HF_STALL:                return "STALL";
    case HF_ABORTED:              return "ABORTED";
    case HF_NO_BOX:               return "NO_BOX";
    case HF_INTERLOCK_CANTILEVER: return "INTERLOCK_CANTILEVER";
    case HF_INTERLOCK_STATION:    return "INTERLOCK_STATION";
    case HF_NOT_HOMED:            return "NOT_HOMED";
    case HF_STATE:                return "BAD_STATE";
    case HF_BAD_ARG:              return "BAD_ARG";
    case HF_CONVEYOR_BUSY:        return "CONVEYOR_BUSY";
  }
  return "UNKNOWN";
}

static const char* locName(uint8_t l) {
  switch (l) {
    case LOC_RACK:     return "rack";
    case LOC_CONVEYOR: return "conveyor";
    case LOC_ARM:      return "arm";
  }
  return "unknown";
}
static char locChar(uint8_t l) {
  switch (l) {
    case LOC_RACK:     return 'R';
    case LOC_CONVEYOR: return 'C';
    case LOC_ARM:      return 'A';
  }
  return '?';
}

// ==========================================
// Shared state
// ==========================================
volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;

volatile bool    abortFlag     = false;  // set by STOP, checked in every wait loop
volatile bool    homed         = false;  // axis counters are valid
volatile bool    homingTrusted = false;  // a homing run started from a valid position (error log is meaningful)
volatile bool    busy          = false;  // a command is queued or running
volatile bool    motionStarted = false;  // a motor was driven during the current command
volatile uint8_t boxLoc[9]     = {0};    // location of box 1..9 (BoxLoc), persisted in flash
bool             verbose       = true;
const char*      faultStep     = nullptr; // first primitive that failed in the current command
volatile uint8_t lastFault     = HF_OK;  // result of the last finished command

// homing error log (encoder counts when the reference switch is hit; ideal = 0)
volatile int      homeErrVLast = 0, homeErrHLast = 0, homeErrVMax = 0, homeErrHMax = 0;
volatile uint32_t homeErrN     = 0;

QueueHandle_t     cmdQueue   = nullptr;
SemaphoreHandle_t printMutex = nullptr;
Preferences       prefs;

const int8_t encoder_table[16] = {
  0, -1,  1, 0,
  1,  0,  0, -1,
 -1,  0,  0,  1,
  0,  1, -1, 0
};

// ==========================================
// Output: one whole line per call, serialized between tasks
// ==========================================
static void __attribute__((format(printf, 1, 2))) say(const char* fmt, ...) {
  char buf[400];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  if (n <= 0) return;
  if (n >= (int)sizeof buf) n = (int)sizeof buf - 1;
  if (printMutex) xSemaphoreTake(printMutex, portMAX_DELAY);
  Serial.write((const uint8_t*)buf, (size_t)n);
  if (printMutex) xSemaphoreGive(printMutex);
}

// ==========================================
// Encoder interrupts (unchanged)
// ==========================================
void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t cur = (digitalRead(ENCODER_VERT_IMP1) << 1) | digitalRead(ENCODER_VERT_IMP2);
  verticalPulseCount += encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

void IRAM_ATTR handleHorizontalEncoder() {
  if (horizontalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t cur = (digitalRead(ENCODER_HORZ_IMP1) << 1) | digitalRead(ENCODER_HORZ_IMP2);
  if (cur != lastState) {
    horizontalPulseCount -= encoder_table[(lastState << 2) | cur];
    lastState = cur;
  }
}

// ==========================================
// Sensors (same logic as the original tests)
// ==========================================
static inline bool isHigh(uint8_t p) { return digitalRead(p) != LOW; }
static inline bool isLow(uint8_t p)  { return digitalRead(p) == LOW; }

static inline bool cantFrontAtLimit() { return isHigh(REF_SWITCH_CANTILEVER_FRONT); }
static inline bool cantBackAtLimit()  { return isHigh(REF_SWITCH_CANTILEVER_BACK); }
static inline bool vertAtHome()       { return isHigh(REF_SWITCH_VERTICAL); }
static inline bool horzAtHome()       { return isHigh(REF_SWITCH_HORIZONTAL); }
static inline bool boxInside()        { return isLow(LIGHT_BARRIER_INSIDE); }
static inline bool boxOutside()       { return isLow(LIGHT_BARRIER_OUTSIDE); }

// ==========================================
// Box state model (persisted)
// ==========================================
// Flash writes only happen between motions (all motors OFF).
static void stateSave() {
  uint8_t tmp[9];
  for (uint8_t i = 0; i < 9; i++) tmp[i] = boxLoc[i];
  prefs.putBytes("boxes", tmp, sizeof tmp);
}

static void stateLoad() {
  uint8_t tmp[9] = {0};
  prefs.begin("hbw", false);
  size_t n = prefs.getBytes("boxes", tmp, sizeof tmp);   // 0 bytes if never written
  for (uint8_t i = 0; i < 9; i++) boxLoc[i] = (n == sizeof tmp && tmp[i] <= LOC_ARM) ? tmp[i] : (uint8_t)LOC_UNKNOWN;
}

static void setLoc(int box, BoxLoc loc) {
  if (boxLoc[box - 1] == loc) return;
  boxLoc[box - 1] = loc;
  stateSave();
  say("{\"event\":\"box\",\"box\":%d,\"loc\":\"%s\"}\n", box, locName(loc));
}

static inline BoxLoc locOf(int box) { return (BoxLoc)boxLoc[box - 1]; }

static bool othersOutOfRack(int box) {          // any OTHER box not safely in its rack slot
  for (int j = 1; j <= 9; j++) if (j != box && locOf(j) != LOC_RACK) return true;
  return false;
}
static bool allInRack() {
  for (int j = 1; j <= 9; j++) if (locOf(j) != LOC_RACK) return false;
  return true;
}
static int carryingBox() {
  for (int j = 1; j <= 9; j++) if (locOf(j) == LOC_ARM) return j;
  return 0;
}
static void boxesStr(char* out) {
  for (uint8_t i = 0; i < 9; i++) out[i] = locChar(boxLoc[i]);
  out[9] = 0;
}

// ==========================================
// Motor helpers
// ==========================================
void allMotorsOff() {
  for (uint8_t i = 0; i < 8; i++) digitalWrite(ALL_MOTORS[i], LOW);
  verticalMoveDirection = 0;
  horizontalMoveDirection = 0;
}

// Drive one direction; the opposite direction of the same motor is forced OFF first.
static inline void run(uint8_t on, uint8_t opposite) {
  digitalWrite(opposite, LOW);
  digitalWrite(on, HIGH);
  motionStarted = true;
}
static inline void halt(uint8_t p) { digitalWrite(p, LOW); }

// ==========================================
// Wait helpers (timeout + abort [+ stall])
// ==========================================
#define WAIT_WHILE(cond, ms, onTimeout)                                        \
  do {                                                                         \
    uint32_t _t0 = millis();                                                   \
    while (cond) {                                                             \
      if (abortFlag) { allMotorsOff(); return HF_ABORTED; }                    \
      if (millis() - _t0 > (uint32_t)(ms)) { allMotorsOff(); return (onTimeout); } \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define WAIT_AXIS(cond, counter, ms)                                           \
  do {                                                                         \
    uint32_t _t0 = millis(), _tp = _t0;                                        \
    int _last = (counter);                                                     \
    while (cond) {                                                             \
      if (abortFlag) { allMotorsOff(); return HF_ABORTED; }                    \
      uint32_t _now = millis();                                                \
      if (_now - _t0 > (uint32_t)(ms)) { allMotorsOff(); return HF_TIMEOUT; } \
      int _c = (counter);                                                      \
      if (_c != _last) { _last = _c; _tp = _now; }                             \
      else if (_now - _tp > STALL_MS) { allMotorsOff(); return HF_STALL; }     \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define TRY(call)                                                              \
  do {                                                                         \
    uint32_t _s = millis();                                                    \
    Fault _f = (call);                                                         \
    if (verbose) say("  %-34s %6lu ms  V=%d H=%d\n", #call,                    \
        (unsigned long)(millis() - _s), (int)verticalPulseCount, (int)horizontalPulseCount); \
    if (_f != HF_OK) { if (!faultStep) faultStep = #call; return _f; }         \
  } while (0)

static Fault waitMs(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    if (abortFlag) return HF_ABORTED;
    delay(1);
  }
  return HF_OK;
}

// ==========================================
// Interlock helper + homing error log
// ==========================================
static bool atStation() {
  int h = horizontalPulseCount;
  if (abs(h - H_CONVEYOR) <= H_TOL) return true;
  for (uint8_t i = 0; i < 9; i++) if (abs(h - SLOTS[i].h) <= H_TOL) return true;
  return false;
}

// counts = encoder counter at the moment the reference switch was reached (ideal 0)
static void recordHomeErr(bool vertical, int counts) {
  if (!(homed || homingTrusted)) return;        // counters were meaningless before this homing
  int a = abs(counts);
  if (vertical) { homeErrVLast = counts; if (a > homeErrVMax) homeErrVMax = a; }
  else          { homeErrHLast = counts; if (a > homeErrHMax) homeErrHMax = a; }
  homeErrN++;
  if (verbose) say("  home_error %s %d counts\n", vertical ? "vertical" : "horizontal", counts);
}

// ==========================================
// Primitives (each returns a Fault)
// ==========================================
// --- Cantilever ---
static Fault cantileverFront() {
  if (cantFrontAtLimit()) return HF_OK;
  if (!homed)             return HF_NOT_HOMED;
  if (!atStation())       return HF_INTERLOCK_STATION;
  run(MOTOR_CANTILEVER_FWD, MOTOR_CANTILEVER_BWD);
  WAIT_WHILE(!cantFrontAtLimit(), TO_CANTILEVER_MS, HF_TIMEOUT);
  halt(MOTOR_CANTILEVER_FWD); delay(10);
  return HF_OK;
}

static Fault cantileverBack() {
  if (cantBackAtLimit()) return HF_OK;
  run(MOTOR_CANTILEVER_BWD, MOTOR_CANTILEVER_FWD);
  WAIT_WHILE(!cantBackAtLimit(), TO_CANTILEVER_MS, HF_TIMEOUT);
  halt(MOTOR_CANTILEVER_BWD); delay(10);
  return HF_OK;
}

// --- Vertical axis ---
static Fault vertHome() {
  if (vertAtHome()) { recordHomeErr(true, verticalPulseCount); verticalPulseCount = 0; return HF_OK; }
  verticalMoveDirection = -1;
  run(MOTOR_VERT_UP, MOTOR_VERT_DOWN);
  WAIT_AXIS(!vertAtHome(), verticalPulseCount, TO_VERT_MS);
  int err = verticalPulseCount;
  halt(MOTOR_VERT_UP); verticalMoveDirection = 0;
  recordHomeErr(true, err);
  verticalPulseCount = 0; delay(10);
  return HF_OK;
}

// Move to an absolute count, direction chosen automatically. Target 0 = home switch.
static Fault moveVertTo(int target) {
  if (target <= 0) return vertHome();
  if (!homed) return HF_NOT_HOMED;
  int c = verticalPulseCount;
  if (c < target) {
    verticalMoveDirection = 1;
    run(MOTOR_VERT_DOWN, MOTOR_VERT_UP);
    WAIT_AXIS(verticalPulseCount < target, verticalPulseCount, TO_VERT_MS);
    halt(MOTOR_VERT_DOWN); verticalMoveDirection = 0; delay(10);
  } else if (c > target) {
    verticalMoveDirection = -1;
    run(MOTOR_VERT_UP, MOTOR_VERT_DOWN);
    WAIT_AXIS(verticalPulseCount > target, verticalPulseCount, TO_VERT_MS);
    halt(MOTOR_VERT_UP); verticalMoveDirection = 0; delay(10);
  }
  return HF_OK;
}

// --- Horizontal axis ---
static Fault horzHome() {
  if (!cantBackAtLimit()) return HF_INTERLOCK_CANTILEVER;
  if (horzAtHome()) { recordHomeErr(false, horizontalPulseCount); horizontalPulseCount = 0; return HF_OK; }
  horizontalMoveDirection = -1;
  run(MOTOR_HORZ_TO_CONVEYOR, MOTOR_HORZ_TO_RACK);
  WAIT_AXIS(!horzAtHome(), horizontalPulseCount, TO_HORZ_MS);
  int err = horizontalPulseCount;
  halt(MOTOR_HORZ_TO_CONVEYOR); horizontalMoveDirection = 0;
  recordHomeErr(false, err);
  horizontalPulseCount = 0; delay(10);
  return HF_OK;
}

static Fault moveHorzTo(int target) {
  if (!homed) return HF_NOT_HOMED;
  int c = horizontalPulseCount;
  if (c == target) return HF_OK;                    // nothing to do (cantilever may be extended)
  if (!cantBackAtLimit()) return HF_INTERLOCK_CANTILEVER;
  if (c < target) {
    horizontalMoveDirection = 1;
    run(MOTOR_HORZ_TO_RACK, MOTOR_HORZ_TO_CONVEYOR);
    WAIT_AXIS(horizontalPulseCount < target, horizontalPulseCount, TO_HORZ_MS);
    halt(MOTOR_HORZ_TO_RACK); horizontalMoveDirection = 0; delay(10);
  } else {
    horizontalMoveDirection = -1;
    run(MOTOR_HORZ_TO_CONVEYOR, MOTOR_HORZ_TO_RACK);
    WAIT_AXIS(horizontalPulseCount > target, horizontalPulseCount, TO_HORZ_MS);
    halt(MOTOR_HORZ_TO_CONVEYOR); horizontalMoveDirection = 0; delay(10);
  }
  return HF_OK;
}

// --- Conveyor ---
// Wait for the box at the inside barrier, push it out until the outside barrier.
static Fault conveyorToOutside() {
  WAIT_WHILE(!boxInside(), TO_BOX_ARRIVE_MS, HF_NO_BOX);
  run(MOTOR_CONVEYOR_FWD, MOTOR_CONVEYOR_BWD);
  WAIT_WHILE(!boxOutside(), TO_CONVEYOR_MS, HF_TIMEOUT);
  halt(MOTOR_CONVEYOR_FWD);
  return HF_OK;
}

// Pull the box back until the inside barrier.
static Fault conveyorToInside() {
  run(MOTOR_CONVEYOR_BWD, MOTOR_CONVEYOR_FWD);
  WAIT_WHILE(!boxInside(), TO_CONVEYOR_MS, HF_TIMEOUT);
  halt(MOTOR_CONVEYOR_BWD); delay(10);
  return HF_OK;
}

// ==========================================
// High-level operations
// ==========================================
static Fault doHome() {
  homingTrusted = homed;      // was the position valid when this homing started?
  homed = false;
  TRY(cantileverBack());
  TRY(vertHome());
  TRY(horzHome());
  homed = true;
  homingTrusted = false;
  return HF_OK;
}

// rack -> conveyor outside. If the box is already on the cantilever
// (recovery), the rack pick-up part is skipped.
static Fault doRetrieve(int slot) {
  if (slot < 1 || slot > 9)  return HF_BAD_ARG;
  if (!homed)                return HF_NOT_HOMED;
  BoxLoc where = locOf(slot);
  if (where != LOC_RACK && where != LOC_ARM) return HF_STATE;
  if (othersOutOfRack(slot)) return HF_STATE;
  if (boxInside() || boxOutside()) return HF_CONVEYOR_BUSY;
  const Slot& s = SLOTS[slot - 1];

  if (where == LOC_RACK) {
    TRY(moveHorzTo(s.h));
    TRY(moveVertTo(s.vRet));
    TRY(cantileverFront());
    setLoc(slot, LOC_UNKNOWN);          // the box leaves the shelf somewhere in the next move
    TRY(moveVertTo(s.vStore));
    setLoc(slot, LOC_ARM);
    TRY(cantileverBack());
  }
  TRY(moveHorzTo(H_CONVEYOR));
  TRY(moveVertTo(V_CONVEYOR));
  setLoc(slot, LOC_UNKNOWN);            // the box is pushed onto the conveyor
  TRY(cantileverFront());
  TRY(conveyorToOutside());
  setLoc(slot, LOC_CONVEYOR);
  say("{\"event\":\"progress\",\"state\":\"box_outside\",\"slot\":%d}\n", slot);
  return HF_OK;
}

// empty box conveyor -> rack. From 'A' (recovery) only the rack part runs.
static Fault doReturn(int slot) {
  if (slot < 1 || slot > 9)  return HF_BAD_ARG;
  if (!homed)                return HF_NOT_HOMED;
  BoxLoc where = locOf(slot);
  if (where != LOC_CONVEYOR && where != LOC_ARM) return HF_STATE;
  if (othersOutOfRack(slot)) return HF_STATE;
  if (where == LOC_CONVEYOR && !boxInside() && !boxOutside()) return HF_NO_BOX;   // state says C, sensors disagree
  const Slot& s = SLOTS[slot - 1];

  if (where == LOC_CONVEYOR) {
    TRY(moveHorzTo(H_CONVEYOR));        // no-ops in the normal flow (already there);
    TRY(moveVertTo(V_CONVEYOR));        // needed when returning after a recovery
    TRY(conveyorToInside());
    TRY(cantileverFront());
    setLoc(slot, LOC_UNKNOWN);          // the box is lifted off the conveyor
    TRY(moveVertTo(V_RETURN_LIFT));
    setLoc(slot, LOC_ARM);
    TRY(cantileverBack());
    TRY(vertHome());
    TRY(horzHome());
  }
  TRY(moveHorzTo(s.h));
  TRY(moveVertTo(s.vStore));
  TRY(cantileverFront());
  setLoc(slot, LOC_UNKNOWN);            // the box is lowered onto the shelf
  TRY(moveVertTo(s.vRet));
  setLoc(slot, LOC_RACK);
  TRY(cantileverBack());
  return HF_OK;
}

// the old standalone sequence
static Fault doAuto() {
  if (!allInRack())                return HF_STATE;
  if (boxInside() || boxOutside()) return HF_CONVEYOR_BUSY;
  TRY(doHome());
  TRY(waitMs(HOMING_SETTLE_MS));
  for (uint8_t i = 0; i < 9; i++) {
    int slot = AUTO_ORDER[i];
    TRY(doRetrieve(slot));
    TRY(waitMs(GRABBER_PICK_WAIT_MS + AFTER_PICK_DELAY_MS));   // Grabber picks the piece
    TRY(doReturn(slot));
  }
  TRY(doHome());
  return HF_OK;
}

// ==========================================
// Command execution (runs in the motion task)
// ==========================================
static Fault runCommand(const Cmd& c) {
  switch (c.type) {
    case 'H': return doHome();
    case 'R': return doRetrieve(c.slot);
    case 'T': return doReturn(c.slot);
    case 'A': return doAuto();
  }
  return HF_BAD_ARG;
}

void executeAndReport(const Cmd& c) {
  faultStep = nullptr;
  motionStarted = false;
  homingTrusted = false;
  uint32_t t0 = millis();
  Fault f = runCommand(c);
  uint32_t dt = millis() - t0;
  allMotorsOff();
  lastFault = f;

  if (f == HF_OK) {
    say("{\"event\":\"done\",\"cmd\":\"%c\",\"slot\":%d,\"ms\":%lu}\n", c.type, c.slot, (unsigned long)dt);
  } else {
    if (motionStarted) homed = false;    // positions can no longer be trusted (box states are already conservative)
    char boxes[10]; boxesStr(boxes);
    say("{\"event\":\"fault\",\"cmd\":\"%c\",\"slot\":%d,\"code\":\"%s\",\"step\":\"%s\",\"ms\":%lu,\"homed\":%s,\"boxes\":\"%s\"}\n",
        c.type, c.slot, faultName(f), faultStep ? faultStep : "-", (unsigned long)dt,
        homed ? "true" : "false", boxes);
  }
  busy = false;
}

void motionTask(void*) {
  Cmd c;
  for (;;) {
    if (xQueueReceive(cmdQueue, &c, portMAX_DELAY) == pdTRUE) executeAndReport(c);
  }
}

// ==========================================
// Serial console (runs in loop())
// ==========================================
static void printStatus() {
  char boxes[10]; boxesStr(boxes);
  const char* cant = cantFrontAtLimit() ? "front" : (cantBackAtLimit() ? "back" : "between");
  say("{\"event\":\"status\",\"busy\":%s,\"homed\":%s,\"boxes\":\"%s\",\"carrying\":%d,\"v\":%d,\"h\":%d,"
      "\"cantilever\":\"%s\",\"box_inside\":%s,\"box_outside\":%s,\"last_fault\":\"%s\","
      "\"home_err\":{\"v_last\":%d,\"v_max\":%d,\"h_last\":%d,\"h_max\":%d,\"n\":%lu},\"verbose\":%s}\n",
      busy ? "true" : "false", homed ? "true" : "false", boxes, carryingBox(),
      (int)verticalPulseCount, (int)horizontalPulseCount, cant,
      boxInside() ? "true" : "false", boxOutside() ? "true" : "false", faultName((Fault)lastFault),
      (int)homeErrVLast, (int)homeErrVMax, (int)homeErrHLast, (int)homeErrHMax, (unsigned long)homeErrN,
      verbose ? "true" : "false");
}

static void printHelp() {
  say("Commands: H | R <1-9> | T <1-9> | A | S | ? | V | L <1-9> <R|C|A|?> | L * R\n");
}

static void reject(char type, int slot, const char* why) {
  say("{\"event\":\"rejected\",\"cmd\":\"%c\",\"slot\":%d,\"code\":\"%s\"}\n", type, slot, why);
}

static void doStop() {
  allMotorsOff();
  abortFlag = true;
  say("{\"event\":\"stop\"}\n");
}

static void submit(char type, int slot) {
  if ((type == 'R' || type == 'T') && (slot < 1 || slot > 9)) { reject(type, slot, "BAD_ARG"); return; }
  if (busy) { reject(type, slot, "BUSY"); return; }
  Cmd c = { type, slot };
  abortFlag = false;
  busy = true;
  say("{\"event\":\"started\",\"cmd\":\"%c\",\"slot\":%d}\n", type, slot);   // before the task can print anything
  if (xQueueSend(cmdQueue, &c, 0) != pdPASS) { busy = false; reject(type, slot, "QUEUE_FULL"); }
}

// Operator declares where a box really is (checked against the light barriers)
static void declareBox(int box, bool all, char l) {
  BoxLoc loc;
  switch (l) {
    case 'R': loc = LOC_RACK; break;
    case 'C': loc = LOC_CONVEYOR; break;
    case 'A': loc = LOC_ARM; break;
    case '?': loc = LOC_UNKNOWN; break;
    default:  reject('L', box, "BAD_ARG"); return;
  }
  if (busy) { reject('L', box, "BUSY"); return; }
  if (!all && (box < 1 || box > 9)) { reject('L', box, "BAD_ARG"); return; }
  if (all && loc != LOC_RACK && loc != LOC_UNKNOWN) { reject('L', 0, "BAD_ARG"); return; }
  bool sensorBox = boxInside() || boxOutside();
  if (loc == LOC_CONVEYOR && !sensorBox) { reject('L', box, "SENSOR_MISMATCH"); return; }   // no box detected on the conveyor
  if (all && loc == LOC_RACK && sensorBox) { reject('L', 0, "SENSOR_MISMATCH"); return; }  // a box IS on the conveyor
  if (!all && (loc == LOC_CONVEYOR || loc == LOC_ARM)) {
    for (int j = 1; j <= 9; j++)
      if (j != box && (locOf(j) == LOC_CONVEYOR || locOf(j) == LOC_ARM)) { reject('L', box, "CONFLICT"); return; }
  }
  if (all) { for (int i = 1; i <= 9; i++) setLoc(i, loc); }
  else     { setLoc(box, loc); }
  printStatus();
}

void handleLine(char* line) {
  while (*line == ' ') line++;
  if (!*line) return;
  char c = (char)toupper((unsigned char)*line);
  int arg = atoi(line + 1);
  switch (c) {
    case 'S': doStop(); break;
    case '?': printStatus(); break;
    case 'V': verbose = !verbose; say("{\"event\":\"verbose\",\"value\":%s}\n", verbose ? "true" : "false"); break;
    case 'L': {
      char* p = line + 1;
      while (*p == ' ') p++;
      bool all = false; int box = 0;
      if (*p == '*') { all = true; p++; }
      else { box = atoi(p); while (isdigit((unsigned char)*p)) p++; }
      while (*p == ' ') p++;
      declareBox(box, all, (char)toupper((unsigned char)*p));
      break;
    }
    case 'H': case 'A': submit(c, 0); break;
    case 'R': case 'T': submit(c, arg); break;
    default: printHelp(); break;
  }
}

// ==========================================
// Arduino entry points
// ==========================================
void setup() {
  Serial.begin(115200);
  printMutex = xSemaphoreCreateMutex();

  pinMode(REF_SWITCH_HORIZONTAL, INPUT); pinMode(LIGHT_BARRIER_INSIDE, INPUT);
  pinMode(LIGHT_BARRIER_OUTSIDE, INPUT); pinMode(REF_SWITCH_VERTICAL, INPUT);
  pinMode(ENCODER_HORZ_IMP1, INPUT); pinMode(ENCODER_HORZ_IMP2, INPUT);
  pinMode(ENCODER_VERT_IMP1, INPUT); pinMode(ENCODER_VERT_IMP2, INPUT);
  pinMode(REF_SWITCH_CANTILEVER_FRONT, INPUT); pinMode(REF_SWITCH_CANTILEVER_BACK, INPUT);

  for (uint8_t i = 0; i < 8; i++) pinMode(ALL_MOTORS[i], OUTPUT);
  allMotorsOff();   // every motor OFF at start

  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP1), handleVerticalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP2), handleVerticalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP1), handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP2), handleHorizontalEncoder, CHANGE);

  stateLoad();
  cmdQueue = xQueueCreate(1, sizeof(Cmd));
  xTaskCreatePinnedToCore(motionTask, "motion", 8192, NULL, 2, NULL, 1);

  say("{\"event\":\"boot\",\"station\":\"HBW\",\"homed\":false}\n");
  printStatus();
  printHelp();
}

void loop() {
  static char buf[32];
  static uint8_t n = 0;
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (n == 0 && (ch == 's' || ch == 'S')) { doStop(); continue; }   // instant STOP, no Enter needed
    if (ch == '\n' || ch == '\r') {
      if (n) { buf[n] = 0; handleLine(buf); n = 0; }
    } else if (n < sizeof(buf) - 1) {
      buf[n++] = ch;
    }
  }
  delay(1);
}
