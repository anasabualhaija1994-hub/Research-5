/*
 * ============================================================================
 *  Oven station - Controller firmware  (Step 1 + 2 + MQTT)
 * ============================================================================
 *  Built on Oven_standalone.ino: every motion, delay and pin sequence is
 *  preserved exactly. What changed (Step 1/2, unchanged from before):
 *
 *   * SAFETY FIX (found by real-hardware testing on 2026-09-22): a reed
 *     switch can read "reached" for an instant that does not reflect the
 *     real position (mechanical bounce, or noise on a floating input pin).
 *     No move "shortcuts" based on a pre-check read anymore, and every
 *     WAIT_WHILE requires the switch to read "reached" CONTINUOUSLY for
 *     CONFIRM_MS before it is trusted.
 *   * Every WAIT_WHILE has a TIMEOUT. Every fixed delay() is an abortable
 *     waitMs(), so STOP works even mid-bake or mid-cut.
 *   * A coarse PIECE PHASE is tracked and reported.
 *   * Motion runs in its own FreeRTOS task; loop() only reads the serial
 *     console.
 *   * SAFETY ON FAULT/ABORT: the door drive, heater/compressor and saw are
 *     always turned off immediately. The gripper and vacuum valve are
 *     deliberately left as they were. After any fault the station requires
 *     a fresh "H" (home) before it will run another cycle.
 *
 *   MQTT (new) - same pattern as HBW/ColorSorter/Grabber: every say() line
 *     is mirrored to the event topic unchanged; commands can arrive as JSON
 *     on the command topic with an optional "command_id" that is
 *     deduplicated (last 16 remembered) so a retried publish never runs
 *     twice; a retained heartbeat/status is published every HEARTBEAT_MS;
 *     a Last Will marks the station "offline" (retained) the instant its
 *     MQTT link drops. WiFi/MQTT connect/reconnect are fully non-blocking.
 *     Fill in WIFI_PASSWORD below before flashing.
 *
 *  Nothing runs automatically at boot: the station waits for commands.
 *
 *  Serial console (115200 baud, end each command with Enter):
 *    H         home (table -> vacuum position, vacuum arm -> table, oven feed -> out)
 *    C         run ONE piece cycle (waits for a piece, then bake+cut+eject)
 *    N <n>     run n cycles back to back (same as the old standalone's 9)
 *    S         STOP immediately (single key press, no Enter needed)
 *    ?         status (JSON)
 *    V         toggle verbose step log
 *    D         raw sensor dump (read-only, safe anytime, no motion)
 *    J <m> [ms]  jog ONE motor for a short capped time (default 300 ms, max
 *                15000 ms). m is one of: V B T O I U (see original header)
 *
 *  MQTT command topic payload examples (see TOPIC_CMD below):
 *    {"cmd":"H","command_id":"c-1"}
 *    {"cmd":"C","command_id":"c-2"}
 *    {"cmd":"N","count":5,"command_id":"c-3"}
 *    {"cmd":"S","command_id":"c-4"}
 *    {"cmd":"J","motor":"V","ms":300,"command_id":"c-5"}
 *
 *  Replies are single-line JSON, identical over Serial and MQTT.
 *
 *  IMPORTANT: the software STOP is NOT a safety function. Keep a hardware
 *  power cut-off within reach at all times, especially given the oven
 *  heater/door and the compressed-air valves on this station.
 * ============================================================================
 */
#include <Arduino.h>
#include <ctype.h>
#include <stdarg.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"

// ==========================================
// Settings
// ==========================================
const uint32_t START_SETTLE_MS = 1000;   // brief pause after boot before accepting motion (lets sensors settle)

// Timeouts (ms). MEASURED on the real machine on 2026-09-22 (one full clean
// cycle). See original header for the full breakdown.
const uint32_t TO_TABLE_MOVE_MS   = 4000;    // table: vacuum <-> saw <-> belt position (measured up to ~2.3s)
const uint32_t TO_VACUUM_MOVE_MS  = 15000;   // vacuum arm: table <-> oven (measured ~9.9-10.2s)
const uint32_t TO_OVEN_FEED_MS    = 5000;    // oven feed in/out (measured ~2.8-2.9s)
const uint32_t TO_BELT_MS         = 20000;   // belt push until Belt_Light_Bar sees the piece (measured ~12.5s)
const uint32_t TO_PIECE_ARRIVE_MS = 300000;  // waiting for an external piece (Grabber) - intentionally long

// ==========================================
// Pins (unchanged from the standalone version)
// ==========================================
#define RS_Table_vacum_position 36
#define RS_Table_belt_position  39
#define Belt_Light_Bar          34
#define RS_Table_Saw_position   35
#define RS_Vacum_Table_position 32
#define RS_Vacum_Oven_position  33
#define Oven_Light_Bar          25

#define Move_Table_TO_belt      23
#define Move_Table_TO_Vacuum    22
#define Belt_Motor              21
#define Saw_Motor               19
#define Move_Vacuum_To_OvenPin  18
#define Move_Vacuum_To_TablePin 17
#define Oven_Light              16
#define Compressor               4
#define Gripper                  2
#define Vacuum_Valve             14
#define Oven_DoorPin             12
#define Table_Valve              13
#define RS_Oven_Feed_In           5
#define RS_Oven_Feed_Out         15
#define Move_Oven_inside         26
#define Move_Oven_outside        27

// Outputs turned off on every fault/abort (heater, door drive, saw, all
// moves, belt). Gripper and Vacuum_Valve are NOT included on purpose.
static const uint8_t SAFE_OFF_PINS[] = {
  Move_Table_TO_belt, Move_Table_TO_Vacuum, Belt_Motor, Saw_Motor,
  Move_Vacuum_To_OvenPin, Move_Vacuum_To_TablePin, Oven_Light, Compressor,
  Oven_DoorPin, Table_Valve, Move_Oven_inside, Move_Oven_outside
};

// ==========================================
// MQTT settings - FILL IN WIFI_PASSWORD BEFORE FLASHING
// ==========================================
const char* WIFI_SSID      = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD  = "YOUR_WIFI_PASSWORD";

const char* MQTT_HOST      = "192.168.0.249";
const uint16_t MQTT_PORT   = 1883;
const char* MQTT_CLIENT_ID = "oven-esp32";

const char* TOPIC_CMD    = "factory/oven/cmd";
const char* TOPIC_EVENT  = "factory/oven/event";
const char* TOPIC_STATUS = "factory/oven/status";
const char* TOPIC_LWT    = "factory/oven/lwt";

const uint32_t WIFI_RETRY_MS = 5000;
const uint32_t MQTT_RETRY_MS = 5000;
const uint32_t HEARTBEAT_MS  = 5000;

#define CMDID_LEN     40
#define CMDID_HISTORY 16

// ==========================================
// Types (above every function, so the Arduino IDE's auto-generated
// prototypes can see them)
// ==========================================
enum Fault : uint8_t { OF_OK = 0, OF_TIMEOUT, OF_ABORTED, OF_NO_PIECE, OF_NOT_HOMED, OF_STATE, OF_BAD_ARG };

enum Phase : uint8_t {
  PH_IDLE = 0, PH_HOMING, PH_WAIT_PIECE, PH_LOAD_OVEN, PH_BAKING,
  PH_UNLOAD_OVEN, PH_TO_TABLE, PH_CUTTING, PH_TO_BELT, PH_EJECTING
};

struct Cmd { char type; int count; int arg2; char cmd_id[CMDID_LEN + 1]; };   // arg2: motor letter for 'J' (jog), unused otherwise

static const char* faultName(Fault f) {
  switch (f) {
    case OF_OK:        return "OK";
    case OF_TIMEOUT:   return "TIMEOUT";
    case OF_ABORTED:   return "ABORTED";
    case OF_NO_PIECE:  return "NO_PIECE";
    case OF_NOT_HOMED: return "NOT_HOMED";
    case OF_STATE:     return "BAD_STATE";
    case OF_BAD_ARG:   return "BAD_ARG";
  }
  return "UNKNOWN";
}

static const char* phaseName(Phase p) {
  switch (p) {
    case PH_IDLE:        return "idle";
    case PH_HOMING:       return "homing";
    case PH_WAIT_PIECE:   return "wait_piece";
    case PH_LOAD_OVEN:    return "load_oven";
    case PH_BAKING:       return "baking";
    case PH_UNLOAD_OVEN:  return "unload_oven";
    case PH_TO_TABLE:     return "to_table";
    case PH_CUTTING:      return "cutting";
    case PH_TO_BELT:      return "to_belt";
    case PH_EJECTING:     return "ejecting";
  }
  return "unknown";
}

// ==========================================
// Shared state
// ==========================================
volatile bool     abortFlag = false;
volatile bool     homed     = false;
volatile bool     busy      = false;
volatile Phase    phase     = PH_IDLE;
volatile uint8_t  lastFault = OF_OK;
volatile uint32_t cyclesDone = 0;
bool              verbose   = true;
const char*       faultStep = nullptr;

QueueHandle_t     cmdQueue   = nullptr;
SemaphoreHandle_t printMutex = nullptr;

// ==========================================
// MQTT globals
// ==========================================
WiFiClient        wifiClient;
PubSubClient      mqttClient(wifiClient);
SemaphoreHandle_t mqttMutex   = nullptr;   // RECURSIVE mutex - see note on say() below
uint32_t          lastWifiAttempt = 0;
uint32_t          lastMqttAttempt = 0;
uint32_t          lastHeartbeat   = 0;

char    cmdIdHistory[CMDID_HISTORY][CMDID_LEN + 1];
uint8_t cmdIdHistoryPos = 0;

static bool isDuplicateCmdId(const char* id) {
  if (!id || !id[0]) return false;
  for (uint8_t i = 0; i < CMDID_HISTORY; i++)
    if (cmdIdHistory[i][0] && strncmp(cmdIdHistory[i], id, CMDID_LEN) == 0) return true;
  return false;
}
static void rememberCmdId(const char* id) {
  if (!id || !id[0]) return;
  strncpy(cmdIdHistory[cmdIdHistoryPos], id, CMDID_LEN);
  cmdIdHistory[cmdIdHistoryPos][CMDID_LEN] = 0;
  cmdIdHistoryPos = (cmdIdHistoryPos + 1) % CMDID_HISTORY;
}

// ==========================================
// Output: one whole line per call, serialized between tasks, mirrored to MQTT
// ==========================================
// See the HBW station's say() for the full note on why mqttMutex is
// RECURSIVE and why the 50 ms timeout keeps a busy MQTT link from ever
// meaningfully delaying a motor wait loop.
static void __attribute__((format(printf, 1, 2))) say(const char* fmt, ...) {
  char buf[380];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  if (n <= 0) return;
  if (n >= (int)sizeof buf) n = (int)sizeof buf - 1;
  if (printMutex) xSemaphoreTake(printMutex, portMAX_DELAY);
  Serial.write((const uint8_t*)buf, (size_t)n);
  if (printMutex) xSemaphoreGive(printMutex);

  if (mqttMutex && xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC_EVENT, (const uint8_t*)buf, (unsigned int)n, false);
    xSemaphoreGiveRecursive(mqttMutex);
  }
}

static void setPhase(Phase p) {
  phase = p;
  say("{\"event\":\"phase\",\"phase\":\"%s\"}\n", phaseName(p));
}

// ==========================================
// Sensors
// ==========================================
// Double-read confirmation (anti-glitch): a switch/barrier value is accepted only
// if two reads SENSOR_CONFIRM_MS apart agree. If they disagree (spike/noise),
// retry; if still no agreement, keep the last confirmed value for that pin.
const uint32_t SENSOR_CONFIRM_MS = 5;
static int8_t lastStable[40] = {
  -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
  -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1 };
static int readConfirmed(uint8_t p) {
  for (int tries = 0; tries < 3; tries++) {
    int a = digitalRead(p);
    delay(SENSOR_CONFIRM_MS);
    int b = digitalRead(p);
    if (a == b) { if (p < 40) lastStable[p] = (int8_t)a; return a; }
  }
  if (p < 40 && lastStable[p] >= 0) return lastStable[p];
  return digitalRead(p);
}
static inline bool isHigh(uint8_t p) { return readConfirmed(p) != LOW; }
static inline bool isLow(uint8_t p)  { return readConfirmed(p) == LOW; }
static inline bool rawHigh(uint8_t p) { return digitalRead(p) != LOW; }

// ==========================================
// Safety
// ==========================================
static void safeOff() {
  for (uint8_t i = 0; i < sizeof(SAFE_OFF_PINS); i++) digitalWrite(SAFE_OFF_PINS[i], LOW);
}

// ==========================================
// Wait helpers (timeout + abort)
// ==========================================
#define CONFIRM_MS 30   // a reed switch must read "reached" continuously for this long before we trust it
#define WAIT_WHILE(cond, ms)                                                   \
  do {                                                                         \
    uint32_t _t0 = millis();                                                   \
    for (;;) {                                                                 \
      if (abortFlag) { safeOff(); return OF_ABORTED; }                         \
      if (millis() - _t0 > (uint32_t)(ms)) { safeOff(); return OF_TIMEOUT; }   \
      if (!(cond)) {                                                           \
        uint32_t _c0 = millis(); bool _stable = true;                          \
        while (millis() - _c0 < CONFIRM_MS) {                                  \
          if (abortFlag) { safeOff(); return OF_ABORTED; }                     \
          if (cond) { _stable = false; break; }                                \
          delay(1);                                                            \
        }                                                                      \
        if (_stable) break;                                                    \
      }                                                                        \
      delay(1);                                                                \
    }                                                                          \
  } while (0)

#define TRY(call)                                                              \
  do {                                                                         \
    uint32_t _s = millis();                                                    \
    Fault _f = (call);                                                         \
    if (verbose) say("  %-28s %6lu ms\n", #call, (unsigned long)(millis() - _s)); \
    if (_f != OF_OK) { if (!faultStep) faultStep = #call; return _f; }         \
  } while (0)

static Fault waitMs(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    if (abortFlag) return OF_ABORTED;
    delay(1);
  }
  return OF_OK;
}

// ==========================================
// Primitives (each = one WAIT_WHILE from the original code)
// ==========================================
static Fault moveTableToVacuum() {
  digitalWrite(Move_Table_TO_Vacuum, HIGH);
  WAIT_WHILE(isLow(RS_Table_vacum_position), TO_TABLE_MOVE_MS);
  digitalWrite(Move_Table_TO_Vacuum, LOW);
  return OF_OK;
}
static Fault moveTableToSaw() {
  digitalWrite(Move_Table_TO_belt, HIGH);
  WAIT_WHILE(isLow(RS_Table_Saw_position), TO_TABLE_MOVE_MS);
  digitalWrite(Move_Table_TO_belt, LOW);
  return OF_OK;
}
static Fault moveTableToBeltPos() {
  digitalWrite(Move_Table_TO_belt, HIGH);
  WAIT_WHILE(isLow(RS_Table_belt_position), TO_TABLE_MOVE_MS);
  digitalWrite(Move_Table_TO_belt, LOW);
  return OF_OK;
}
static Fault moveVacuumToTable() {
  digitalWrite(Move_Vacuum_To_TablePin, HIGH);
  WAIT_WHILE(isLow(RS_Vacum_Table_position), TO_VACUUM_MOVE_MS);
  digitalWrite(Move_Vacuum_To_TablePin, LOW);
  return OF_OK;
}
static Fault moveVacuumToOven() {
  digitalWrite(Move_Vacuum_To_OvenPin, HIGH);
  WAIT_WHILE(isLow(RS_Vacum_Oven_position), TO_VACUUM_MOVE_MS);
  digitalWrite(Move_Vacuum_To_OvenPin, LOW);
  return OF_OK;
}
static Fault moveOvenOutside() {
  digitalWrite(Move_Oven_outside, HIGH);
  WAIT_WHILE(isLow(RS_Oven_Feed_Out), TO_OVEN_FEED_MS);
  digitalWrite(Move_Oven_outside, LOW);
  return OF_OK;
}
static Fault moveOvenInside() {
  digitalWrite(Move_Oven_inside, HIGH);
  WAIT_WHILE(isLow(RS_Oven_Feed_In), TO_OVEN_FEED_MS);
  digitalWrite(Move_Oven_inside, LOW);
  return OF_OK;
}
static Fault waitPieceAtEntry() {
  WAIT_WHILE(isHigh(Oven_Light_Bar), TO_PIECE_ARRIVE_MS);
  return OF_OK;
}
static Fault runBelt() {
  digitalWrite(Belt_Motor, HIGH);
  WAIT_WHILE(isHigh(Belt_Light_Bar), TO_BELT_MS);
  TRY(waitMs(2000));
  digitalWrite(Belt_Motor, LOW);
  return OF_OK;
}

// ==========================================
// High-level operations
// ==========================================
static Fault doHome() {
  homed = false;
  setPhase(PH_HOMING);
  TRY(moveTableToVacuum());
  TRY(moveVacuumToTable());
  TRY(moveOvenOutside());
  homed = true;
  setPhase(PH_IDLE);
  return OF_OK;
}

static Fault doCycle() {
  if (!homed) return OF_NOT_HOMED;

  setPhase(PH_WAIT_PIECE);
  TRY(waitPieceAtEntry());
  TRY(waitMs(2000));

  setPhase(PH_LOAD_OVEN);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Oven_DoorPin, HIGH);
  TRY(waitMs(1000));
  TRY(moveOvenInside());
  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Oven_Light, HIGH);
  digitalWrite(Compressor, LOW);

  setPhase(PH_BAKING);
  TRY(waitMs(3000));
  digitalWrite(Oven_Light, LOW);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Oven_DoorPin, HIGH);
  TRY(waitMs(1000));

  setPhase(PH_UNLOAD_OVEN);
  TRY(moveOvenOutside());
  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Compressor, LOW);

  setPhase(PH_TO_TABLE);
  TRY(moveVacuumToOven());
  digitalWrite(Compressor, HIGH);
  digitalWrite(Gripper, LOW);
  digitalWrite(Vacuum_Valve, HIGH);
  TRY(waitMs(500));
  digitalWrite(Gripper, HIGH);
  TRY(waitMs(500));
  digitalWrite(Vacuum_Valve, LOW);
  TRY(moveVacuumToTable());
  digitalWrite(Vacuum_Valve, HIGH);
  TRY(waitMs(500));
  digitalWrite(Gripper, LOW);
  TRY(waitMs(500));
  digitalWrite(Vacuum_Valve, LOW);
  digitalWrite(Compressor, LOW);

  setPhase(PH_CUTTING);
  TRY(moveTableToSaw());
  digitalWrite(Saw_Motor, HIGH);
  TRY(waitMs(2000));
  digitalWrite(Compressor, HIGH);
  digitalWrite(Saw_Motor, LOW);

  setPhase(PH_TO_BELT);
  TRY(moveTableToBeltPos());
  digitalWrite(Table_Valve, HIGH);
  TRY(waitMs(500));
  digitalWrite(Table_Valve, LOW);
  digitalWrite(Compressor, LOW);

  setPhase(PH_EJECTING);
  TRY(runBelt());
  TRY(moveTableToVacuum());

  setPhase(PH_IDLE);
  cyclesDone++;
  return OF_OK;
}

static Fault doJog(char motor, int ms) {
  if (ms < 50) ms = 300;
  if (ms > 15000) ms = 15000;
  int onPin, offPin;
  switch (toupper((unsigned char)motor)) {
    case 'V': onPin = Move_Table_TO_Vacuum;    offPin = Move_Table_TO_belt;      break;
    case 'B': onPin = Move_Table_TO_belt;      offPin = Move_Table_TO_Vacuum;    break;
    case 'T': onPin = Move_Vacuum_To_TablePin; offPin = Move_Vacuum_To_OvenPin;  break;
    case 'O': onPin = Move_Vacuum_To_OvenPin;  offPin = Move_Vacuum_To_TablePin; break;
    case 'I': onPin = Move_Oven_inside;        offPin = Move_Oven_outside;       break;
    case 'U': onPin = Move_Oven_outside;       offPin = Move_Oven_inside;        break;
    default: return OF_BAD_ARG;
  }
  digitalWrite(offPin, LOW);
  digitalWrite(onPin, HIGH);
  TRY(waitMs((uint32_t)ms));
  digitalWrite(onPin, LOW);
  return OF_OK;
}

static Fault doN(int n) {
  if (n < 1 || n > 1000) return OF_BAD_ARG;
  for (int i = 0; i < n; i++) TRY(doCycle());
  return OF_OK;
}

// ==========================================
// Command execution (runs in the motion task)
// ==========================================
static Fault runCommand(const Cmd& c) {
  switch (c.type) {
    case 'H': return doHome();
    case 'C': return doCycle();
    case 'N': return doN(c.count);
    case 'J': return doJog((char)c.arg2, c.count);
  }
  return OF_BAD_ARG;
}

void executeAndReport(const Cmd& c) {
  faultStep = nullptr;
  uint32_t t0 = millis();
  Fault f = runCommand(c);
  uint32_t dt = millis() - t0;
  safeOff();
  lastFault = f;

  if (f == OF_OK) {
    say("{\"event\":\"done\",\"cmd\":\"%c\",\"count\":%d,\"ms\":%lu,\"command_id\":\"%s\"}\n",
        c.type, c.count, (unsigned long)dt, c.cmd_id);
  } else {
    homed = false;   // positions/oven-feed state can no longer be trusted; re-home required
    say("{\"event\":\"fault\",\"cmd\":\"%c\",\"code\":\"%s\",\"step\":\"%s\",\"phase\":\"%s\",\"ms\":%lu,\"command_id\":\"%s\"}\n",
        c.type, faultName(f), faultStep ? faultStep : "-", phaseName(phase), (unsigned long)dt, c.cmd_id);
  }
  busy = false;
}

void motionTask(void*) {
  Cmd c;
  for (;;) {
    if (xQueueReceive(cmdQueue, &c, portMAX_DELAY) == pdTRUE) executeAndReport(c);
  }
}

// ==========================================
// Serial console (runs in loop())
// ==========================================
static int buildStatusJson(char* out, size_t outSize) {
  return snprintf(out, outSize,
      "{\"event\":\"status\",\"busy\":%s,\"homed\":%s,\"phase\":\"%s\",\"cycles_done\":%lu,"
      "\"last_fault\":\"%s\",\"piece_present\":%s,\"belt_clear\":%s,\"verbose\":%s}\n",
      busy ? "true" : "false", homed ? "true" : "false", phaseName(phase), (unsigned long)cyclesDone,
      faultName((Fault)lastFault), isLow(Oven_Light_Bar) ? "true" : "false",
      isHigh(Belt_Light_Bar) ? "true" : "false", verbose ? "true" : "false");
}

static void printStatus() {
  char buf[380];
  buildStatusJson(buf, sizeof buf);
  say("%s", buf);
}

static void printHelp() {
  say("Commands: H | C | N <count> | S | ? | V | D (raw sensor dump) | J <V|B|T|O|I|U> [ms, def 300, max 15000]\n");
}

static void printRaw() {
  say("{\"event\":\"raw\",\"RS_Table_vacum\":%d,\"RS_Table_saw\":%d,\"RS_Table_belt\":%d,"
      "\"RS_Vac_Table\":%d,\"RS_Vac_Oven\":%d,\"RS_Oven_In\":%d,\"RS_Oven_Out\":%d,"
      "\"Oven_Light_Bar\":%d,\"Belt_Light_Bar\":%d}\n",
      digitalRead(RS_Table_vacum_position), digitalRead(RS_Table_Saw_position), digitalRead(RS_Table_belt_position),
      digitalRead(RS_Vacum_Table_position), digitalRead(RS_Vacum_Oven_position),
      digitalRead(RS_Oven_Feed_In), digitalRead(RS_Oven_Feed_Out),
      digitalRead(Oven_Light_Bar), digitalRead(Belt_Light_Bar));
}

static void reject(char type, int arg, const char* why, const char* cmd_id = "") {
  say("{\"event\":\"rejected\",\"cmd\":\"%c\",\"arg\":%d,\"code\":\"%s\",\"command_id\":\"%s\"}\n",
      type, arg, why, cmd_id ? cmd_id : "");
}

static void doStopWithId(const char* id) {
  safeOff();
  abortFlag = true;
  say("{\"event\":\"stop\",\"command_id\":\"%s\"}\n", (id && id[0]) ? id : "");
}
static void doStop() { doStopWithId(""); }

static void submit(char type, int count, int arg2 = 0, const char* cmd_id = "") {
  if (busy) { reject(type, count, "BUSY", cmd_id); return; }
  Cmd c = { type, count, arg2, {0} };
  if (cmd_id && cmd_id[0]) strncpy(c.cmd_id, cmd_id, CMDID_LEN);
  abortFlag = false;
  busy = true;
  if (type == 'J') say("{\"event\":\"started\",\"cmd\":\"J\",\"motor\":\"%c\",\"ms\":%d,\"command_id\":\"%s\"}\n",
                        (char)toupper(arg2), count, c.cmd_id);
  else              say("{\"event\":\"started\",\"cmd\":\"%c\",\"count\":%d,\"command_id\":\"%s\"}\n", type, count, c.cmd_id);
  if (xQueueSend(cmdQueue, &c, 0) != pdPASS) { busy = false; reject(type, count, "QUEUE_FULL", cmd_id); }
}

void handleLine(char* line) {
  while (*line == ' ') line++;
  if (!*line) return;
  char c = (char)toupper((unsigned char)*line);
  int arg = atoi(line + 1);
  switch (c) {
    case 'S': doStop(); break;
    case '?': printStatus(); break;
    case 'V': verbose = !verbose; say("{\"event\":\"verbose\",\"value\":%s}\n", verbose ? "true" : "false"); break;
    case 'D': printRaw(); break;
    case 'H': submit('H', 0); break;
    case 'C': submit('C', 1); break;
    case 'N':
      if (arg < 1 || arg > 1000) { reject('N', arg, "BAD_ARG"); break; }
      submit('N', arg);
      break;
    case 'J': {
      char* p = line + 1;
      while (*p == ' ') p++;
      char motor = (char)toupper((unsigned char)*p);
      if (!strchr("VBTOIU", motor)) { reject('J', 0, "BAD_ARG"); break; }
      p++;
      while (*p == ' ') p++;
      int ms = atoi(p);
      submit('J', ms > 0 ? ms : 300, motor);
      break;
    }
    default: printHelp(); break;
  }
}

// ==========================================
// MQTT - tiny manual JSON field extraction (flat objects only, no nesting)
// ==========================================
static bool jsonFindString(const char* json, const char* key, char* out, size_t outSize) {
  char pat[24]; snprintf(pat, sizeof pat, "\"%s\"", key);
  const char* p = strstr(json, pat);
  if (!p) return false;
  p = strchr(p + strlen(pat), ':');
  if (!p) return false;
  p++;
  while (*p == ' ') p++;
  if (*p != '"') return false;
  p++;
  size_t i = 0;
  while (*p && *p != '"' && i < outSize - 1) out[i++] = *p++;
  out[i] = 0;
  return true;
}
static bool jsonFindInt(const char* json, const char* key, int* out) {
  char pat[24]; snprintf(pat, sizeof pat, "\"%s\"", key);
  const char* p = strstr(json, pat);
  if (!p) return false;
  p = strchr(p + strlen(pat), ':');
  if (!p) return false;
  p++;
  while (*p == ' ') p++;
  *out = atoi(p);
  return true;
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  if (length >= 250) { reject('?', 0, "PAYLOAD_TOO_LONG"); return; }
  char buf[256];
  memcpy(buf, payload, length);
  buf[length] = 0;

  char cmdType[4] = {0};
  char cmdId[CMDID_LEN + 1] = {0};
  char motorStr[4] = {0};
  int  count = 0;
  int  ms    = 0;

  jsonFindString(buf, "cmd", cmdType, sizeof cmdType);
  jsonFindString(buf, "command_id", cmdId, sizeof cmdId);
  jsonFindInt(buf, "count", &count);
  jsonFindInt(buf, "ms", &ms);
  jsonFindString(buf, "motor", motorStr, sizeof motorStr);

  if (!cmdType[0]) { reject('?', 0, "BAD_JSON", cmdId); return; }
  char c = (char)toupper((unsigned char)cmdType[0]);

  if (isDuplicateCmdId(cmdId)) { reject(c, count, "DUPLICATE", cmdId); return; }

  switch (c) {
    case 'H':
      rememberCmdId(cmdId);
      submit('H', 0, 0, cmdId);
      break;
    case 'C':
      rememberCmdId(cmdId);
      submit('C', 1, 0, cmdId);
      break;
    case 'N':
      if (count < 1 || count > 1000) { reject('N', count, "BAD_ARG", cmdId); break; }
      rememberCmdId(cmdId);
      submit('N', count, 0, cmdId);
      break;
    case 'S':
      rememberCmdId(cmdId);
      doStopWithId(cmdId);
      break;
    case 'D':
      rememberCmdId(cmdId);
      printRaw();
      break;
    case 'J': {
      char motor = motorStr[0] ? (char)toupper((unsigned char)motorStr[0]) : 0;
      if (!strchr("VBTOIU", motor)) { reject('J', 0, "BAD_ARG", cmdId); break; }
      rememberCmdId(cmdId);
      submit('J', ms > 0 ? ms : 300, motor, cmdId);
      break;
    }
    default:
      reject(c, 0, "BAD_ARG", cmdId);
  }
}

static void publishHeartbeat() {
  char buf[380];
  buildStatusJson(buf, sizeof buf);
  if (xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC_STATUS, (const uint8_t*)buf, (unsigned int)strlen(buf), true);
    xSemaphoreGiveRecursive(mqttMutex);
  }
}

static void maintainNetwork() {
  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - lastWifiAttempt > WIFI_RETRY_MS) {
      lastWifiAttempt = millis();
      WiFi.disconnect();
      WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
      WiFi.setSleep(false);   // re-assert after reconnect - some cores reset this on begin()
      say("{\"event\":\"wifi_connecting\"}\n");
    }
    return;
  }
  if (xSemaphoreTakeRecursive(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (!mqttClient.connected()) {
      if (millis() - lastMqttAttempt > MQTT_RETRY_MS) {
        lastMqttAttempt = millis();
        say("{\"event\":\"mqtt_connecting\"}\n");
        if (mqttClient.connect(MQTT_CLIENT_ID, nullptr, nullptr, TOPIC_LWT, 1, true, "offline")) {
          mqttClient.subscribe(TOPIC_CMD);
          mqttClient.publish(TOPIC_LWT, "online", true);
          say("{\"event\":\"mqtt_connected\"}\n");
        } else {
          say("{\"event\":\"mqtt_connect_failed\",\"rc\":%d}\n", mqttClient.state());
        }
      }
    } else {
      mqttClient.loop();
    }
    xSemaphoreGiveRecursive(mqttMutex);
  }
}

// ==========================================
// Arduino entry points
// ==========================================
void setup() {
  Serial.begin(115200);
  printMutex = xSemaphoreCreateMutex();
  mqttMutex  = xSemaphoreCreateRecursiveMutex();

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);   // disable WiFi modem-sleep: it was adding 100s-1000+ms of
                          // scheduling jitter to the light-barrier polling loops
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  mqttClient.setServer(MQTT_HOST, MQTT_PORT);
  mqttClient.setCallback(mqttCallback);
  mqttClient.setBufferSize(512);
  lastWifiAttempt = millis();

  pinMode(RS_Table_vacum_position, INPUT);
  pinMode(RS_Table_belt_position, INPUT);
  pinMode(Belt_Light_Bar, INPUT);
  pinMode(RS_Table_Saw_position, INPUT);
  pinMode(RS_Vacum_Table_position, INPUT);
  pinMode(RS_Vacum_Oven_position, INPUT);
  pinMode(Oven_Light_Bar, INPUT);
  pinMode(RS_Oven_Feed_In, INPUT);
  pinMode(RS_Oven_Feed_Out, INPUT);

  pinMode(Move_Table_TO_belt, OUTPUT);
  pinMode(Move_Table_TO_Vacuum, OUTPUT);
  pinMode(Belt_Motor, OUTPUT);
  pinMode(Saw_Motor, OUTPUT);
  pinMode(Move_Vacuum_To_OvenPin, OUTPUT);
  pinMode(Move_Vacuum_To_TablePin, OUTPUT);
  pinMode(Oven_Light, OUTPUT);
  pinMode(Compressor, OUTPUT);
  pinMode(Gripper, OUTPUT);
  pinMode(Vacuum_Valve, OUTPUT);
  pinMode(Oven_DoorPin, OUTPUT);
  pinMode(Table_Valve, OUTPUT);
  pinMode(Move_Oven_inside, OUTPUT);
  pinMode(Move_Oven_outside, OUTPUT);

  safeOff();
  digitalWrite(Gripper, HIGH);      // same default as the standalone version ("Gripper default position is up")
  digitalWrite(Vacuum_Valve, LOW);

  cmdQueue = xQueueCreate(1, sizeof(Cmd));
  xTaskCreatePinnedToCore(motionTask, "motion", 8192, NULL, 2, NULL, 1);

  say("{\"event\":\"boot\",\"station\":\"Oven\",\"homed\":false}\n");
  printHelp();
}

void loop() {
  maintainNetwork();
  if (millis() - lastHeartbeat > HEARTBEAT_MS) { lastHeartbeat = millis(); publishHeartbeat(); }

  static char buf[24];
  static uint8_t n = 0;
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (n == 0 && (ch == 's' || ch == 'S')) { doStop(); continue; }
    if (ch == '\n' || ch == '\r') {
      if (n) { buf[n] = 0; handleLine(buf); n = 0; }
    } else if (n < sizeof(buf) - 1) {
      buf[n++] = ch;
    }
  }
  delay(1);
}
