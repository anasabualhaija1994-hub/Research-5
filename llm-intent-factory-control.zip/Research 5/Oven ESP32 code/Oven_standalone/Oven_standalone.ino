/*
 * ============================================================================
 *  Oven - STANDALONE ESP32 firmware
 * ============================================================================
 *  Upload and the Oven runs by itself, in the same order the Python sender
 *  used to send to the Oven station. No PC, no bridge, no serial, no logging.
 *
 *    1) Oven Homing (once)
 *    2) 9 Oven cycles, one after another. Each cycle:
 *         - waits for a piece at Oven_Light_Bar (the piece detects itself,
 *           exactly like in the original firmware/Python version)
 *         - runs the full bake -> cut -> eject sequence
 * ============================================================================
 */
#include <Arduino.h>

// ==========================================
// Settings
// ==========================================
// Wait after power-up/reset before the first movement
const unsigned long START_DELAY_MS = 3000;

// Number of pieces / cycles to run
const int TOTAL_CYCLES = 9;

// ==========================================
// Pins
// ==========================================
#define RS_Table_vacum_position 36
#define RS_Table_belt_position  39
#define Belt_Light_Bar          34
#define RS_Table_Saw_position   35
#define RS_Vacum_Table_position 32
#define RS_Vacum_Oven_position  33
#define Oven_Light_Bar          25

#define Move_Table_TO_belt      23
#define Move_Table_TO_Vacuum    22
#define Belt_Motor              21
#define Saw_Motor               19
#define Move_Vacuum_To_OvenPin  18
#define Move_Vacuum_To_TablePin 17
#define Oven_Light              16
#define Compressor               4
#define Gripper                  2
#define Vacuum_Valve            14
#define Oven_DoorPin            12
#define Table_Valve             13
#define RS_Oven_Feed_In          5
#define RS_Oven_Feed_Out        15
#define Move_Oven_inside        26
#define Move_Oven_outside       27

#define WAIT_WHILE(cond) while (cond) { delay(1); }

// ==========================================
// Oven Homing (Python: OVEN_HOMING)
// ==========================================
void ovenHoming() {
  digitalWrite(Move_Table_TO_Vacuum, HIGH);
  WAIT_WHILE(digitalRead(RS_Table_vacum_position) == LOW);
  digitalWrite(Move_Table_TO_Vacuum, LOW);
  digitalWrite(Move_Vacuum_To_TablePin, HIGH);
  WAIT_WHILE(digitalRead(RS_Vacum_Table_position) == LOW);
  digitalWrite(Move_Vacuum_To_TablePin, LOW);
  digitalWrite(Move_Oven_outside, HIGH);
  WAIT_WHILE(digitalRead(RS_Oven_Feed_Out) == LOW);
  digitalWrite(Move_Oven_outside, LOW);
}

// ==========================================
// One full cycle (Python: OVEN_CYCLE)
// ==========================================
void ovenCycle() {
  WAIT_WHILE(digitalRead(Oven_Light_Bar) == HIGH);
  delay(2000);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Oven_DoorPin, HIGH);
  delay(1000);
  digitalWrite(Move_Oven_inside, HIGH);
  WAIT_WHILE(digitalRead(RS_Oven_Feed_In) == LOW);
  digitalWrite(Move_Oven_inside, LOW);
  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Oven_Light, HIGH);
  digitalWrite(Compressor, LOW);
  delay(3000);
  digitalWrite(Oven_Light, LOW);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Oven_DoorPin, HIGH);
  delay(1000);
  digitalWrite(Move_Oven_outside, HIGH);
  WAIT_WHILE(digitalRead(RS_Oven_Feed_Out) == LOW);
  digitalWrite(Move_Oven_outside, LOW);
  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Compressor, LOW);
  digitalWrite(Move_Vacuum_To_OvenPin, HIGH);
  WAIT_WHILE(digitalRead(RS_Vacum_Oven_position) == LOW);
  digitalWrite(Move_Vacuum_To_OvenPin, LOW);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Gripper, LOW);
  digitalWrite(Vacuum_Valve, HIGH);
  delay(500);
  digitalWrite(Gripper, HIGH);
  delay(500);
  digitalWrite(Vacuum_Valve, LOW);
  digitalWrite(Move_Vacuum_To_TablePin, HIGH);
  WAIT_WHILE(digitalRead(RS_Vacum_Table_position) == LOW);
  digitalWrite(Move_Vacuum_To_TablePin, LOW);
  digitalWrite(Vacuum_Valve, HIGH);
  delay(500);
  digitalWrite(Gripper, LOW);
  delay(500);
  digitalWrite(Vacuum_Valve, LOW);
  digitalWrite(Compressor, LOW);
  digitalWrite(Move_Table_TO_belt, HIGH);
  WAIT_WHILE(digitalRead(RS_Table_Saw_position) == LOW);
  digitalWrite(Move_Table_TO_belt, LOW);
  digitalWrite(Saw_Motor, HIGH);
  delay(2000);
  digitalWrite(Compressor, HIGH);
  digitalWrite(Saw_Motor, LOW);
  digitalWrite(Move_Table_TO_belt, HIGH);
  WAIT_WHILE(digitalRead(RS_Table_belt_position) == LOW);
  digitalWrite(Move_Table_TO_belt, LOW);
  digitalWrite(Table_Valve, HIGH);
  delay(500);
  digitalWrite(Table_Valve, LOW);
  digitalWrite(Compressor, LOW);
  digitalWrite(Belt_Motor, HIGH);
  WAIT_WHILE(digitalRead(Belt_Light_Bar) == HIGH);
  delay(2000);
  digitalWrite(Belt_Motor, LOW);
  digitalWrite(Move_Table_TO_Vacuum, HIGH);
  WAIT_WHILE(digitalRead(RS_Table_vacum_position) == LOW);
  digitalWrite(Move_Table_TO_Vacuum, LOW);
}

// ==========================================
// Arduino entry points
// ==========================================
void setupPins() {
  pinMode(RS_Table_vacum_position, INPUT);
  pinMode(RS_Table_belt_position, INPUT);
  pinMode(Belt_Light_Bar, INPUT);
  pinMode(RS_Table_Saw_position, INPUT);
  pinMode(RS_Vacum_Table_position, INPUT);
  pinMode(RS_Vacum_Oven_position, INPUT);
  pinMode(Oven_Light_Bar, INPUT);
  pinMode(RS_Oven_Feed_In, INPUT);
  pinMode(RS_Oven_Feed_Out, INPUT);

  pinMode(Move_Table_TO_belt, OUTPUT);
  pinMode(Move_Table_TO_Vacuum, OUTPUT);
  pinMode(Belt_Motor, OUTPUT);
  pinMode(Saw_Motor, OUTPUT);
  pinMode(Move_Vacuum_To_OvenPin, OUTPUT);
  pinMode(Move_Vacuum_To_TablePin, OUTPUT);
  pinMode(Oven_Light, OUTPUT);
  pinMode(Compressor, OUTPUT);
  pinMode(Gripper, OUTPUT);
  pinMode(Vacuum_Valve, OUTPUT);
  pinMode(Oven_DoorPin, OUTPUT);
  pinMode(Table_Valve, OUTPUT);
  pinMode(Move_Oven_inside, OUTPUT);
  pinMode(Move_Oven_outside, OUTPUT);

  // Same starting state as the original firmware
  digitalWrite(Move_Table_TO_belt, LOW);
  digitalWrite(Move_Table_TO_Vacuum, LOW);
  digitalWrite(Belt_Motor, LOW);
  digitalWrite(Saw_Motor, LOW);
  digitalWrite(Move_Vacuum_To_OvenPin, LOW);
  digitalWrite(Move_Vacuum_To_TablePin, LOW);
  digitalWrite(Oven_Light, LOW);
  digitalWrite(Compressor, LOW);
  digitalWrite(Gripper, HIGH);   // Gripper default position is up
  digitalWrite(Vacuum_Valve, LOW);
  digitalWrite(Oven_DoorPin, LOW);
  digitalWrite(Table_Valve, LOW);
  digitalWrite(Move_Oven_inside, LOW);
  digitalWrite(Move_Oven_outside, LOW);
}

bool sequenceDone = false;

void setup() {
  setupPins();
}

void loop() {
  if (!sequenceDone) {
    delay(START_DELAY_MS);   // safety delay before the first movement
    ovenHoming();
    for (int i = 0; i < TOTAL_CYCLES; i++) {
      ovenCycle();
    }
    sequenceDone = true;
  }
}
