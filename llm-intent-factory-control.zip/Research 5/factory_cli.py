#!/usr/bin/env python3
"""
Tiny client for the orchestrator service - does exactly what n8n will do:
publish one JSON request, then print the replies until the job ends.

  python factory_cli.py home
  python factory_cli.py run 1 2 3
  python factory_cli.py status
  python factory_cli.py stop
"""
import json
import os
import sys
import threading
import time

import paho.mqtt.client as mqtt

BROKER_HOST = "192.168.0.249"
BROKER_PORT = 1883
T_ORC = "factory/orchestrator"
FINAL = {"job_done", "job_failed", "job_rejected", "home_done", "home_failed", "stopped"}

if len(sys.argv) < 2 or sys.argv[1] not in ("run", "home", "status", "stop"):
    print(__doc__)
    sys.exit(1)
cmd = sys.argv[1]
job_id = f"cli-{cmd}-{int(time.time())}"
req = {"cmd": cmd, "job_id": job_id}
if cmd == "run":
    req["slots"] = [int(x) for x in sys.argv[2:]] or [1, 2, 3]

finished = threading.Event()
got_status = threading.Event()
last_status = [None]

try:
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"factory-cli-{os.getpid()}-{time.time_ns()}")
except AttributeError:
    c = mqtt.Client(client_id=f"factory-cli-{os.getpid()}-{time.time_ns()}")


sent = [False]


def on_connect(cl, u, f, rc, p=None):
    if sent[0]:                       # a reconnect must never re-send the request
        return
    sent[0] = True
    cl.subscribe([(f"{T_ORC}/event", 1), (f"{T_ORC}/status", 1), (f"{T_ORC}/lwt", 1)])
    time.sleep(0.3)
    cl.publish(f"{T_ORC}/cmd", json.dumps(req), qos=1)
    print(">>", json.dumps(req))


def on_message(cl, u, msg):
    txt = msg.payload.decode("utf-8", "replace")
    if msg.topic.endswith("/lwt"):
        if txt != "online":
            print("!! orchestrator service is OFFLINE - start orchestrator_service.py first")
        return
    if msg.topic.endswith("/status"):
        last_status[0] = txt
        if finished.is_set():
            got_status.set()
        return
    ev = json.loads(txt)
    if ev.get("job_id") != job_id:
        return
    print("<<", json.dumps(ev, ensure_ascii=False))
    if ev.get("event") in FINAL or (cmd == "status" and ev.get("event") == "status_sent"):
        finished.set()


c.on_connect = on_connect
c.on_message = on_message
c.connect(BROKER_HOST, BROKER_PORT, 30)
c.loop_start()
try:
    finished.wait(20 if cmd in ("status", "stop") else 3600)
    if cmd == "status":
        got_status.wait(2)
        if last_status[0]:
            print(json.dumps(json.loads(last_status[0]), indent=2, ensure_ascii=False))
except KeyboardInterrupt:
    pass
c.loop_stop()
