# Physical experiments: protocol as run for the paper

All commands are run from this `experiments` folder. The orchestrator service must be running and the
four stations must be online. Every attempt is logged by the orchestrator in `../logs/jobs.csv` and
`../logs/commands.csv`; `physical_experiments.py` additionally stores the MQTT traffic of each repetition in
its own folder under `results/<label>/raw_mqtt.csv`.

## Initial state (before every attempt)

1. Nine pieces in boxes 1–9: three white, three red, three blue.
2. Declare the box and gripper state: `python reset_state.py` (all boxes in the rack, gripper empty).
3. Home all stations (`--home-first`, or `home` from the CLI).

## 1) Throughput (RQ3)

Order: slots `1 4 7 2 5 8 3 6 9`. Three complete runs per mode.

```
python physical_experiments.py throughput --mode seq   --slots 1 4 7 2 5 8 3 6 9 --reps 1 --rep-start 1 --home-first --out results/seq_r1
python physical_experiments.py throughput --mode pipe  --slots 1 4 7 2 5 8 3 6 9 --reps 1 --rep-start 1 --home-first --out results/pipe_r1
python physical_experiments.py throughput --mode early --slots 1 4 7 2 5 8 3 6 9 --reps 1 --rep-start 1 --home-first --out results/early_r1
```

Increase `--rep-start` and the folder number for the next repetition. If an attempt aborts on a station fault, reset the
state (steps 1–3) and repeat the attempt under the same repetition number; the aborted attempt stays
in `../logs/jobs.csv`. In the paper: sequential 3 of 4 attempts completed, pipelined 3 of 15,
pipelined + early drop 3 of 5. Except for one network dropout, the aborted attempts ended on a problem of the
model factory or its setup (HBW out of position, box handling at the HBW, sunlight on an oven light barrier, a
piece left on the sorter belt, a piece not placed). After each event the operator switched off the motor supply
to reset the line while the controllers stayed powered; when he did so before a station had detected the problem,
the fault was reported by whichever station was moving. Root causes were not logged; they were identified by the
operator and are listed per attempt in `results/analysis/aborted_attempts_root_causes.csv` (Table 8; logged faults
in `results/analysis/aborted_attempts.csv`).

## 2) Fault injection (RQ4)

Mode: pipelined + early drop, slots `1 4 7`. Before each repetition, remove box 4 from the rack while
the HBW's box model still declares it present. The HBW reports `NO_BOX` when it pushes the missing box
onto the conveyor.

```
python physical_experiments.py fault --mode early --slots 1 4 7 --reps 5 --out results/fault
```

After each repetition put box 4 back, run `reset_state.py`, and home. In the paper the injected fault was
reached in 5 of 7 attempts; in the other two the HBW was out of position before the injected fault was reached
(reported by the system as an HBW timeout and a sorter timeout; see `aborted_attempts_root_causes.csv`).

## 3) End-to-end chat commands and operator stop (RQ4, RQ5)

Run the logger once per parser model. The n8n timestamps and the logger's clock were not synchronised in our setup (offset of at least 0.13 s, visible as negative dispatch times), so times that span both clocks are approximate:

```
python physical_experiments.py e2e --label deepseek --out results/e2e_deepseek
python physical_experiments.py e2e --label claude --out results/e2e_claude
```

Then type in the n8n chat, waiting for each reply: `حالة المصنع`, `جهز المصنع`, `process box 1`,
`شغّل الصندوقين ٢ و٣`, then `وقف` about 50 s after the two-box job was accepted, `status`, `home the line`.

## 4) Analysis

```
python analyze_physical.py results ../logs
python make_figures.py results ../benchmark/analysis/table_overall.csv figs
```

`analyze_physical.py` writes the throughput, fault, end-to-end and stop tables, station utilisation
(window = first to last piece completion, waiting-for-piece phases excluded) and the list of aborted
attempts to `results/analysis/`.

## Folder notes

- `results/<mode>_r<n>/`: one folder per repetition used in the paper. `early_r3/` holds the attempt that
  aborted on the HBW network dropout; its orchestrator job ID carries the label r2
  (`exp-early-r2-1791117149`) although it was the third early-drop repetition. The completed third early-drop run is `early_r3b/` (job
  `exp-early-r3-1791117841`).
- `results_commissioning/`: MQTT log of protocol-development runs (other piece orders),
  not used in the paper.
- `smoke/`: short functional checks before the experiments.

## 5) Physical check of the post-experiment fixes

The output goes to `experiments/review_check/` (not under `results/`, so that `analyze_physical.py` does not pick it up). Run with the fixed `orchestrator_service.py`, the new workflow imported into n8n and the logger running:

```
python physical_experiments.py e2e --label review --out review_check
```

Before every attempt: `python factory_cli.py home` and `python experiments/reset_state.py` (must print
`HBW OK boxes=RRRRRRRRR`).

1. **Stop during the preflight (3 attempts).** `python experiments/stop_in_preflight.py`. The script waits for
   a heartbeat round, sends `run 1` and, 1 s later from the same MQTT client, `stop`; the preflight waits for
   the next heartbeat round (about 5 s), so the stop always arrives inside it. Pass = `job_rejected` with reason
   `stopped`, no `job_accepted`, no station motion command. (Typing `run` and `stop` in two terminals does not
   control the order or the timing and is not used.)
2. **Stop words in the chat (3 attempts).** `python factory_cli.py run 1`; while the HBW moves, type `وقف`,
   then `stop`, then `أوقف المصنع` in the n8n chat (one per attempt). Pass = the execution takes the
   "Stop (deterministic)" branch (no LLM call), `job_failed` with `stop requested`, all stations report `stop`,
   no motion command afterwards.
3. **Station offline during a run (1 attempt).** `python factory_cli.py run 1`; while the HBW retrieves the box,
   cut the power of the oven ESP32. The broker publishes the oven's Last Will after the MQTT keep-alive
   timeout (about 22 s), so this cannot be done reliably during a `home` (up to 18 s, median 8 s, so the Last Will would arrive at or after its end); the Last Will during homing is
   covered by the simulator test `tests/run_scenario.sh lwt_in_home`. Pass = STOP to all stations and
   `job_failed` with `oven went offline` after the Last Will, no motion command afterwards.

Analysis (one clock, the logger's; `e2e.csv` is not used for timing because the n8n and logger clocks are
not synchronised):

```
python analyze_review_check.py review_check/raw_mqtt.csv
```

Result (`review_check/analysis/review_check_summary.csv`): experiment 1 3/3, experiment 2 3/3,
experiment 3 1/1 pass.

## 6) Session 2: heartbeat watchdog, end-to-end commands, clock offset (28 October 2026)

Released `orchestrator_service.py` (heartbeat watchdog, `WATCHDOG_S = 7.0`) and the released workflow
(`factory_intent_workflow_.json`, restricted count rule and stop-word path). Data in `experiments/session2/`.

1. **Clock offset before.** Import `session2/workflow_clock.json` into n8n (GET `/webhook/clock` returns
   `Date.now()`), then `python session2/clock_offset.py --out clock_before.csv` (50 probes; offset = n8n time
   minus the midpoint of the request).
2. **Watchdog (6 trials).** `python physical_experiments.py e2e --label watchdog --out session2/watchdog_check`,
   then per trial `reset_state.py`, `factory_cli.py home`, `factory_cli.py run 1` and, while the HBW retrieves
   the box, cut the power of the oven ESP32. Pass = `job_failed` with `... lost: no status for ... s (watchdog)`,
   stop to all stations, no motion command afterwards. In trial 3 the grabber's USB cable was disconnected
   accidentally before the oven's, so the watchdog reported the grabber; one extra oven trial was run
   (`session2/watchdog_check2`).
3. **End-to-end (7 commands per model).** Logger per model (`--label deepseek --out session2/e2e_deepseek`,
   `--label claude --out session2/e2e_claude`), `DEFAULT_MODEL` set in the Normalize node, chat cleared, then
   the seven commands of section 3. `e2e_deepseek_aborted/` is a first DeepSeek attempt that ended on an HBW
   stall at the conveyor (root cause identified by the operator: the horizontal axis reached its reference
   switch, but the switch was not detected) and was repeated from the start. Claude's `status` and `home the line` were logged
   separately (`e2e_claude_part2/`) because the logger had been stopped after the stop command.
4. **Clock offset after.** `clock_after.csv` (after DeepSeek), `clock_after2.csv` (after Claude's first five
   commands) and `clock_after3.csv` (after `e2e_claude_part2`).

Analysis:

```
python analyze_session2.py session2
python replay_watchdog.py 7 results/*/raw_mqtt.csv results_commissioning/raw_mqtt.csv review_check/raw_mqtt.csv
```

Result: watchdog stop 7.1-9.4 s after the lost station's last status (median 7.6 s, 6/6), stop fan-out
within 2 ms, no motion command afterwards; the oven's Last Will 22.2-24.8 s after its last status in all six power cuts (22.5-24.8 s in the five trials
reported by the oven; in trial 3 the watchdog reported the grabber); the logger receives each message slightly
after the broker, so these delays can be below the broker's 22.5 s timeout. Median
clock offsets 41, 6, -13 and 73 ms (median round trip 157-162 ms), not corrected.
