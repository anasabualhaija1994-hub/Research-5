#!/usr/bin/env python3
"""
Physical experiments on the real factory (talks to orchestrator_service.py over MQTT).
Every MQTT message on factory/# is also written to raw_mqtt.csv for traceability.

  python physical_experiments.py throughput --mode seq   --reps 5
  python physical_experiments.py throughput --mode pipe  --reps 5      # pipelined, no early drop
  python physical_experiments.py throughput --mode early --reps 5      # pipelined + early drop (proposed)
  python physical_experiments.py fault --reps 5
  python physical_experiments.py e2e --label deepseek                  # then type commands in the n8n chat

Options: --broker 192.168.0.249  --slots 1 2 3  --out results  --yes (no prompts; simulator only)
"""
import argparse
import csv
import json
import os
import sys
import threading
import time
from datetime import datetime

import paho.mqtt.client as mqtt

STATIONS = ("hbw", "grabber", "oven", "colorsorter")
T_ORC = "factory/orchestrator"
FINAL = {"job_done", "job_failed", "job_rejected", "home_done", "home_failed", "stopped", "status_sent"}
RUN_TIMEOUT_S = 1800
HOME_TIMEOUT_S = 240


def now_iso():
    return datetime.now().isoformat(timespec="milliseconds")


class Bus:
    """MQTT connection + raw log + per-job event store."""

    def __init__(self, host, port, outdir):
        self.outdir = outdir
        os.makedirs(outdir, exist_ok=True)
        self.lock = threading.Condition()
        self.events = {}            # job_id -> [(t, event_dict)]
        self.log = []               # (t, topic, retained, payload)
        self.live = {}              # station -> (t, status dict)   (non-retained only)
        self.orc_online = None
        self.listeners = []
        raw_path = os.path.join(outdir, "raw_mqtt.csv")
        new = not os.path.exists(raw_path)
        self.raw = open(raw_path, "a", newline="", encoding="utf-8")
        self.raw_w = csv.writer(self.raw)
        if new:
            self.raw_w.writerow(["t_unix", "ts", "topic", "retained", "payload"])
        try:
            self.c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"exp-{int(time.time() * 1000)}")
        except AttributeError:
            self.c = mqtt.Client(client_id=f"exp-{int(time.time() * 1000)}")
        self.c.on_connect = lambda c, u, f, rc, p=None: c.subscribe("factory/#", 1)
        self.c.on_message = self._on_msg
        self.c.connect(host, port, 30)
        self.c.loop_start()
        time.sleep(1.0)
        if self.orc_online != "online":
            sys.exit("!! orchestrator service is not online - start orchestrator_service.py first")

    def _on_msg(self, c, u, msg):
        t = time.time()
        txt = msg.payload.decode("utf-8", "replace")
        with self.lock:
            self.raw_w.writerow([f"{t:.3f}", now_iso(), msg.topic, int(msg.retain), txt])
            self.raw.flush()
            self.log.append((t, msg.topic, msg.retain, txt))
            parts = msg.topic.split("/")
            if msg.topic == f"{T_ORC}/lwt":
                self.orc_online = txt
            elif msg.topic == f"{T_ORC}/event":
                try:
                    ev = json.loads(txt)
                except ValueError:
                    ev = None
                if ev:
                    self.events.setdefault(ev.get("job_id"), []).append((t, ev))
                    for fn in self.listeners:
                        fn(t, ev)
            elif len(parts) == 3 and parts[1] in STATIONS and parts[2] == "status" and not msg.retain:
                try:
                    self.live[parts[1]] = (t, json.loads(txt))
                except ValueError:
                    pass
            self.lock.notify_all()

    def send(self, req):
        self.c.publish(f"{T_ORC}/cmd", json.dumps(req), qos=1)
        return time.time()

    def wait(self, job_id, names, timeout):
        end = time.time() + timeout
        with self.lock:
            while True:
                for t, ev in self.events.get(job_id, []):
                    if ev.get("event") in names:
                        return t, ev
                left = end - time.time()
                if left <= 0:
                    return None, None
                self.lock.wait(min(left, 1.0))

    def first(self, job_id, names=None):
        for t, ev in self.events.get(job_id, []):
            if names is None or ev.get("event") in names:
                return t, ev
        return None, None

    def close(self):
        self.c.loop_stop()
        self.raw.close()


def append_csv(path, header, row):
    new = not os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new:
            w.writerow(header)
        w.writerow(row)


def ask(args, text):
    if args.yes:
        print(f"[auto] {text}")
        return ""
    return input(f"\n>>> {text}\n    [Enter] = go,  s = skip,  q = quit : ").strip().lower()


def home(bus, tag):
    jid = f"exp-home-{tag}-{int(time.time())}"
    t0 = bus.send({"cmd": "home", "job_id": jid})
    t, ev = bus.wait(jid, {"home_done", "home_failed", "job_rejected"}, HOME_TIMEOUT_S)
    ok = bool(ev) and ev["event"] == "home_done"
    print(f"    home: {ev['event'] if ev else 'TIMEOUT'} ({(t or time.time()) - t0:.1f}s) {'' if ok else ev}")
    return ok, (t - t0) if t else None


def run_job(bus, job_id, slots, early_drop, retry_home=True):
    """Send one run and wait for its end. Returns dict with timing and result."""
    t_sent = bus.send({"cmd": "run", "slots": slots, "job_id": job_id, "early_drop": early_drop})
    t_end, ev = bus.wait(job_id, {"job_done", "job_failed", "job_rejected"}, RUN_TIMEOUT_S)
    if ev and ev["event"] == "job_rejected" and retry_home and any("not homed" in p for p in ev.get("problems", [])):
        print("    not homed -> homing once and retrying")
        ok, _ = home(bus, "auto")
        if ok:
            return run_job(bus, job_id + "b", slots, early_drop, retry_home=False)
    t_acc, _ = bus.first(job_id, {"job_accepted"})
    return {"job_id": job_id, "t_sent": t_sent, "t_accepted": t_acc, "t_end": t_end,
            "result": ev["event"] if ev else "timeout", "ev": ev or {}}


# ------------------------------------------------------------------ throughput
def cmd_throughput(bus, args):
    path = os.path.join(args.out, "throughput.csv")
    header = ["ts", "mode", "rep", "slots", "result", "makespan_s", "exec_sum_s", "per_piece_s",
              "orc_total_s", "piece_cycles_s", "colors", "job_ids", "error"]
    early = {"seq": True, "pipe": False, "early": True}[args.mode]
    for rep in range(args.rep_start, args.rep_start + args.reps):
        a = ask(args, f"[{args.mode} rep {rep}] put a workpiece in the boxes of slots {args.slots}, factory idle")
        if a == "q":
            break
        if a == "s":
            continue
        if args.home_first:                 # every repetition starts from the same homed state
            h_ok, _ = home(bus, f"pre-{args.mode}-r{rep}")
            if not h_ok:
                print("  => home failed - repetition NOT started (nothing written). Fix the line and run again.")
                break
        tag = f"exp-{args.mode}-r{rep}-{int(time.time())}"
        jobs = []
        if args.mode == "seq":
            for s in args.slots:
                r = run_job(bus, f"{tag}-s{s}", [s], early)
                jobs.append(r)
                print(f"    slot {s}: {r['result']}  {((r['t_end'] or 0) - (r['t_accepted'] or 0)):.1f}s")
                if r["result"] != "job_done":
                    break
        else:
            r = run_job(bus, tag, list(args.slots), early)
            jobs.append(r)
        ok = all(j["result"] == "job_done" for j in jobs) and len(jobs) == (len(args.slots) if args.mode == "seq" else 1)
        starts = [j["t_accepted"] for j in jobs if j["t_accepted"]]
        ends = [j["t_end"] for j in jobs if j["t_end"]]
        makespan = (max(ends) - min(starts)) if ok else None
        exec_sum = sum(j["t_end"] - j["t_accepted"] for j in jobs) if ok else None
        pieces = [p for j in jobs for p in j["ev"].get("pieces", [])]
        cycles = []
        for j in jobs:      # piece_done events carry cycle_s
            cycles += [ev.get("cycle_s") for _, ev in bus.events.get(j["job_id"], []) if ev.get("event") == "piece_done"]
        err = "; ".join(str(j["ev"].get("error") or j["ev"].get("problems") or "") for j in jobs if j["result"] != "job_done")
        append_csv(path, header, [
            now_iso(), args.mode, rep, " ".join(map(str, args.slots)), "ok" if ok else "failed",
            f"{makespan:.1f}" if makespan else "", f"{exec_sum:.1f}" if exec_sum else "",
            f"{makespan / len(args.slots):.1f}" if makespan else "",
            " ".join(str(j["ev"].get("total_s", "")) for j in jobs),
            " ".join(str(c) for c in cycles), " ".join(str(p.get("color")) for p in pieces),
            " ".join(j["job_id"] for j in jobs), err])
        print(f"  => {args.mode} rep {rep}: {'OK' if ok else 'FAILED'}  makespan={makespan and round(makespan, 1)} s")
        if err:
            print(f"     reason: {err}")
        if not ok:
            a = ask(args, "run failed - fix the factory (it will be homed next)")
            if a == "q":
                break
            home(bus, f"after-fail-r{rep}")


# ------------------------------------------------------------------ fault injection
def cmd_fault(bus, args):
    path = os.path.join(args.out, "fault.csv")
    header = ["ts", "rep", "job_id", "fault_station", "fault_code", "t_fault_to_job_failed_s", "t_fault_to_first_stop_s",
              "t_fault_to_all_stops_s", "t_fault_to_quiescent_s", "motion_cmds_after_fault", "chat_visible_error",
              "recovery_home_s", "home_ok", "note"]
    for rep in range(1, args.reps + 1):
        a = ask(args, f"[fault rep {rep}/{args.reps}] pieces in slots {args.slots}, factory idle. "
                      f"After the job starts, inject ONE fault (e.g. stop the oven vacuum / block a light barrier)")
        if a == "q":
            break
        if a == "s":
            continue
        jid = f"exp-fault-r{rep}-{int(time.time())}"
        n0 = len(bus.log)
        if args.yes and args.sim_fault:
            threading.Timer(args.sim_fault, lambda: bus.c.publish("sim/fault", "oven")).start()
        r = run_job(bus, jid, list(args.slots), True)
        t_fail = r["t_end"] if r["result"] == "job_failed" else None
        time.sleep(3.0)                       # let STOP + status settle
        with bus.lock:
            log = bus.log[n0:]
        # first station fault/rejected event (or a station going offline) after the job started
        t_fault, f_st, f_code = None, "", ""
        for t, topic, ret, txt in log:
            p = topic.split("/")
            if len(p) == 3 and p[1] in STATIONS:
                if p[2] == "event":
                    try:
                        e = json.loads(txt)
                    except ValueError:
                        continue
                    if e.get("event") in ("fault", "rejected"):
                        t_fault, f_st, f_code = t, p[1], str(e.get("code"))
                        break
                elif p[2] == "lwt" and txt != "online" and not ret:
                    t_fault, f_st, f_code = t, p[1], "offline"
                    break
        stops, motion_after = [], 0
        for t, topic, ret, txt in log:
            p = topic.split("/")
            if len(p) == 3 and p[1] in STATIONS and p[2] == "cmd" and t_fault and t >= t_fault:
                try:
                    c = json.loads(txt).get("cmd")
                except ValueError:
                    c = "?"
                if c == "S":
                    stops.append((t, p[1]))
                else:
                    motion_after += 1
        t_first_stop = min(t for t, _ in stops) if stops else None
        first_per_st = {}
        for t, s in stops:
            first_per_st.setdefault(s, t)
        t_all_stops = max(first_per_st.values()) if set(first_per_st) >= set(STATIONS) else None
        # quiescent = every station reported a live status with busy=false after the last STOP
        t_quiet = None
        if t_all_stops:
            seen = {}
            for t, topic, ret, txt in log:
                p = topic.split("/")
                if t > t_all_stops and len(p) == 3 and p[1] in STATIONS and p[2] == "status" and not ret:
                    try:
                        if not json.loads(txt).get("busy"):
                            seen.setdefault(p[1], t)
                    except ValueError:
                        pass
            if set(seen) >= set(STATIONS):
                t_quiet = max(seen.values())
        rel = lambda x: f"{x - t_fault:.3f}" if (x and t_fault) else ""
        err = r["ev"].get("error", "")
        print(f"    fault: {f_st} {f_code} | job_failed +{rel(t_fail)} s | STOP all +{rel(t_all_stops)} s | "
              f"quiescent +{rel(t_quiet)} s | motion cmds after fault: {motion_after}")
        print(f"    error shown to operator: {err}")
        a = ask(args, "remove the fault physically (re-insert boxes/pieces if needed); the factory will be homed")
        h_ok, h_s = (False, None) if a == "q" else home(bus, f"recover-r{rep}")
        append_csv(path, header, [now_iso(), rep, jid, f_st, f_code, rel(t_fail), rel(t_first_stop), rel(t_all_stops),
                                  rel(t_quiet), motion_after, err, f"{h_s:.1f}" if h_s else "", int(h_ok),
                                  "" if t_fault else f"no station fault seen (result={r['result']})"])
        if a == "q":
            break


# ------------------------------------------------------------------ end-to-end from the chat
def cmd_e2e(bus, args):
    """Passive: log every job the n8n chat sends (job_id = n8n-<cmd>-<t_chat_ms>-<t_validated_ms>)."""
    path = os.path.join(args.out, "e2e.csv")
    header = ["ts", "label", "job_id", "cmd", "result", "llm_validate_s", "dispatch_preflight_s", "exec_s", "total_s", "detail"]
    done = set()
    print(f"Listening. Type commands in the n8n chat (model label = {args.label}). Ctrl+C to finish.")

    def on_event(t, ev):
        jid = str(ev.get("job_id") or "")
        if not jid.startswith("n8n-") or jid in done or ev.get("event") not in FINAL:
            return
        if ev.get("event") == "status_sent" and not jid.startswith("n8n-status"):
            return
        parts = jid.split("-")
        if len(parts) < 4:
            return
        done.add(jid)
        cmd, t_chat, t_val = parts[1], int(parts[2]) / 1000, int(parts[3]) / 1000
        t_first = bus.first(jid)[0] or t
        detail = ev.get("error") or ev.get("problems") or ev.get("per_piece_s") or ""
        row = [now_iso(), args.label, jid, cmd, ev["event"], f"{t_val - t_chat:.3f}", f"{t_first - t_val:.3f}",
               f"{t - t_first:.3f}", f"{t - t_chat:.3f}", detail]
        append_csv(path, header, row)
        print(f"  {cmd:6s} {ev['event']:12s} LLM+validate {t_val - t_chat:6.2f}s | dispatch+preflight {t_first - t_val:5.2f}s | "
              f"factory {t - t_first:7.1f}s | total {t - t_chat:7.1f}s")
        if args.count and len(done) >= args.count:
            stop.set()

    stop = threading.Event()
    bus.listeners.append(on_event)
    try:
        while not stop.is_set():
            time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    print(f"{len(done)} chat jobs logged -> {path}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("experiment", choices=["throughput", "fault", "e2e"])
    ap.add_argument("--mode", choices=["seq", "pipe", "early"], default="early")
    ap.add_argument("--reps", type=int, default=5)
    ap.add_argument("--rep-start", type=int, default=1, help="number of the first repetition (when reps are run one by one)")
    ap.add_argument("--home-first", action="store_true", help="throughput: home the line before every repetition")
    ap.add_argument("--slots", type=int, nargs="+", default=[1, 2, 3])
    ap.add_argument("--label", default="model")
    ap.add_argument("--count", type=int, default=0, help="e2e: stop after N chat jobs")
    ap.add_argument("--broker", default="192.168.0.249")
    ap.add_argument("--port", type=int, default=1883)
    ap.add_argument("--out", default="results")
    ap.add_argument("--yes", action="store_true", help="no prompts (simulator tests only)")
    ap.add_argument("--sim-fault", type=float, default=0, help=argparse.SUPPRESS)
    args = ap.parse_args()
    bus = Bus(args.broker, args.port, args.out)
    try:
        {"throughput": cmd_throughput, "fault": cmd_fault, "e2e": cmd_e2e}[args.experiment](bus, args)
    finally:
        bus.close()


if __name__ == "__main__":
    main()
