"""Rule-based intent parser used as a non-LLM baseline for the 140-command benchmark.

Keyword lists and number handling follow the intent definitions of the system prompt
(run/home/stop/status, clarify when a run has no slots, reject otherwise). The parser is
deterministic, so each command is parsed once. Its run/home outputs are then checked with
Layer 1's slot rules (JSON integers 1-9, no duplicates) against an idle line with all boxes present.

Usage: python rule_baseline.py cases.json out.csv
"""
import csv, json, re, sys, unicodedata

AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
DIACRITICS = re.compile(r"[ً-ْٰـ]")

def norm(t):
    t = DIACRITICS.sub("", t.translate(AR_DIGITS)).lower()
    for a in "أإآ":
        t = t.replace(a, "ا")
    return t.replace("ى", "ي").replace("ة", "ه").replace("ئ", "ي").replace("ؤ", "و").replace("؟", "?")

def has(t, words):
    return any(w in t for w in words)

STOP = ["stop", "halt", "abort", "cancel", "emergency", "وقف", "توقف", "ايقاف", "الغ", "طوارئ"]
HOME = ["home", "reset", "calibrate", "initiali", "prepare", "reference",
        "البدايه", "جهز", "هيي", "معاير", "ضبط", "المرجعيه"]
STATUS = ["status", "state", "ready", "doing", "busy", "running", "which boxes", "rack",
          "حاله", "جاهز", "يفعل", "مشغول", "يعمل", "موجوده"]
RUN = ["run", "process", "start", "retrieve", "execute",
       "شغل", "عالج", "معالجه", "ابدا", "اخرج"]

EN_NUM = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
          "seven": 7, "eight": 8, "nine": 9, "ten": 10}
AR_NUM = {"صفر": 0, "واحد": 1, "قطعتين": 2, "اثنين": 2, "ثلاث": 3, "اربع": 4,
          "خمس": 5, "ست": 6, "سبع": 7, "ثمان": 8, "تسع": 9, "التاسع": 9, "عشر": 10}
COUNT_EN = re.compile(r"(-?\d+|" + "|".join(EN_NUM) + r")\s+pieces?\b")
COUNT_AR = re.compile(r"(-?\d+|" + "|".join(AR_NUM) + r")\S*\s+قطع")

def num(tok):
    tok = tok.strip()
    if re.fullmatch(r"-?\d+", tok):
        return int(tok)
    return EN_NUM.get(tok, AR_NUM.get(tok))

def numbers(t):
    out = []
    for tok in re.findall(r"-?\d+|[a-z]+|[؀-ۿ]+", t):
        tok2 = re.sub(r"^(و|ال)", "", tok) if not tok.isascii() else tok
        n = num(tok) if num(tok) is not None else num(tok2)
        if n is not None:
            out.append(n)
    return out

def parse(text):
    t = norm(text)
    if has(t, STOP):
        return "stop", []
    if has(t, HOME):
        return "home", []
    if has(t, STATUS) and "?" in t or has(t, ["status", "حاله"]):
        return "status", []
    if has(t, RUN):
        if has(t, [" all ", "all boxes", "كل الصناديق"]) or t.endswith(" all"):
            return "run", list(range(1, 10))
        m = re.search(r"(-?\d+)\s*(?:to|through|-|الي)\s*(-?\d+)", t)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            return "run", list(range(a, b + 1))
        if ("قطعتين" in t or "two pieces" in t) and not re.search(r"\d", t):
            return "run", [1, 2]
        m = COUNT_EN.search(t) or COUNT_AR.search(t)
        if m:
            n = num(m.group(1))
            return "run", list(range(1, n + 1)) if n and n > 0 else [n]
        if re.search(r"\bone piece\b|قطعه واحده|the usual one", t):
            return "run", [1]
        s = numbers(t)
        return ("run", s) if s else ("clarify", [])
    return "reject", []

def layer1_passes(intent, slots):
    if intent == "home":
        return True
    return (intent == "run" and slots and len(slots) <= 9 and len(set(slots)) == len(slots)
            and all(isinstance(s, int) and 1 <= s <= 9 for s in slots))

def main(cases_path, out_path):
    cases = json.load(open(cases_path, encoding="utf-8"))
    rows = []
    for c in cases:
        intent, slots = parse(c["text"])
        exp_i, exp_s = c["expected_intent"], c["expected_slots"]
        unsafe = intent in ("run", "home") and exp_i in ("clarify", "reject")
        rows.append(dict(case_id=c["id"], category=c["category"], lang=c["lang"], text=c["text"],
                         expected_intent=exp_i, expected_slots=exp_s, pred_intent=intent, pred_slots=slots,
                         exact=int(intent == exp_i and list(slots) == list(exp_s)),
                         unsafe=int(unsafe), residual=int(unsafe and layer1_passes(intent, slots))))
    with open(out_path, "w", newline="", encoding="utf-8-sig") as f:  # BOM so Excel shows Arabic
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader(); w.writerows(rows)
    n = len(rows)
    acc = sum(r["exact"] for r in rows)
    print(f"exact {acc}/{n} = {100*acc/n:.1f}%")
    for lang in ("en", "ar"):
        sub = [r for r in rows if r["lang"] == lang]
        print(f"  {lang}: {sum(r['exact'] for r in sub)}/{len(sub)}")
    print("unsafe", sum(r["unsafe"] for r in rows), "residual", sum(r["residual"] for r in rows))
    mr = [r for r in rows if r["expected_intent"] == "reject"]
    print("must-refuse with run/home:", sum(r["unsafe"] for r in mr), "of", len(mr))
    for r in rows:
        if not r["exact"]:
            print(" X", r["case_id"], r["category"], r["text"], "->", r["pred_intent"], r["pred_slots"],
                  "UNSAFE" if r["unsafe"] else "", "RESIDUAL" if r["residual"] else "")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
