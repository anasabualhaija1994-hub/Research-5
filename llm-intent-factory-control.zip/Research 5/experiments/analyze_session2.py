#!/usr/bin/env python3
"""Session 2 (28 October 2026): heartbeat watchdog trials, end-to-end chat commands and clock offset.

    cd experiments && python analyze_session2.py session2

Watchdog: for every job failed by the watchdog, the time from the lost station's last status to the first
stop command, the spread of that stop fan-out, the HBW abort report and the Last Will (logger clock only).
End-to-end: per-model medians of e2e.csv (Table 9) and the stop fan-out/acknowledgements (Table 7).
Clock: median offset (n8n - midpoint of the request) and round trip of each clock_*.csv.
"""
import csv, json, os, statistics as st, sys

D = sys.argv[1] if len(sys.argv) > 1 else "session2"
rows = lambda p: list(csv.DictReader(open(p, encoding="utf-8")))
T = lambda r: float(r["t_unix"])


def watchdog(path):
    r = rows(path)
    for x in r:
        if x["topic"] != "factory/orchestrator/event" or "watchdog" not in x["payload"]:
            continue
        tf, station = T(x), json.loads(x["payload"])["error"].split()[0]
        stops = sorted(T(y) for y in r if y["topic"].endswith("/cmd") and '"S"' in y["payload"] and tf - 1 < T(y) <= tf)
        t0 = stops[0]
        last = max(T(y) for y in r if y["topic"] == f"factory/{station}/status" and T(y) < t0)
        lwt = [T(y) for y in r if y["topic"] == f"factory/{station}/lwt" and y["payload"] == "offline" and T(y) > t0]
        abort = [T(y) for y in r if y["topic"] == "factory/hbw/event" and "ABORTED" in y["payload"] and t0 - 0.5 < T(y) < t0 + 2]
        nxt = next((y["payload"] for y in r if T(y) > t0 + 1 and y["topic"].endswith("/cmd")), "")
        yield dict(file=path, station=station, last_status_to_stop_s=round(t0 - last, 2),
                   fanout_ms=round((stops[3] - t0) * 1000, 1), hbw_abort_s=round(abort[0] - t0, 3) if abort else "",
                   lwt_after_last_status_s=round(lwt[0] - last, 1) if lwt else "",
                   next_command=json.loads(nxt).get("cmd") + (" (reset_state)" if "reset" in nxt else "") if nxt else "none")


def chat_stop(path):
    r = rows(path)
    s = [y for y in r if y["topic"].endswith("/cmd") and '"S"' in y["payload"] and "orchestrator" not in y["topic"]]
    t0 = T(s[0])
    ids = {json.loads(y["payload"])["command_id"] for y in s[:4]}
    acks = [T(y) for y in r if y["topic"].endswith("/event") and '"stop"' in y["payload"]
            and json.loads(y["payload"]).get("command_id") in ids]
    return round((T(s[3]) - t0) * 1000, 1), round((max(acks) - t0) * 1000)


out = []
for d in ("watchdog_check", "watchdog_check2"):
    out += list(watchdog(os.path.join(D, d, "raw_mqtt.csv")))
print("Watchdog trials")
for o in out:
    print(" ", o)
v = [o["last_status_to_stop_s"] for o in out]
print(f"  last status -> stop: {min(v)}-{max(v)} s, median {st.median(v):.1f} s (n={len(v)})")

print("\nEnd-to-end (medians)")
e2e = {}
for d in ("e2e_deepseek", "e2e_claude", "e2e_claude_part2"):
    for x in rows(os.path.join(D, d, "e2e.csv")):
        e2e.setdefault(x["label"], []).append(x)
for lab, xs in e2e.items():
    by = {}
    for x in xs:
        k = x["cmd"] + (" (2 boxes)" if x["result"] == "job_failed" and x["cmd"] == "run" else "")
        by.setdefault(k, []).append(x)
    for k, ys in by.items():
        f = lambda c: st.median(float(y[c]) for y in ys)
        share = st.median(float(y["llm_validate_s"]) / float(y["total_s"]) for y in ys) * 100
        print(f"  {lab:9s} {k:15s} n={len(ys)} llm={f('llm_validate_s'):.2f} disp={f('dispatch_preflight_s'):.2f} "
              f"exec={f('exec_s'):.1f} total={f('total_s'):.2f} share={share:.1f}%")
for d in ("e2e_deepseek", "e2e_claude"):
    print(f"  chat stop {d}: fan-out spread, last acknowledgement (ms) = {chat_stop(os.path.join(D, d, 'raw_mqtt.csv'))}")

print("\nClock offset (positive = n8n ahead)")
for f in ("clock_before.csv", "clock_after.csv", "clock_after2.csv", "clock_after3.csv"):
    r = rows(os.path.join(D, f))
    print(f"  {f}: median offset {st.median(float(x['offset_ms']) for x in r):.1f} ms, "
          f"median round trip {st.median(float(x['rtt_ms']) for x in r):.1f} ms (n={len(r)})")
