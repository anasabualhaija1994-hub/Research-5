/*
 * ============================================================================
 *  ColorSorter - STANDALONE ESP32 firmware
 * ============================================================================
 *  Upload and the ColorSorter runs by itself, in the same order the Python
 *  sender used to send to the ColorSorter station. No PC, no bridge, no
 *  serial, no logging.
 *
 *  This station is different from the others: in the original firmware the
 *  Python sender only ever sent one command to it — "RUN_COLOR_CYCLE" — and
 *  the real logic (wait for piece -> read color -> sort) already lived
 *  natively in this .ino as runColorSorterCycle(). So here that function is
 *  kept exactly as-is (same thresholds, same timing, same logic), just with
 *  all the Serial/EVT/pin-logging calls removed, and it's simply called 9
 *  times in a row, same as the Python sender used to do.
 *
 *    1) No homing (the ColorSorter never had one — it starts directly by
 *       waiting for a piece, same as before)
 *    2) 9 sorting cycles, one after another
 * ============================================================================
 */
#include <Arduino.h>

// ==========================================
// Settings
// ==========================================
// Wait after power-up/reset before the first movement
const unsigned long START_DELAY_MS = 3000;

// Number of pieces / cycles to run
const int TOTAL_CYCLES = 9;

// ==========================================
// Pins
// ==========================================
#define BELT_MOTOR     13
#define COMPRESSOR     12
#define VALVE_WHITE    14
#define VALVE_RED      27
#define VALVE_BLUE     26

#define PULSE_COUNTER  36
#define SENSOR_BEFORE  39
#define SENSOR_AFTER   34
#define COLOR_SENSOR   35

// ==========================================
// Color calibration constants (unchanged)
// ==========================================
const float WHITE_MIN_V = 0.8002f;
const float RED_MIN_V   = 1.6222f;
const float BLUE_MIN_V  = 2.0000f;

const float THRESHOLD_RED_WHITE = (RED_MIN_V + WHITE_MIN_V) / 2.0f;
const float THRESHOLD_BLUE_RED  = (BLUE_MIN_V + RED_MIN_V) / 2.0f;
const float THRESHOLD_WHITE_MIN = 0.4500f;

const float VOLTAGE_FACTOR = 0.000805861f;

// ==========================================
// State used by the color cycle (unchanged)
// ==========================================
volatile unsigned int pulseCount = 0;

int   sensorValue     = 0;
float voltage         = 0.0f;
float pieceMinVoltage = 3.3f;
int   targetPulse     = 0;
int   targetValve     = -1;

void IRAM_ATTR countPulse() {
  pulseCount++;
}

// ==========================================
// Setup
// ==========================================
void setupPins() {
  pinMode(BELT_MOTOR, OUTPUT);
  pinMode(COMPRESSOR, OUTPUT);
  pinMode(VALVE_WHITE, OUTPUT);
  pinMode(VALVE_RED, OUTPUT);
  pinMode(VALVE_BLUE, OUTPUT);

  pinMode(PULSE_COUNTER, INPUT);
  pinMode(SENSOR_BEFORE, INPUT);
  pinMode(SENSOR_AFTER, INPUT);
  pinMode(COLOR_SENSOR, INPUT);

  digitalWrite(BELT_MOTOR, LOW);
  digitalWrite(COMPRESSOR, LOW);
  digitalWrite(VALVE_WHITE, LOW);
  digitalWrite(VALVE_RED, LOW);
  digitalWrite(VALVE_BLUE, LOW);

  attachInterrupt(digitalPinToInterrupt(PULSE_COUNTER), countPulse, CHANGE);
}

// ==========================================
// Native color detection cycle
// (identical logic to the original runColorSorterCycle(), minus all the
//  Serial / EVT / pin-state-logging calls)
// ==========================================
void runColorSorterCycle() {
  // Reset
  pieceMinVoltage = 3.3f;
  targetPulse = 0;
  targetValve = -1;
  voltage = 0.0f;
  sensorValue = 0;

  // 1) Wait for the piece at SENSOR_BEFORE
  while (digitalRead(SENSOR_BEFORE) == HIGH) {
    delay(10);
  }

  // 2) Run the belt and read the color while passing through
  digitalWrite(BELT_MOTOR, HIGH);

  while (digitalRead(SENSOR_AFTER) == HIGH) {
    sensorValue = analogRead(COLOR_SENSOR);
    voltage = sensorValue * VOLTAGE_FACTOR;
    if (voltage > 0.05f && voltage < pieceMinVoltage) {
      pieceMinVoltage = voltage;
    }
    delay(10);
  }

  digitalWrite(BELT_MOTOR, LOW);

  // 3) Analyze the color
  if (pieceMinVoltage > THRESHOLD_BLUE_RED) {
    targetPulse = 480; targetValve = VALVE_BLUE;
  } else if (pieceMinVoltage > THRESHOLD_RED_WHITE) {
    targetPulse = 280; targetValve = VALVE_RED;
  } else if (pieceMinVoltage > THRESHOLD_WHITE_MIN) {
    targetPulse = 110; targetValve = VALVE_WHITE;
  }

  // 4) Sort the piece
  if (targetValve != -1) {
    pulseCount = 0;
    digitalWrite(BELT_MOTOR, HIGH);
    while (pulseCount <= (unsigned int)targetPulse) {
      delay(1);
    }
    digitalWrite(BELT_MOTOR, LOW);

    digitalWrite(COMPRESSOR, HIGH);
    digitalWrite(targetValve, HIGH);
    delay(200);
    digitalWrite(targetValve, LOW);
    digitalWrite(COMPRESSOR, LOW);
  }

  // 5) Reset in preparation for the next piece
  pieceMinVoltage = 3.3f;
  targetPulse = 0;
  targetValve = -1;
  voltage = 0.0f;
  delay(500);
}

// ==========================================
// Arduino entry points
// ==========================================
bool sequenceDone = false;

void setup() {
  setupPins();
}

void loop() {
  if (!sequenceDone) {
    delay(START_DELAY_MS);   // safety delay before the first movement
    for (int i = 0; i < TOTAL_CYCLES; i++) {
      runColorSorterCycle();
    }
    sequenceDone = true;
  }
}
