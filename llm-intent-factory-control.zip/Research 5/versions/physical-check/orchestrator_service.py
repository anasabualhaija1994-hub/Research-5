#!/usr/bin/env python3
"""
============================================================================
 Factory Orchestrator SERVICE (v3) - long-running, job-driven
============================================================================
Same pipelined, event-driven flow as orchestrator.py v2
(HBW -> Grabber -> Oven -> ColorSorter, several pieces in flight), but it
stays running and takes JOBS over MQTT. This is the interface the n8n /
LLM layer will call: the AI only has to produce one of the JSON requests
below.

REQUESTS  ->  factory/orchestrator/cmd
  {"cmd":"run",    "slots":[1,2,3], "job_id":"any-id"}   process these slots
  {"cmd":"home",   "job_id":"any-id"}                    home HBW, Grabber, Oven
  {"cmd":"stop",   "job_id":"any-id"}                    abort job + STOP all
  {"cmd":"status", "job_id":"any-id"}                    publish status now
  (job_id is optional; it is echoed back in every reply)

REPLIES / PROGRESS  <-  factory/orchestrator/event   (not retained)
  job_accepted, job_rejected{reason,problems}, piece_stage{slot,stage},
  piece_done{slot,color,voltage,cycle_s}, job_done{total_s,per_piece_s,pieces},
  job_failed{error}, home_done, home_failed{error}, stopped

STATE  <-  factory/orchestrator/status  (retained, on change + every 10 s)
  {"state":"idle|preflight|running|homing", "job_id", "slots", "done_slots",
   "stations":{...online/busy/homed/boxes/hold...}}
LIVENESS  <-  factory/orchestrator/lwt  "online"/"offline" (retained)

LOGS (for the paper)  ./logs/jobs.csv, pieces.csv, commands.csv

Run:  python orchestrator_service.py      (Ctrl+C to quit)
Test: python factory_cli.py run 1 2 3
============================================================================
"""
import csv
import json
import os
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import paho.mqtt.client as mqtt

# ==========================================
# Config
# ==========================================
BROKER_HOST = "192.168.0.249"
BROKER_PORT = 1883

REHOME_ROTATE_EVERY = 3         # Grabber uses R (rotate re-home) on every Nth piece of a job
SAME_STATION_SETTLE_S = 0.3
EARLY_DROP = True               # Grabber drops next piece once the oven tray is free
TRAY_FREE_PHASE = "cutting"
PREFLIGHT_WAIT_S = 8            # stations heartbeat every 5 s; wait for a FRESH one
MOVE_TIMEOUT_S = 180
WAIT_TIMEOUT_S = 900
HOME_TIMEOUT_S = 120
STATUS_EVERY_S = 10
LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")

HTTP_PORT = 8090                # REST API for n8n (0 = disabled)

STATIONS = ("hbw", "grabber", "oven", "colorsorter")
T_ORC = "factory/orchestrator"

# ==========================================
# Shared state
# ==========================================
lwt, status, status_live = {}, {}, {}
status_at = {}                                  # station -> time the last LIVE status arrived
pending = {}                                    # command_id -> Cmd
last_done = {s: 0.0 for s in STATIONS}
state = {"state": "idle", "job_id": None, "slots": [], "done_slots": [], "last_result": None}
state_lock = threading.Lock()
current = {"job": None}                          # the running Job (or None)
connected = threading.Event()
_counter = [0]
_counter_lock = threading.Lock()
_csv_lock = threading.Lock()
T_START = time.time()


def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def now_iso():
    return datetime.now().isoformat(timespec="milliseconds")


def csv_append(name, header, row):
    os.makedirs(LOG_DIR, exist_ok=True)
    path = os.path.join(LOG_DIR, name)
    with _csv_lock:
        new = not os.path.exists(path)
        with open(path, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if new:
                w.writerow(header)
            w.writerow(row)


class Aborted(Exception):
    pass


class Cmd:
    def __init__(self, job, station, letter, cid, extra):
        self.job, self.station, self.letter, self.cid, self.extra = job, station, letter, cid, extra
        self.started, self.finished = threading.Event(), threading.Event()
        self.error = None
        self.code = ""
        self.sent_at = time.time()


class Job:
    def __init__(self, job_id, slots, kind="run"):
        self.job_id, self.slots, self.kind = job_id, slots, kind
        self.abort = threading.Event()
        self.lock = threading.Lock()            # orders "abort + STOP" against new station commands
        self.errors = []
        self.t0 = time.time()
        self.oven_current = -1
        self.early_drop = EARLY_DROP
        self.sorter_current = -1
        self.pieces = [{
            "slot": s, "idx": i,
            "r_ready": threading.Event(), "p_done": threading.Event(),
            "oven_armed": threading.Event(), "tray_free": threading.Event(),
            "t_start": None, "t_sorted": None, "color": None, "voltage": None,
        } for i, s in enumerate(slots)]
        if self.pieces:
            self.pieces[0]["tray_free"].set()
        self.by_slot = {p["slot"]: p for p in self.pieces}

    def fail(self, msg):
        with self.lock:
            if self.abort.is_set():
                return
            self.errors.append(msg)
            self.abort.set()
            stop_all()                          # STOP immediately - do not wait for the workers to unwind
        log(f"!!! [{self.job_id}] {msg} -> STOP sent to all stations")

    def rel(self):
        return time.time() - self.t0


# ==========================================
# MQTT plumbing
# ==========================================
try:
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="factory-orchestrator-svc")
except AttributeError:
    client = mqtt.Client(client_id="factory-orchestrator-svc")
client.will_set(f"{T_ORC}/lwt", "offline", qos=1, retain=True)


jobs = {}                                       # job_id -> {"events": [...], "final": {...}}
jobs_lock = threading.Lock()
FINAL_EVENTS = {"job_done", "job_failed", "job_rejected", "home_done", "home_failed", "stopped", "status_sent"}


def publish_event(event, **fields):
    payload = {"event": event, "ts": now_iso()}
    payload.update(fields)
    jid = payload.get("job_id")
    if jid:
        with jobs_lock:
            rec = jobs.setdefault(jid, {"job_id": jid, "events": [], "final": None})
            rec["events"].append(payload)
            if event in FINAL_EVENTS:
                rec["final"] = payload
            while len(jobs) > 200:
                jobs.pop(next(iter(jobs)))
    client.publish(f"{T_ORC}/event", json.dumps(payload), qos=1)


def station_summary():
    out = {}
    for st in STATIONS:
        s = status_live.get(st) or status.get(st) or {}
        d = {"online": lwt.get(st) == "online", "busy": bool(s.get("busy"))}
        if st != "colorsorter":
            d["homed"] = s.get("homed") is True
        if st == "hbw":
            d["boxes"] = s.get("boxes")
        if st == "grabber":
            d["hold"] = s.get("hold")
        out[st] = d
    return out


def status_payload():
    with state_lock:
        payload = dict(state)
    payload["stations"] = station_summary()
    payload["ts"] = now_iso()
    return payload


def publish_status():
    payload = status_payload()
    client.publish(f"{T_ORC}/status", json.dumps(payload), qos=1, retain=True)


def set_state(**kw):
    with state_lock:
        state.update(kw)
    publish_status()


def on_connect(c, userdata, flags, rc, props=None):
    c.subscribe([(f"factory/{st}/{k}", 1) for st in STATIONS for k in ("event", "status", "lwt")])
    c.subscribe(f"{T_ORC}/cmd", 1)
    c.publish(f"{T_ORC}/lwt", "online", qos=1, retain=True)
    connected.set()
    log("connected to broker")


def on_message(c, userdata, msg):
    if msg.topic == f"{T_ORC}/cmd":
        threading.Thread(target=handle_request, args=(msg.payload,), daemon=True).start()
        return
    parts = msg.topic.split("/")
    if len(parts) != 3 or parts[0] != "factory" or parts[1] not in STATIONS:
        return
    st, kind = parts[1], parts[2]
    raw = msg.payload.decode("utf-8", "replace").strip()
    job = current["job"]

    if kind == "lwt":
        lwt[st] = raw
        if raw != "online" and job:              # run, home, or a job still in preflight
            job.fail(f"{st} went offline")
        return
    try:
        ev = json.loads(raw)
    except ValueError:
        return
    if kind == "status":
        status[st] = ev
        if not msg.retain:
            status_live[st] = ev
            status_at[st] = time.time()
        return
    if kind != "event":
        return
    etype = ev.get("event")

    if job and job.kind == "run":
        if st == "hbw" and etype == "progress" and ev.get("state") == "box_outside":
            p = job.by_slot.get(ev.get("slot"))
            if p:
                p["r_ready"].set()
        if st == "oven" and etype == "phase" and ev.get("phase") == TRAY_FREE_PHASE:
            nxt = job.oven_current + 1
            if 0 < nxt < len(job.pieces) and not job.pieces[nxt]["tray_free"].is_set():
                job.pieces[nxt]["tray_free"].set()
                log(f"oven        tray free -> piece {job.pieces[nxt]['slot']} may be dropped")
        if st == "colorsorter" and etype == "color" and 0 <= job.sorter_current < len(job.pieces):
            p = job.pieces[job.sorter_current]
            p["color"], p["voltage"] = ev.get("color"), ev.get("voltage")
            log(f"colorsorter piece {p['slot']} color={p['color']} v={p['voltage']}")

    cmd = pending.get(ev.get("command_id"))
    if cmd is None:
        return
    if etype == "started":
        cmd.started.set()
    elif etype == "done":
        last_done[st] = time.time()
        log(f"{st:11s} {cmd.letter} done  ({time.time() - cmd.sent_at:.1f}s)")
        log_cmd(cmd, "done")
        cmd.started.set()
        cmd.finished.set()
    elif etype in ("fault", "rejected"):
        cmd.code = str(ev.get("code"))
        cmd.error = (f"{st} {cmd.letter} {etype.upper()}: {ev.get('code')} "
                     f"step={ev.get('step', '-')} phase={ev.get('phase', '-')}")
        log_cmd(cmd, etype)
        cmd.started.set()
        cmd.finished.set()
        cmd.job.fail(cmd.error)


def log_cmd(cmd, result):
    csv_append("commands.csv",
               ["ts", "job_id", "station", "cmd", "slot", "command_id", "sent_rel_s", "duration_s", "result", "code"],
               [now_iso(), cmd.job.job_id, cmd.station, cmd.letter, cmd.extra.get("slot", ""), cmd.cid,
                f"{cmd.sent_at - cmd.job.t0:.2f}", f"{time.time() - cmd.sent_at:.2f}", result, cmd.code])


client.on_connect = on_connect
client.on_message = on_message


def send(job, station, letter, **extra):
    if job.abort.is_set():
        raise Aborted()
    with _counter_lock:
        _counter[0] += 1
        cid = f"svc-{station[:2]}-{_counter[0]}-{int(time.time())}"
    cmd = Cmd(job, station, letter, cid, extra)
    pending[cid] = cmd
    gap = last_done[station] + SAME_STATION_SETTLE_S - time.time()
    if gap > 0:
        time.sleep(gap)
    payload = {"cmd": letter, "command_id": cid}
    payload.update(extra)
    with job.lock:                              # never send a motion command after the job was aborted
        if job.abort.is_set():
            pending.pop(cid, None)
            raise Aborted()
        cmd.sent_at = time.time()
        client.publish(f"factory/{station}/cmd", json.dumps(payload), qos=1)
    log(f"{station:11s} {letter} sent  {extra if extra else ''}")
    return cmd


def stop_all():
    for st in STATIONS:
        client.publish(f"factory/{st}/cmd",
                       json.dumps({"cmd": "S", "command_id": f"svc-stop-{st[:2]}-{int(time.time() * 1000)}"}), qos=1)


def _wait(job, ev, what, timeout):
    end = time.time() + timeout
    while True:
        if job.abort.is_set():
            raise Aborted()
        if ev.wait(0.2):
            return
        if time.time() > end:
            raise TimeoutError(f"timed out waiting for {what}")


def wait_started(job, cmd):
    _wait(job, cmd.started, f"{cmd.station}:{cmd.letter} to start", 15)
    if cmd.error:
        raise RuntimeError(cmd.error)


def wait_done(job, cmd, timeout=MOVE_TIMEOUT_S):
    _wait(job, cmd.finished, f"{cmd.station}:{cmd.letter} to finish", timeout)
    if cmd.error:
        raise RuntimeError(cmd.error)


def stage(job, p, name):
    publish_event("piece_stage", job_id=job.job_id, slot=p["slot"], stage=name, t_rel_s=round(job.rel(), 1))


# ==========================================
# Station workers (one job)
# ==========================================
def hbw_worker(job):
    for p in job.pieces:
        p["t_start"] = job.rel()
        wait_done(job, send(job, "hbw", "R", slot=p["slot"]))
        p["r_ready"].set()
        stage(job, p, "retrieved")
        _wait(job, p["p_done"], f"Grabber to pick piece {p['slot']}", WAIT_TIMEOUT_S)
        wait_done(job, send(job, "hbw", "T", slot=p["slot"]))


def grabber_worker(job):
    for i, p in enumerate(job.pieces):
        _wait(job, p["r_ready"], f"box {p['slot']} at HBW outer barrier", WAIT_TIMEOUT_S)
        wait_done(job, send(job, "grabber", "P"))
        p["p_done"].set()
        stage(job, p, "picked")
        if job.early_drop:
            _wait(job, p["tray_free"], f"oven tray free for piece {p['slot']}", WAIT_TIMEOUT_S)
        else:
            _wait(job, p["oven_armed"], f"oven armed for piece {p['slot']}", WAIT_TIMEOUT_S)
        wait_done(job, send(job, "grabber", "R" if (i + 1) % REHOME_ROTATE_EVERY == 0 else "O"))
        stage(job, p, "placed_in_oven")


def oven_worker(job):
    for i, p in enumerate(job.pieces):
        _wait(job, p["p_done"], f"piece {p['slot']} picked", WAIT_TIMEOUT_S)
        job.oven_current = i
        c = send(job, "oven", "C")
        wait_started(job, c)
        p["oven_armed"].set()
        wait_done(job, c, WAIT_TIMEOUT_S)
        stage(job, p, "oven_done")


def sorter_worker(job):
    for i, p in enumerate(job.pieces):
        _wait(job, p["oven_armed"], f"oven armed for piece {p['slot']}", WAIT_TIMEOUT_S)
        job.sorter_current = i
        wait_done(job, send(job, "colorsorter", "C"), WAIT_TIMEOUT_S)
        p["t_sorted"] = job.rel()
        cycle = p["t_sorted"] - (p["t_start"] or 0)
        with state_lock:
            state["done_slots"] = state["done_slots"] + [p["slot"]]
        publish_status()
        publish_event("piece_done", job_id=job.job_id, slot=p["slot"], color=p["color"],
                      voltage=p["voltage"], cycle_s=round(cycle, 1), t_rel_s=round(p["t_sorted"], 1))
        csv_append("pieces.csv", ["ts", "job_id", "slot", "color", "voltage", "t_start_rel_s", "t_sorted_rel_s", "cycle_s"],
                   [now_iso(), job.job_id, p["slot"], p["color"], p["voltage"],
                    f"{p['t_start'] or 0:.1f}", f"{p['t_sorted']:.1f}", f"{cycle:.1f}"])
        log(f"=== piece from slot {p['slot']} COMPLETE ({p['color']}) ===")


def run_worker(job, fn):
    try:
        fn(job)
    except Aborted:
        pass
    except Exception as e:
        job.fail(f"{fn.__name__}: {e}")


# ==========================================
# Preflight
# ==========================================
def preflight(slots, need_boxes=True, job=None):
    # Only trust a status that arrived AFTER this request (and after the
    # station's last command finished) - avoids stale "busy/not homed".
    t_req = time.time()
    end = t_req + PREFLIGHT_WAIT_S
    fresh = lambda st: status_at.get(st, 0) > max(t_req, last_done[st])
    while time.time() < end and not all(fresh(st) for st in STATIONS):
        if job is not None and job.abort.is_set():
            return [job.errors[0] if job.errors else "aborted"]
        time.sleep(0.2)
    if job is not None and job.abort.is_set():
        return [job.errors[0] if job.errors else "aborted"]
    problems = []
    for st in STATIONS:
        if lwt.get(st) != "online":
            problems.append(f"{st}: not online")
        s = status_live.get(st) or status.get(st)
        if s is None:
            problems.append(f"{st}: no status received")
            continue
        if not fresh(st) and lwt.get(st) == "online":
            problems.append(f"{st}: no fresh status in {PREFLIGHT_WAIT_S}s")
        if s.get("busy"):
            problems.append(f"{st}: busy")
        if need_boxes and st in ("hbw", "grabber", "oven") and s.get("homed") is not True:
            problems.append(f"{st}: not homed (send home first)")
    if need_boxes:
        boxes = (status_live.get("hbw") or status.get("hbw") or {}).get("boxes", "")
        for slot in slots:
            if len(boxes) < slot or boxes[slot - 1] != "R":
                problems.append(f"hbw: box {slot} is not in the rack (boxes={boxes!r})")
        if boxes and any(ch != "R" for ch in boxes):
            problems.append(f"hbw: not every box is in the rack (boxes={boxes!r})")
        g = status_live.get("grabber") or status.get("grabber") or {}
        if g.get("hold") != "empty":               # a missing field is not "empty"
            problems.append(f"grabber: hold is {g.get('hold')!r}, expected 'empty'")
    return problems


# ==========================================
# Request handling
# ==========================================
def handle_request(raw):
    try:
        req = json.loads(raw.decode("utf-8", "replace"))
        if not isinstance(req, dict):
            raise ValueError
    except ValueError:
        publish_event("job_rejected", job_id=None, reason="bad_json")
        return
    cmd = str(req.get("cmd", "")).lower()
    job_id = str(req.get("job_id") or f"job-{int(time.time())}")
    log(f">>> request {cmd} job_id={job_id} {req}")

    if cmd == "status":
        publish_status()
        publish_event("status_sent", job_id=job_id, status=status_payload())
        return
    if cmd == "stop":
        job = current["job"]
        if job:
            job.fail("stop requested")
        stop_all()
        publish_event("stopped", job_id=job_id, aborted_job=job.job_id if job else None)
        return
    if cmd not in ("run", "home"):
        publish_event("job_rejected", job_id=job_id, reason=f"unknown cmd {cmd!r}")
        return
    slots = req.get("slots")
    if cmd == "run" and (not isinstance(slots, list) or not slots
                         or not all(type(s) is int and 1 <= s <= 9 for s in slots)   # bool is NOT a slot
                         or len(set(slots)) != len(slots)):
        publish_event("job_rejected", job_id=job_id, reason="bad_slots",
                      problems=["slots must be a non-empty list of unique integers 1..9"])
        return

    with state_lock:
        if state["state"] != "idle":
            busy = dict(state)
        else:
            busy = None
            state.update(state="preflight", job_id=job_id, slots=[], done_slots=[])
    if busy:
        publish_event("job_rejected", job_id=job_id, reason="busy",
                      problems=[f"orchestrator is {busy['state']} (job {busy['job_id']})"])
        return
    # experiment knob (MQTT/HTTP clients only - the n8n validator never forwards it)
    early_drop = req.get("early_drop") if isinstance(req.get("early_drop"), bool) else EARLY_DROP
    # The job exists from the start of the preflight: a STOP (or a station going offline) during the
    # preflight aborts it, and it is never accepted afterwards.
    job = Job(job_id, slots if cmd == "run" else [], kind=cmd)
    job.early_drop = early_drop
    current["job"] = job
    try:
        if cmd == "home":
            do_home(job)
        else:
            do_run(job)
    finally:
        current["job"] = None
        set_state(state="idle")


def accept_or_abort(job, **state_kw):
    """Accept the job unless it was aborted during the preflight (checked under the job lock, the same
    lock that orders STOP against station commands). Returns False if the job must not start."""
    with job.lock:
        if job.abort.is_set():
            return False
        job.t0 = time.time()
        set_state(**state_kw)
        publish_event("job_accepted", job_id=job.job_id, cmd=job.kind,
                      **({"slots": job.slots, "early_drop": job.early_drop} if job.kind == "run" else {}))
        return True


def do_home(job):
    job_id = job.job_id
    problems = preflight([], need_boxes=False, job=job)
    if problems or not accept_or_abort(job, state="homing"):
        err = "; ".join(problems) if problems else (job.errors[0] if job.errors else "aborted")
        publish_event("home_failed", job_id=job_id, error=err)
        return
    cmds = [send(job, st, "H") for st in ("hbw", "grabber", "oven")]
    try:
        for c in cmds:
            wait_done(job, c, HOME_TIMEOUT_S)
    except (Aborted, RuntimeError, TimeoutError) as e:
        job.fail(str(e))
    if job.errors:
        stop_all()
        log(f"home {job_id}: FAILED - {job.errors[0]}")
        with state_lock:
            state["last_result"] = {"job_id": job_id, "result": "failed", "error": job.errors[0]}
        publish_event("home_failed", job_id=job_id, error=job.errors[0])
    else:
        publish_event("home_done", job_id=job_id, total_s=round(job.rel(), 1))


def do_run(job):
    job_id, slots = job.job_id, job.slots
    problems = preflight(slots, job=job)
    if problems or not accept_or_abort(job, state="running", slots=slots, done_slots=[]):
        problems = problems or [job.errors[0] if job.errors else "aborted"]
        log("preflight FAIL: " + "; ".join(problems))
        publish_event("job_rejected", job_id=job_id, reason="stopped" if job.abort.is_set() else "preflight",
                      problems=problems)
        return
    log(f"job {job_id}: starting {len(slots)} piece(s), slots {slots}")

    workers = [threading.Thread(target=run_worker, args=(job, fn), daemon=True)
               for fn in (hbw_worker, grabber_worker, oven_worker, sorter_worker)]
    for w in workers:
        w.start()
    for w in workers:
        w.join()

    total = job.rel()
    done = [p for p in job.pieces if p["t_sorted"] is not None]
    pieces = [{"slot": p["slot"], "color": p["color"], "voltage": p["voltage"],
               "t_sorted_s": round(p["t_sorted"], 1) if p["t_sorted"] is not None else None} for p in job.pieces]
    result = "failed" if job.errors else "done"
    with state_lock:
        state["last_result"] = {"job_id": job_id, "result": result, "pieces_done": len(done), "pieces_total": len(slots),
                                "total_s": round(total, 1), "error": job.errors[0] if job.errors else None,
                                "colors": {str(p["slot"]): p["color"] for p in job.pieces if p["color"]}}
    if job.errors:
        log(f"job {job_id}: FAILED after {total:.0f}s ({len(done)}/{len(slots)} pieces) - {job.errors[0]}")
        log("sending STOP to all stations")
    csv_append("jobs.csv", ["ts", "job_id", "slots", "result", "pieces_done", "total_s", "per_piece_s", "error"],
               [now_iso(), job_id, " ".join(map(str, slots)), result, len(done), f"{total:.1f}",
                f"{total / max(len(done), 1):.1f}", job.errors[0] if job.errors else ""])
    if job.errors:
        stop_all()
        publish_event("job_failed", job_id=job_id, error=job.errors[0], pieces=pieces,
                      hint="check physical state, home, re-declare boxes (L) if needed")
    else:
        publish_event("job_done", job_id=job_id, total_s=round(total, 1),
                      per_piece_s=round(total / len(slots), 1), pieces=pieces)
        log(f"job {job_id}: all {len(slots)} piece(s) done in {total:.0f}s")


# ==========================================
# HTTP API (for n8n)
#   GET  /status          -> orchestrator + station state
#   POST /cmd  {json}     -> same request as MQTT; waits for the first answer
#                            (job_accepted / job_rejected / home_* / stopped)
#   GET  /job/<job_id>    -> all events of that job + final result
# ==========================================
FIRST_ANSWER = {"job_accepted", "job_rejected", "home_failed", "home_done", "stopped", "status_sent"}


class Api(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path.rstrip("/") == "/status":
            return self._send(200, status_payload())
        if self.path.startswith("/job/"):
            jid = self.path[5:]
            with jobs_lock:
                rec = jobs.get(jid)
                rec = json.loads(json.dumps(rec)) if rec else None
            return self._send(200 if rec else 404, rec or {"error": "unknown job_id"})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if self.path.rstrip("/") != "/cmd":
            return self._send(404, {"error": "not found"})
        try:
            n = int(self.headers.get("Content-Length", 0))
            req = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
            if not isinstance(req, dict):
                raise ValueError
        except ValueError:
            return self._send(400, {"event": "job_rejected", "reason": "bad_json"})
        req.setdefault("job_id", f"http-{req.get('cmd', 'x')}-{int(time.time() * 1000)}")
        jid = str(req["job_id"])
        threading.Thread(target=handle_request, args=(json.dumps(req).encode(),), daemon=True).start()
        # "wait": true -> answer only when the job is FINISHED (used for home, ~15 s);
        # otherwise answer as soon as it is accepted/rejected.
        wait_final = bool(req.get("wait"))
        want = FINAL_EVENTS if wait_final else FIRST_ANSWER
        end = time.time() + PREFLIGHT_WAIT_S + 7 + (HOME_TIMEOUT_S if wait_final else 0)
        while time.time() < end:
            with jobs_lock:
                rec = jobs.get(jid)
                ans = next((e for e in rec["events"] if e["event"] in want), None) if rec else None
            if ans:
                return self._send(200, ans)
            time.sleep(0.1)
        self._send(504, {"event": "no_answer", "job_id": jid})


def start_http():
    if not HTTP_PORT:
        return
    srv = ThreadingHTTPServer(("0.0.0.0", HTTP_PORT), Api)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log(f"HTTP API on http://0.0.0.0:{HTTP_PORT}  (GET /status, POST /cmd, GET /job/<id>)")


# ==========================================
# Main
# ==========================================
def main():
    client.connect(BROKER_HOST, BROKER_PORT, keepalive=30)
    client.loop_start()
    if not connected.wait(10):
        print("could not connect to the MQTT broker")
        return
    time.sleep(0.5)
    publish_status()
    start_http()
    log(f"orchestrator service ready - send requests to {T_ORC}/cmd")
    try:
        while True:
            time.sleep(STATUS_EVERY_S)
            publish_status()
    except KeyboardInterrupt:
        log("shutting down")
        job = current["job"]
        if job:
            job.fail("service stopped (Ctrl+C)")
            stop_all()
        client.publish(f"{T_ORC}/lwt", "offline", qos=1, retain=True)
        time.sleep(0.5)
        client.loop_stop()


if __name__ == "__main__":
    main()
