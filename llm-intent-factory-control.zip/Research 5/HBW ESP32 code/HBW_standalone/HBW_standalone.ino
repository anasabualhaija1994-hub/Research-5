/*
 * ============================================================================
 *  HBW (High-Bay Warehouse) - STANDALONE ESP32 firmware
 * ============================================================================
 *  Upload and the HBW runs by itself, in the same order the Python sender
 *  used to send to the HBW station. No PC, no bridge, no serial, no logging.
 *
 *    1) Initial Homing
 *    2) Positions in this order: 1, 4, 7, 2, 5, 8, 3, 6, 9
 *         a) RETRIEVE  (rack -> conveyor outside)
 *         b) wait for the Grabber to PICK the piece
 *         c) RETURN    (empty box back to the rack)
 *    3) Final Homing
 * ============================================================================
 */
#include <Arduino.h>

// ==========================================
// Settings
// ==========================================
// Wait after power-up/reset before the first movement
const unsigned long START_DELAY_MS = 3000;

// Python: time.sleep(1) after the Initial Homing
const unsigned long HOMING_SETTLE_MS = 1000;

// The HBW cannot "see" that the Grabber took the piece, so after each RETRIEVE it waits
// a fixed time (= duration of "Grabber PICK_FROM_HBW" in the Python version).
// >>> Set it a bit ABOVE the "Cycle N PICK" Total_ms values in timing_log.csv <<<
const unsigned long GRABBER_PICK_WAIT_MS = 2000;

// Python: time.sleep(1) right after the Grabber PICK, before HBW RETURN
const unsigned long AFTER_PICK_DELAY_MS = 1000;

// ==========================================
// Pins
// ==========================================
#define REF_SWITCH_HORIZONTAL    36
#define LIGHT_BARRIER_INSIDE     39
#define LIGHT_BARRIER_OUTSIDE    34
#define REF_SWITCH_VERTICAL      35

#define ENCODER_HORZ_IMP1        32
#define ENCODER_HORZ_IMP2        33
#define ENCODER_VERT_IMP1        25
#define ENCODER_VERT_IMP2        26

#define REF_SWITCH_CANTILEVER_FRONT 27
#define REF_SWITCH_CANTILEVER_BACK  14

#define MOTOR_CONVEYOR_FWD     23
#define MOTOR_CONVEYOR_BWD     22
#define MOTOR_HORZ_TO_RACK     21
#define MOTOR_HORZ_TO_CONVEYOR 19
#define MOTOR_VERT_DOWN        18
#define MOTOR_VERT_UP          4
#define MOTOR_CANTILEVER_FWD   17
#define MOTOR_CANTILEVER_BWD   16

volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;

const int8_t encoder_table[16] = {
  0, -1,  1, 0,
  1,  0,  0, -1,
 -1,  0,  0,  1,
  0,  1, -1, 0
};

// ==========================================
// Encoder interrupts (unchanged)
// ==========================================
void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t cur = (digitalRead(ENCODER_VERT_IMP1) << 1) | digitalRead(ENCODER_VERT_IMP2);
  verticalPulseCount += encoder_table[(lastState << 2) | cur];
  lastState = cur;
}

void IRAM_ATTR handleHorizontalEncoder() {
  if (horizontalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t cur = (digitalRead(ENCODER_HORZ_IMP1) << 1) | digitalRead(ENCODER_HORZ_IMP2);
  if (cur != lastState) {
    horizontalPulseCount -= encoder_table[(lastState << 2) | cur];
    lastState = cur;
  }
}

// ==========================================
// Basic movements (each = one command group from the Python blocks)
// ==========================================
#define WAIT_WHILE(cond) while (cond) { delay(1); }

// --- Cantilever ---
void cantileverFront() {
  digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
  WAIT_WHILE(digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW);
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); delay(10);
}

void cantileverBack() {
  digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  WAIT_WHILE(digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW);
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW); delay(10);
}

// --- Vertical axis ---
void vertDownTo(int target) {
  digitalWrite(MOTOR_VERT_DOWN, HIGH); verticalMoveDirection = 1;
  WAIT_WHILE(verticalPulseCount < target);
  digitalWrite(MOTOR_VERT_DOWN, LOW); verticalMoveDirection = 0; delay(10);
}

void vertUpTo(int target) {
  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  WAIT_WHILE(verticalPulseCount > target);
  digitalWrite(MOTOR_VERT_UP, LOW); verticalMoveDirection = 0; delay(10);
}

void vertHome() {
  digitalWrite(MOTOR_VERT_UP, HIGH); verticalMoveDirection = -1;
  WAIT_WHILE(digitalRead(REF_SWITCH_VERTICAL) == LOW);
  digitalWrite(MOTOR_VERT_UP, LOW); verticalPulseCount = 0; verticalMoveDirection = 0; delay(10);
}

// --- Horizontal axis ---
void horzToRackTo(int target) {
  digitalWrite(MOTOR_HORZ_TO_RACK, HIGH); horizontalMoveDirection = 1;
  WAIT_WHILE(horizontalPulseCount < target);
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); horizontalMoveDirection = 0; delay(10);
}

void horzToConveyorTo(int target) {
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  WAIT_WHILE(horizontalPulseCount > target);
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalMoveDirection = 0; delay(10);
}

void horzHome() {
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH); horizontalMoveDirection = -1;
  WAIT_WHILE(digitalRead(REF_SWITCH_HORIZONTAL) == LOW);
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW); horizontalPulseCount = 0; horizontalMoveDirection = 0; delay(10);
}

// --- Conveyor ---
// Wait for the box inside, push it out until the outside light barrier
void conveyorToOutside() {
  WAIT_WHILE(digitalRead(LIGHT_BARRIER_INSIDE) != LOW);
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  WAIT_WHILE(digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW);
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
}

// Pull the box back until the inside light barrier
void conveyorToInside() {
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  WAIT_WHILE(digitalRead(LIGHT_BARRIER_INSIDE) != LOW);
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW); delay(10);
}

// ==========================================
// Homing (Python: FINAL_HOMING, also used as Initial Homing for HBW)
// ==========================================
void homing() {
  cantileverBack();
  vertHome();
  horzHome();
}

// ==========================================
// The 9 positions (translated 1:1 from the Python blocks)
// ==========================================
// ---------- POS 1 (H=2900, V_Ret=500, V_Store=0 (home)) ----------
void pos1Retrieve() {
  horzToRackTo(2900);
  vertDownTo(500);
  cantileverFront();
  vertHome();
  cantileverBack();
  horzToConveyorTo(60);
  vertDownTo(2800);
  cantileverFront();
  conveyorToOutside();
}

void pos1Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(2900);
  cantileverFront();
  vertDownTo(500);
  cantileverBack();
}

// ---------- POS 4 (H=5250, V_Ret=500, V_Store=0 (home)) ----------
void pos4Retrieve() {
  horzToRackTo(5250);
  vertUpTo(500);
  cantileverFront();
  vertHome();
  cantileverBack();
  horzToConveyorTo(60);
  vertDownTo(2800);
  cantileverFront();
  conveyorToOutside();
}

void pos4Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(5250);
  cantileverFront();
  vertDownTo(500);
  cantileverBack();
}

// ---------- POS 7 (H=7570, V_Ret=500, V_Store=0 (home)) ----------
void pos7Retrieve() {
  horzToRackTo(7570);
  vertUpTo(500);
  cantileverFront();
  vertHome();
  cantileverBack();
  horzToConveyorTo(60);
  vertDownTo(2800);
  cantileverFront();
  conveyorToOutside();
}

void pos7Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(7570);
  cantileverFront();
  vertDownTo(500);
  cantileverBack();
}

// ---------- POS 2 (H=2900, V_Ret=1850, V_Store=1500) ----------
void pos2Retrieve() {
  horzToConveyorTo(2900);
  vertDownTo(1850);
  cantileverFront();
  vertUpTo(1500);
  cantileverBack();
  horzToConveyorTo(60);
  vertDownTo(2800);
  cantileverFront();
  conveyorToOutside();
}

void pos2Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(2900);
  vertDownTo(1500);
  cantileverFront();
  vertDownTo(1850);
  cantileverBack();
}

// ---------- POS 5 (H=5250, V_Ret=1850, V_Store=1500) ----------
void pos5Retrieve() {
  horzToRackTo(5250);
  vertDownTo(1850);
  cantileverFront();
  vertUpTo(1500);
  cantileverBack();
  horzToConveyorTo(60);
  vertDownTo(2800);
  cantileverFront();
  conveyorToOutside(); delay(1000);
}

void pos5Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(5250);
  vertDownTo(1500);
  cantileverFront();
  vertDownTo(1850);
  cantileverBack();
}

// ---------- POS 8 (H=7570, V_Ret=1850, V_Store=1500) ----------
void pos8Retrieve() {
  horzToRackTo(7570);
  vertDownTo(1850);
  cantileverFront();
  vertUpTo(1500);
  cantileverBack();
  horzToConveyorTo(60);
  vertDownTo(2800);
  cantileverFront();
  conveyorToOutside();
}

void pos8Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(7570);
  vertDownTo(1500);
  cantileverFront();
  vertDownTo(1850);
  cantileverBack();
}

// ---------- POS 3 (H=2900, V_Ret=3450, V_Store=3000) ----------
void pos3Retrieve() {
  horzToConveyorTo(2900);
  vertDownTo(3450);
  cantileverFront();
  vertUpTo(3000);
  cantileverBack();
  horzToConveyorTo(60);
  vertDownTo(2800);
  if (verticalPulseCount > 2800) vertUpTo(2800);
  cantileverFront();
  conveyorToOutside();
}

void pos3Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(2900);
  vertDownTo(3000);
  cantileverFront();
  vertDownTo(3450);
  cantileverBack();
}

// ---------- POS 6 (H=5250, V_Ret=3450, V_Store=3000) ----------
void pos6Retrieve() {
  horzToRackTo(5250);
  vertDownTo(3450);
  cantileverFront();
  vertUpTo(3000);
  cantileverBack();
  horzToConveyorTo(60);
  if (verticalPulseCount > 2800) vertUpTo(2800);
  cantileverFront();
  conveyorToOutside();
}

void pos6Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(5250);
  vertDownTo(3000);
  cantileverFront();
  vertDownTo(3450);
  cantileverBack();
}

// ---------- POS 9 (H=7570, V_Ret=3450, V_Store=3000) ----------
void pos9Retrieve() {
  horzToRackTo(7570);
  vertDownTo(3450);
  cantileverFront();
  vertUpTo(3000);
  cantileverBack();
  horzToConveyorTo(60);
  if (verticalPulseCount > 2800) vertUpTo(2800);
  cantileverFront();
  conveyorToOutside();
}

void pos9Return() {
  conveyorToInside();
  cantileverFront();
  vertUpTo(2400);
  cantileverBack();
  vertHome();
  horzHome();
  horzToRackTo(7570);
  vertDownTo(3000);
  cantileverFront();
  vertDownTo(3450);
  cantileverBack();
}

// ==========================================
// Sequence (same order as the Python main)
// ==========================================
struct PosStep {
  void (*retrievePiece)();
  void (*returnBox)();
};

// Order: 1, 4, 7, 2, 5, 8, 3, 6, 9
const PosStep POS_SEQUENCE[9] = {
  { pos1Retrieve, pos1Return },
  { pos4Retrieve, pos4Return },
  { pos7Retrieve, pos7Return },
  { pos2Retrieve, pos2Return },
  { pos5Retrieve, pos5Return },
  { pos8Retrieve, pos8Return },
  { pos3Retrieve, pos3Return },
  { pos6Retrieve, pos6Return },
  { pos9Retrieve, pos9Return },
};

void runSequence() {
  homing();                       // Initial Homing
  delay(HOMING_SETTLE_MS);

  for (int i = 0; i < 9; i++) {
    POS_SEQUENCE[i].retrievePiece();
    delay(GRABBER_PICK_WAIT_MS + AFTER_PICK_DELAY_MS);   // Grabber picks the piece
    POS_SEQUENCE[i].returnBox();
  }

  homing();                       // Final Homing
}

// ==========================================
// Arduino entry points
// ==========================================
void setup() {
  pinMode(REF_SWITCH_HORIZONTAL, INPUT); pinMode(LIGHT_BARRIER_INSIDE, INPUT);
  pinMode(LIGHT_BARRIER_OUTSIDE, INPUT); pinMode(REF_SWITCH_VERTICAL, INPUT);
  pinMode(ENCODER_HORZ_IMP1, INPUT); pinMode(ENCODER_HORZ_IMP2, INPUT);
  pinMode(ENCODER_VERT_IMP1, INPUT); pinMode(ENCODER_VERT_IMP2, INPUT);
  pinMode(REF_SWITCH_CANTILEVER_FRONT, INPUT); pinMode(REF_SWITCH_CANTILEVER_BACK, INPUT);

  pinMode(MOTOR_CONVEYOR_FWD, OUTPUT); pinMode(MOTOR_CONVEYOR_BWD, OUTPUT);
  pinMode(MOTOR_HORZ_TO_RACK, OUTPUT); pinMode(MOTOR_HORZ_TO_CONVEYOR, OUTPUT);
  pinMode(MOTOR_VERT_DOWN, OUTPUT); pinMode(MOTOR_VERT_UP, OUTPUT);
  pinMode(MOTOR_CANTILEVER_FWD, OUTPUT); pinMode(MOTOR_CANTILEVER_BWD, OUTPUT);

  // Every motor OFF at start
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW); digitalWrite(MOTOR_CONVEYOR_BWD, LOW);
  digitalWrite(MOTOR_HORZ_TO_RACK, LOW); digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW);
  digitalWrite(MOTOR_VERT_DOWN, LOW);    digitalWrite(MOTOR_VERT_UP, LOW);
  digitalWrite(MOTOR_CANTILEVER_FWD, LOW); digitalWrite(MOTOR_CANTILEVER_BWD, LOW);

  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP1), handleVerticalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP2), handleVerticalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP1), handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP2), handleHorizontalEncoder, CHANGE);
}

bool sequenceDone = false;

void loop() {
  if (!sequenceDone) {
    delay(START_DELAY_MS);   // safety delay before the first movement
    runSequence();           // runs once
    sequenceDone = true;
  }
}
