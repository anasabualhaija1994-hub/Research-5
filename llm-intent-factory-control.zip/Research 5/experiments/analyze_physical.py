#!/usr/bin/env python3
"""
Analyse the physical experiments.   python analyze_physical.py [results_dir] [logs_dir]
Writes <results_dir>/analysis/: summary.md, table_throughput.tex, table_fault.tex, table_e2e.tex, fig_throughput.png,
                                 utilisation.csv, aborted_attempts.csv
logs_dir defaults to ../logs (jobs.csv and commands.csv written by the orchestrator service).
"""
import os
import statistics as stt
import sys

import pandas as pd

d = sys.argv[1] if len(sys.argv) > 1 else "results"
out = os.path.join(d, "analysis")
os.makedirs(out, exist_ok=True)
md = ["# Physical experiments - summary", ""]
MODE = {"seq": "Sequential (one job per piece)", "pipe": "Pipelined", "early": "Pipelined + early drop"}


def ms(x, dec=1):
    x = [v for v in x if pd.notna(v)]
    if not x:
        return "-"
    return f"{stt.mean(x):.{dec}f} ± {stt.stdev(x):.{dec}f}" if len(x) > 1 else f"{x[0]:.{dec}f}"


def tex_table(path, caption, label, cols, rows):
    t = [r"\begin{table}[t]", r"\centering", rf"\caption{{{caption}}}", rf"\label{{{label}}}",
         r"\begin{tabular}{l" + "r" * (len(cols) - 1) + "}", r"\toprule", " & ".join(cols) + r" \\", r"\midrule"]
    t += [" & ".join(str(c).replace("±", r"$\pm$").replace("%", r"\%") for c in r) + r" \\" for r in rows]
    t += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    open(path, "w").write("\n".join(t) + "\n")


# ---------------- loading (one folder per repetition, or one flat folder)
import csv as _csv
import glob
import json
import re


def load(name):
    """concat <d>/<name> and <d>/*/<name>; adds run_dir"""
    frames = []
    for f in sorted(glob.glob(os.path.join(d, name)) + glob.glob(os.path.join(d, "*", name))):
        x = pd.read_csv(f)
        x["run_dir"] = os.path.basename(os.path.dirname(f)) if os.path.dirname(f) != d else ""
        frames.append(x)
    return pd.concat(frames, ignore_index=True) if frames else None


def logged_attempts(mode, slots="1 4 7 2 5 8 3 6 9"):
    """attempts of a throughput mode in ../logs/jobs.csv (aborted ones included); None if the log is missing"""
    lg = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(d)), "..", "logs")
    f = os.path.join(lg, "jobs.csv")
    if not os.path.exists(f):
        return None
    js = [j for j in _csv.DictReader(open(f, encoding="utf-8")) if j["job_id"].startswith(f"exp-{mode}-")]
    if mode == "seq":
        reps = {j["job_id"].rsplit("-s", 1)[0] for j in js}
        return len(reps)
    return sum(1 for j in js if j["slots"] == slots)


def piece_done_times(run_dir):
    """unix times of the orchestrator piece_done events in one repetition folder"""
    f = os.path.join(d, run_dir, "raw_mqtt.csv")
    t = []
    if not os.path.exists(f):
        return t
    for r in _csv.reader(open(f, encoding="utf-8")):
        if len(r) > 4 and r[2] == "factory/orchestrator/event" and "piece_done" in r[4]:
            try:
                if json.loads(r[4]).get("event") == "piece_done":
                    t.append(float(r[0]))
            except Exception:
                pass
    return t


# ---------------- throughput
t = load("throughput.csv")
if t is not None:
    # the folder name is authoritative for the repetition number (early_r3b -> 3)
    for i, rd in t.run_dir.items():
        m = re.search(r"_r(\d+)", rd or "")
        if m:
            t.at[i, "rep"] = int(m.group(1))
    steady, lat = [], []
    for _, r in t.iterrows():
        pd_t = piece_done_times(r.run_dir) if r.run_dir else []
        g = [y - x for x, y in zip(pd_t, pd_t[1:])]
        steady.append(stt.mean(g) if g and r.result == "ok" else float("nan"))
        c = [float(v) for v in str(r.piece_cycles_s).split() if v not in ("", "nan")]
        lat.append(stt.mean(c) if c and r.result == "ok" else float("nan"))
    t["steady_cycle_s"], t["piece_latency_s"] = steady, lat
    t.to_csv(os.path.join(out, "throughput_all.csv"), index=False)
    n_pieces = t.slots.astype(str).str.split().str.len().max()

    md += [f"## Throughput ({n_pieces}-piece order, same slots and pieces)", "",
           "| Mode | OK / attempts | Makespan (s) | Per piece (s) | Steady-state cycle (s) | Piece latency (s) | Makespan speed-up | Throughput gain |",
           "|---|---|---|---|---|---|---|---|"]
    rows, base, base_cyc = [], None, None
    ok = t[t.result == "ok"]
    if (ok["mode"] == "seq").any():
        base = ok[ok["mode"] == "seq"].makespan_s.mean()
        base_cyc = ok[ok["mode"] == "seq"].steady_cycle_s.mean()
    for m in ("seq", "pipe", "early"):
        s = t[t["mode"] == m]
        if s.empty:
            continue
        g = s[s.result == "ok"]
        sp = f"{base / g.makespan_s.mean():.2f}x" if (base and len(g)) else "-"
        att = logged_attempts(m)
        r = [MODE[m], f"{len(g)}/{att if att else len(s)}", ms(g.makespan_s), ms(g.per_piece_s), ms(g.steady_cycle_s),
             ms(g.piece_latency_s), sp,
             f"{base_cyc / g.steady_cycle_s.mean():.2f}x" if (base_cyc and len(g)) else "-"]
        rows.append(r)
        md.append("| " + " | ".join(r) + " |")
    if base:
        for m in ("pipe", "early"):
            g = ok[ok["mode"] == m]
            if len(g):
                md.append(f"\n{MODE[m]}: makespan -{(1 - g.makespan_s.mean() / base) * 100:.1f}% vs sequential, "
                          f"steady-state cycle {g.steady_cycle_s.mean():.1f} s vs {base_cyc:.1f} s "
                          f"({base_cyc / g.steady_cycle_s.mean():.2f}x throughput).")
    fails = t[t.result != "ok"]
    md += ["", "Steady-state cycle = mean time between consecutive piece completions. "
           "Piece latency = mean time of one piece from retrieval to sorting.", "",
           f"Failed attempts with a results folder: {len(fails)} (all aborted attempts: see aborted_attempts.csv)" + "".join(f"\n- {r['mode']} ({r['run_dir'] or 'rep ' + str(r['rep'])}): {r['error']}"
                                                      for _, r in fails.iterrows()), ""]
    tex_table(os.path.join(out, "table_throughput.tex"),
              f"Physical line, {n_pieces}-piece order (mean $\\pm$ SD over successful repetitions).",
              "tab:throughput", ["Mode", "OK/att.", "Makespan (s)", "Per piece (s)", "Cycle (s)", "Latency (s)", "Makespan speed-up", "Throughput gain"], rows)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        modes = [m for m in ("seq", "pipe", "early") if (ok["mode"] == m).any()]
        fig, ax = plt.subplots(figsize=(6, 3.2))
        ax.boxplot([ok[ok["mode"] == m].makespan_s for m in modes], tick_labels=[MODE[m] for m in modes])
        for i, m in enumerate(modes, 1):
            y = ok[ok["mode"] == m].makespan_s
            ax.scatter([i] * len(y), y, s=12, zorder=3)
        ax.set_ylabel(f"Makespan, {n_pieces} pieces (s)")
        ax.grid(axis="y", alpha=.3)
        plt.xticks(fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(out, "fig_throughput.png"), dpi=200)
    except Exception as e:
        md.append(f"(figure skipped: {e})")

# ---------------- fault injection
STATIONS = ("hbw", "grabber", "oven", "colorsorter")


def fault_from_raw(run_dir, job_id):
    """Recompute, from the full raw log, the stations active at the fault and the time until every
    station reported idle (the live 3-s window in physical_experiments.py can miss the heartbeat)."""
    f = os.path.join(d, run_dir, "raw_mqtt.csv")
    if not os.path.exists(f):
        return None, None
    rows = list(_csv.reader(open(f, encoding="utf-8")))[1:]

    def js(x):
        try:
            return json.loads(x)
        except Exception:
            return {}
    t_job = next((float(r[0]) for r in rows if r[2].startswith("factory/orchestrator") and job_id in r[4]), None)
    if t_job is None:
        return None, None
    tf = None
    for r in rows:
        p = r[2].split("/")
        if float(r[0]) >= t_job and len(p) == 3 and p[1] in STATIONS and p[2] == "event" and js(r[4]).get("event") == "fault":
            tf = float(r[0])
            break
    if tf is None:
        return None, None
    active = {}
    for r in rows:
        if float(r[0]) > tf:
            break
        p = r[2].split("/")
        if len(p) == 3 and p[1] in STATIONS and p[2] == "event":
            ev = js(r[4]).get("event")
            if ev == "started":
                active[p[1]] = js(r[4]).get("cmd")
            elif ev in ("done", "fault"):
                active.pop(p[1], None)
    stops = {}
    for r in rows:
        p = r[2].split("/")
        if float(r[0]) >= tf and len(p) == 3 and p[1] in STATIONS and p[2] == "cmd" and js(r[4]).get("cmd") == "S":
            stops.setdefault(p[1], float(r[0]))
    quiet = {}
    if len(stops) == 4:
        t_all = max(stops.values())
        for r in rows:
            p = r[2].split("/")
            if float(r[0]) > t_all and len(p) == 3 and p[1] in STATIONS and p[2] == "status" and r[3] == "0" \
                    and js(r[4]).get("busy") is False:
                quiet.setdefault(p[1], float(r[0]))
    q = (max(quiet.values()) - tf) if len(quiet) == 4 else None
    return q, "+".join(f"{k}:{v}" for k, v in sorted(active.items())) or "none"


f = load("fault.csv")
if f is not None:
    seen = f[f.fault_station.notna() & (f.fault_station != "")].copy()
    act = []
    for i, r in seen.iterrows():
        q, a = fault_from_raw(r.run_dir, r.job_id)
        if q is not None:
            seen.at[i, "t_fault_to_quiescent_s"] = round(q, 3)
        act.append(a or "?")
    seen["active_at_fault"] = act
    seen.to_csv(os.path.join(out, "fault_all.csv"), index=False)
    md += ["## Fault injection", "",
           f"Repetitions: {len(f)}, station fault observed in {len(seen)}.", "",
           "| Metric | Mean ± SD | Max |", "|---|---|---|"]
    rows = []
    for col, name in [("t_fault_to_all_stops_s", "Fault $\\rightarrow$ STOP at all 4 stations (s)"),
                      ("t_fault_to_job_failed_s", "Fault $\\rightarrow$ error shown to operator (s)"),
                      ("t_fault_to_quiescent_s", "Fault $\\rightarrow$ all stations idle (s)*"),
                      ("recovery_home_s", "Recovery: home after fault removed (s)")]:
        v = pd.to_numeric(seen[col], errors="coerce")
        dec = 1 if col == "recovery_home_s" else 3
        r = [name, ms(v, dec), f"{v.max():.{dec}f}" if v.notna().any() else "-"]
        rows.append(r)
        md.append("| " + " | ".join(r) + " |")
    mot = int(pd.to_numeric(seen.motion_cmds_after_fault, errors="coerce").fillna(0).sum())
    rows.append(["Motion commands sent after the fault", str(mot), "-"])
    md += [f"| Motion commands sent after the fault (total) | {mot} | - |",
           f"| Recovered by a single home | {int(seen.home_ok.sum())}/{len(seen)} | - |", "",
           "*bounded by the station heartbeat period (5 s).", "",
           "Faults: " + ", ".join(f"{r.fault_station}:{r.fault_code}" for r in seen.itertuples()), "",
           "Other stations active at the fault: " + ", ".join(f"{r.run_dir or ''} rep {r.rep}: {r.active_at_fault}" for r in seen.itertuples()), ""]
    tex_table(os.path.join(out, "table_fault.tex"), "Fault-injection results on the physical line.",
              "tab:fault", ["Metric", "Mean $\\pm$ SD", "Max"], rows)

# ---------------- end-to-end from the chat
e = load("e2e.csv")
if e is not None:
    e = e.rename(columns={"dispatch_s": "dispatch_preflight_s"})
    ok_e = e[e.result != "job_failed"]          # jobs aborted by the operator STOP are reported separately
    md += ["## End-to-end from the n8n chat", "",
           "| Model | Command | n | LLM + validation (s) | Dispatch + preflight (s) | Factory execution (s) | Total (s) | LLM share |",
           "|---|---|---|---|---|---|---|---|"]
    rows = []
    order = {"status": 0, "home": 1, "run": 2, "stop": 3}
    for (lab, cmd), g in sorted(ok_e.groupby(["label", "cmd"]), key=lambda k: (k[0][0], order.get(k[0][1], 9))):
        moving = g.exec_s.median() > 0.5
        share = f"{(g.llm_validate_s / g.total_s).median() * 100:.1f}%" if moving else "-"
        r = [lab, cmd, str(len(g)), f"{g.llm_validate_s.median():.2f}", f"{g.dispatch_preflight_s.median():.2f}",
             f"{g.exec_s.median():.1f}", f"{g.total_s.median():.1f}", share]
        rows.append(r)
        md.append("| " + " | ".join(r) + " |")
    md += ["", "Medians over completed commands. LLM share is given only for commands that move the line. "
           "LLM + validation is measured on one clock (n8n); dispatch spans the n8n and logger clocks "
           f"(offset up to {abs(e.dispatch_preflight_s.clip(upper=0).min()):.2f} s, visible as negative values).",
           "Outcomes: " + ", ".join(f"{k}={v}" for k, v in e.result.value_counts().items()), "",
           f"LLM + validation over all {len(e)} chat commands: median {e.llm_validate_s.median():.2f} s, "
           f"max {e.llm_validate_s.max():.2f} s.", ""]
    tex_table(os.path.join(out, "table_e2e.tex"),
              "End-to-end latency decomposition for commands issued in the chat (medians).", "tab:e2e",
              ["Model", "Command", "n", "LLM+val. (s)", "Dispatch (s)", "Execution (s)", "Total (s)", "LLM share"], rows)

# ---------------- operator STOP from the chat while the line is moving
if e is not None and (e.cmd == "stop").any():
    md += ["## Operator STOP issued from the chat during a running job", "",
           "| Run | Stations active at STOP | STOP fan-out spread (ms) | Last station ack (ms) | Motion cmds after |",
           "|---|---|---|---|---|"]
    srows = []
    for _, r in e[e.cmd == "stop"].iterrows():
        f = os.path.join(d, r.run_dir, "raw_mqtt.csv")
        if not os.path.exists(f):
            continue
        rows = list(_csv.reader(open(f, encoding="utf-8")))[1:]

        def js(x):
            try:
                return json.loads(x)
            except Exception:
                return {}
        t_val = int(str(r.job_id).split("-")[3]) / 1000
        S = {}
        for x in rows:
            p = x[2].split("/")
            if float(x[0]) >= t_val - 1 and len(p) == 3 and p[1] in STATIONS and p[2] == "cmd" and js(x[4]).get("cmd") == "S":
                S.setdefault(p[1], float(x[0]))
        if len(S) < 4:
            continue
        t0 = min(S.values())
        active, phase = {}, {}
        for x in rows:
            if float(x[0]) > t0:
                break
            p = x[2].split("/")
            if len(p) == 3 and p[1] in STATIONS and p[2] == "event":
                ev = js(x[4])
                if ev.get("event") == "started":
                    active[p[1]] = ev.get("cmd")
                elif ev.get("event") in ("done", "fault"):
                    active.pop(p[1], None)
                elif ev.get("event") == "phase":
                    phase[p[1]] = ev.get("phase")
        acks = {}
        for x in rows:
            p = x[2].split("/")
            if float(x[0]) >= t0 and len(p) == 3 and p[1] in STATIONS and p[2] == "event" and js(x[4]).get("event") == "stop":
                acks.setdefault(p[1], float(x[0]))
        motion = sum(1 for x in rows if t0 < float(x[0]) < t0 + 30 and x[2].endswith("/cmd")
                     and x[2].split("/")[1] in STATIONS and js(x[4]).get("cmd") not in ("S", None))
        act = ", ".join(f"{k} {v}" + (f" ({phase[k]})" if k in phase and k != "hbw" else "") for k, v in sorted(active.items()))
        row = [r.label, act, f"{(max(S.values()) - t0) * 1000:.1f}",
               f"{(max(acks.values()) - t0) * 1000:.0f}" if len(acks) == 4 else "-", str(motion)]
        srows.append(row)
        md.append("| " + " | ".join(row) + " |")
    md += ["", "Fan-out = time between the first and last STOP published by the orchestrator; "
           "ack = station 'stop' event, relative to the first STOP.", ""]
    if srows:
        tex_table(os.path.join(out, "table_stop.tex"), "Operator STOP from the chat while stations were moving.",
                  "tab:stop", ["Model", "Active stations", "Fan-out (ms)", "Last ack (ms)", "Motion after"], srows)

# ------------------------------------------------------------------ station utilisation (pipelined runs)
def utilisation(run_dir):
    """Share of the window [first piece completion, last piece completion] in which each station executes a
    command (from its 'started' event to 'done'/'fault'/'stop'), excluding phases in which it waits for a piece
    (from a 'wait_piece' phase event to the next phase event). Homing commands are ignored."""
    f = os.path.join(d, run_dir, "raw_mqtt.csv")
    ev = []
    for r in _csv.reader(open(f, encoding="utf-8")):
        if len(r) < 5 or not r[2].endswith("/event"):
            continue
        try:
            e = json.loads(r[4])
            ev.append((float(r[0]), r[2].split("/")[1], e))
        except (ValueError, json.JSONDecodeError):
            continue
    acc = [t for t, s, e in ev if s == "orchestrator" and e.get("event") == "job_accepted" and e.get("cmd") == "run"]
    if acc:
        ev = [x for x in ev if x[0] >= acc[-1] - 1]
    done = [t for t, s, e in ev if s == "orchestrator" and e.get("event") == "piece_done"]
    if len(done) < 2:
        return None
    w0, w1 = done[0], done[-1]
    res = {"run_dir": run_dir, "window_s": round(w1 - w0, 1)}
    for st in ("hbw", "grabber", "oven", "colorsorter"):
        ivs, cur, wait = [], None, None
        for t, s, e in ev:
            if s != st:
                continue
            k = e.get("event")
            if k == "started" and e.get("cmd") != "H":
                cur, wait = t, None
            elif k == "phase" and cur is not None:
                if e.get("phase") == "wait_piece":
                    ivs.append((cur, t))
                    wait = t
                elif wait is not None:
                    cur, wait = t, None
            elif k in ("done", "fault", "stop") and cur is not None:
                if wait is None:
                    ivs.append((cur, t))
                cur, wait = None, None
        act = sum(max(0.0, min(b, w1) - max(a, w0)) for a, b in ivs)
        res[st] = round(100 * act / (w1 - w0), 1)
    return res


ut = [u for u in (utilisation(r) for r in sorted(os.listdir(d)) if r.startswith("pipe_")
                  and os.path.exists(os.path.join(d, r, "raw_mqtt.csv"))) if u]
if ut:
    u = pd.DataFrame(ut)
    u.to_csv(os.path.join(out, "utilisation.csv"), index=False)
    md += ["## Station utilisation, pipelined runs", "",
           "Window = first to last piece completion; active = executing a command, wait_piece phases excluded.", "",
           "| Run | Window (s) | HBW (%) | Grabber (%) | Oven (%) | Sorter (%) |", "|---|---|---|---|---|---|"]
    for _, r in u.iterrows():
        md.append(f"| {r.run_dir} | {r.window_s} | {r.hbw} | {r.grabber} | {r.oven} | {r.colorsorter} |")
    md.append(f"| mean | {u.window_s.mean():.1f} | {u.hbw.mean():.1f} | {u.grabber.mean():.1f} | {u.oven.mean():.1f} | "
              f"{u.colorsorter.mean():.1f} |")
    md.append("")

# ------------------------------------------------------------------ every aborted attempt (from the orchestrator logs)
LOGS = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(d)), "..", "logs")
FINAL = "1 4 7 2 5 8 3 6 9"


def experiment_of(j):
    jid = j["job_id"]
    if jid.startswith("exp-seq"):
        return "throughput, sequential"
    if jid.startswith("exp-pipe") and j["slots"] == FINAL:
        return "throughput, pipelined"
    if jid.startswith("exp-early") and j["slots"] == FINAL:
        return "throughput, pipelined + early drop"
    if jid.startswith("exp-fault"):
        return "fault injection"
    if jid.startswith("n8n-run") and j["ts"].startswith("2026-10-10T22"):
        return "end-to-end"
    return None      # protocol development (other piece orders, earlier tests)


if os.path.exists(os.path.join(LOGS, "jobs.csv")):
    jobs = list(_csv.DictReader(open(os.path.join(LOGS, "jobs.csv"), encoding="utf-8")))
    cmds = list(_csv.DictReader(open(os.path.join(LOGS, "commands.csv"), encoding="utf-8")))
    from datetime import datetime as _dt
    T = lambda x: _dt.fromisoformat(x).timestamp()
    rows = []
    for j in jobs:
        ex = experiment_of(j)
        if not ex or j["result"] != "failed" or j["error"] == "stop requested":
            continue
        cs = [c for c in cmds if c["job_id"] == j["job_id"]]
        own = [c for c in cs if c["result"] == "fault" and c["code"] != "ABORTED"]
        tf = min(T(c["ts"]) for c in own) if own else max(T(c["ts"]) for c in cs)
        after = sum(1 for c in cs if T(c["ts"]) - float(c["duration_s"]) > tf + 1e-3)
        aborted = sorted({c["station"] for c in cs if c["code"] == "ABORTED"})
        planned = ex == "fault injection" and "NO_BOX" in j["error"]
        rows.append({"ts": j["ts"], "experiment": ex, "job_id": j["job_id"], "pieces_done": j["pieces_done"],
                     "cause": j["error"], "n_faults": max(1, len(own)), "all_faults": "; ".join(f"{c['station']} {c['code']}" for c in own),
                     "injected": planned, "commands_after_fault": after,
                     "stations_aborted": " ".join(aborted)})
    pd.DataFrame(rows).to_csv(os.path.join(out, "aborted_attempts.csv"), index=False)
    md += ["## Aborted attempts (final protocol)", "",
           "| Experiment | Attempts | Completed | Aborted by unplanned faults | Unplanned faults | Commands after fault |",
           "|---|---|---|---|---|---|"]
    for ex in ("throughput, sequential", "throughput, pipelined", "throughput, pipelined + early drop",
               "fault injection", "end-to-end"):
        js = [j for j in jobs if experiment_of(j) == ex]
        if ex == "throughput, sequential":   # one attempt = one 9-piece repetition (job ids share a prefix)
            reps = {}
            for j in js:
                reps.setdefault(j["job_id"].rsplit("-s", 1)[0], []).append(j["result"])
            att, okn = len(reps), sum(all(v == "done" for v in r) for r in reps.values())
        elif ex == "fault injection":
            att, okn = len(js), sum("NO_BOX" in j["error"] for j in js)
        else:
            att, okn = len([j for j in js if j["error"] != "stop requested"]), sum(j["result"] == "done" for j in js)
        rr = [r for r in rows if r["experiment"] == ex and not r["injected"]]
        md.append(f"| {ex} | {att} | {okn} | {len(rr)} | {sum(r['n_faults'] for r in rr)} | "
                  f"{sum(r['commands_after_fault'] for r in rr)} |")
    md += ["", "Fault-injection 'completed' = attempts in which the injected NO_BOX fault was reached. "
           "End-to-end counts run commands only. A station fault that is not ABORTED counts as its own fault "
           "(firmware checks the abort flag before the stall/timeout check).", ""]

open(os.path.join(out, "summary.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")
print("\n".join(md))
print(f"\n-> {out}")
