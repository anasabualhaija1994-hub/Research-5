#!/usr/bin/env python3
"""Measures the offset between the n8n clock and this computer's clock (the MQTT logger's clock).

Each probe sends GET /webhook/clock; n8n answers with its Date.now(). The offset is
n8n_ms - midpoint(send, receive), and its uncertainty is half the round trip. The probe with the
shortest round trip is the most precise; the median over all probes is reported as well.

    python clock_offset.py --out clock_before.csv            (before the session)
    python clock_offset.py --out clock_after.csv             (after the session)
"""
import argparse, csv, json, statistics, time, urllib.request

ap = argparse.ArgumentParser()
ap.add_argument("--url", default="http://localhost/webhook/clock")
ap.add_argument("--n", type=int, default=50)
ap.add_argument("--out", required=True)
a = ap.parse_args()

rows = []
for i in range(a.n):
    t1 = time.time()
    with urllib.request.urlopen(a.url, timeout=10) as r:
        body = json.loads(r.read())
    t2 = time.time()
    if isinstance(body, list):
        body = body[0]
    n8n = body["now"] / 1000.0
    rows.append({"probe": i, "t_send": f"{t1:.4f}", "t_recv": f"{t2:.4f}", "n8n": f"{n8n:.3f}",
                 "rtt_ms": round((t2 - t1) * 1000, 1), "offset_ms": round((n8n - (t1 + t2) / 2) * 1000, 1)})
    time.sleep(0.1)
with open(a.out, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
best = min(rows, key=lambda r: r["rtt_ms"])
print(f"{len(rows)} probes. Best probe: offset {best['offset_ms']:+.1f} ms +/- {best['rtt_ms'] / 2:.1f} ms. "
      f"Median offset {statistics.median(r['offset_ms'] for r in rows):+.1f} ms, "
      f"median round trip {statistics.median(r['rtt_ms'] for r in rows):.1f} ms  -> {a.out}")
print("(positive = the n8n clock is ahead of this computer)")
