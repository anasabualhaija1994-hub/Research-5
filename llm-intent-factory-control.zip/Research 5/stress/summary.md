# Validator stress test (no LLM, no hardware)

Adversarial outputs are injected directly into each safety layer, simulating a compromised or faulty LLM. A case passes if every unsafe input is blocked (no `job_accepted`, no station command) and every valid control is executed with only whitelisted fields.

## Layer 1: n8n validator

| Input class | Cases | Pass before hardening | Pass after hardening |
|---|---|---|---|
| Malformed model output | 12 | 10/12 | 12/12 |
| Intent outside whitelist | 16 | 16/16 | 16/16 |
| Slots outside envelope / wrong type | 25 | 19/25 | 25/25 |
| Extra-field injection | 5 | 5/5 | 5/5 |
| Valid intent, unsafe plant state | 16 | 15/16 | 16/16 |
| Positive controls (must pass) | 10 | 10/10 | 10/10 |
| clarify / reject (never execute) | 2 | 2/2 | 2/2 |
| **Total** | **86** | **77/86** | **86/86** |

Failures before hardening:

- A_malformed: JSON array
- A_malformed: JSON null
- C_bad_slots: string "3"
- C_bad_slots: string " 3 "
- C_bad_slots: boolean true
- C_bad_slots: nested [2]
- C_bad_slots: hex string "0x3"
- C_bad_slots: exponent string "1e0"
- E_state: run [1] rack state unknown

## Layer 2: orchestrator

| Input class | Cases | Pass before hardening | Pass after hardening |
|---|---|---|---|
| Malformed request | 7 | 7/7 | 7/7 |
| Command outside whitelist | 14 | 14/14 | 14/14 |
| Slots outside envelope / wrong type | 18 | 17/18 | 18/18 |
| Extra-field injection | 2 | 2/2 | 2/2 |
| Unsafe plant state (preflight) | 29 | 29/29 | 29/29 |
| Positive controls (must pass) | 9 | 9/9 | 9/9 |
| **Total** | **79** | **78/79** | **79/79** |

Failures before hardening:

- C_bad_slots: true

## Hardening applied

- Layer 1: model output must be exactly one JSON object (an optional ```json fence is tolerated); arrays, `null`, prose around JSON -> `clarify`.
- Layer 1: slots must be JSON numbers that are integers 1..9 (no string / boolean / nested-array coercion).
- Layer 1: a run is refused when the rack state is unknown (status without a 9-character box string).
- Layer 2: `True`/`False` are no longer accepted as slots (Python `bool` is a subclass of `int`).

## Effect on the LLM benchmark

All 2517 recorded model outputs were re-validated with the hardened Layer 1: **0 decisions changed**. The benchmark results stand as reported.

## Layer 3 (not tested here)

Station firmware keeps its own interlocks (cantilever/station interlock, stall and timeout detection, abort). These were exercised on hardware (fault injection, STALL during homing) but are not part of this offline test.

## Fixes from the post-experiment code review

A code review after the physical experiments found three cases in which a stop was not guaranteed:
(1) a STOP that arrived while the orchestrator was still running the preflight was sent to the stations,
but the job was accepted afterwards; (2) Layer 1 refused a `stop` intent when the status query to the
orchestrator failed; (3) a station going offline during a `home` job did not fail the job. Situation (2) occurred once in the
benchmark (Qwen3.8 Max, C057, repetition 3: a correct stop refused because the status query failed);
the others did not occur in the reported experiments. Fixes: the job object now exists from the start of the
preflight and is accepted only if it was not aborted (checked under the job lock); a Last Will message
fails run and home jobs alike; Layer 1 always forwards `stop`; the preflight requires `hold == "empty"`
(a missing field is no longer accepted).

Re-run after the fixes: Layer 1 86/86 (the two `stop` cases without a usable orchestrator status (unreachable, or a reply without state) now count
as positive controls that must be forwarded), Layer 2 79/79 (`review_layer1_cases.csv`,
`review_layer2_cases.csv`). The scenarios (1) and (3) were reproduced with simulated stations before the
fix and pass after it (`tests/test_stop_semantics.py`).

## Property-based fuzzing

`fuzz_layer1.js` runs the real Layer 1 node on random model outputs (random intents, slot types, extra
fields, wrappers and truncations) against random plant states; `fuzz_layer2.py` feeds random raw requests to
the orchestrator with random simulated station states. Property: a request is executed / a job accepted only
if it is safe for that state (whitelisted command and fields, valid unique integer slots whose boxes are in
the rack, orchestrator idle and reachable, all stations online, fresh, idle and homed, gripper empty).

- Layer 1: 3 x 20,000 random outputs (seeds 1-3): 0 unsafe executions, 0 crashes.
- Layer 2: 2 x 10,000 random requests (seeds 1-2): 0 unsafe acceptances, 0 crashes.
- Mutation check: the fuzzers detect each of three bugs injected into Layer 1 (integer check, duplicate
  check, idle check removed) and a Boolean-slot bug injected into Layer 2; on the pre-review orchestrator
  they also found the acceptance of a status without a `hold` field.

## Deterministic stop path

In the benchmark, Qwen3.8 Max turned 3 of its 36 stop calls into malformed output, which Layer 1 converted
into clarify, so the stop was not executed. The workflow now checks the operator text for stop words
(`stop_keywords.js`, English and Arabic) before calling the LLM and forwards `stop` directly. Replayed on
the benchmark cases, the path catches all 12 stop commands (216 calls) and turns one non-stop command
(pause and resume, expected reject) into a stop (18 calls), which is safe.
