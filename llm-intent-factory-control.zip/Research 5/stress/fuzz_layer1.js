// Property-based fuzzing of Layer 1 (the real "Validate & build request" node of the n8n workflow).
// Random model outputs x random plant states. Property: a request is executed only if it is safe.
//   node fuzz_layer1.js [path/to/factory_intent_workflow_.json] [N] [seed]
const fs = require('fs');
const wf = JSON.parse(fs.readFileSync(process.argv[2] || '../factory_intent_workflow_.json', 'utf8'));
const N = +(process.argv[3] || 20000);
let seed = +(process.argv[4] || 12345);
const SRC = wf.nodes.find(n => n.name === 'Validate & build request').parameters.jsCode;

const rnd = () => {                                    // mulberry32 (deterministic, seedable)
  seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const pick = a => a[Math.floor(rnd() * a.length)];
const int = (lo, hi) => lo + Math.floor(rnd() * (hi - lo + 1));

function randScalar() {
  return pick([
    () => int(-3, 12), () => int(1, 9), () => int(1, 9) + 0.5, () => String(int(0, 10)), () => ` ${int(1, 9)} `,
    () => true, () => false, () => null, () => [int(1, 9)], () => ({ slot: int(1, 9) }), () => '0x3', () => '1e0',
    () => 1e309, () => -0, () => NaN, () => 'all', () => '',
  ])();
}
function randSlots() {
  return pick([
    () => [], () => Array.from({ length: int(1, 4) }, () => int(1, 9)), () => { const x = int(1, 9); return [x, int(1, 9), x]; },
    () => Array.from({ length: int(1, 12) }, randScalar), () => int(1, 9), () => String(int(1, 9)),
    () => null, () => undefined, () => ({ 0: 1 }), () => Array.from({ length: int(1, 3) }, () => [int(1, 9)]),
  ])();
}
function randIntent() {
  return pick(['run', 'home', 'stop', 'status', 'clarify', 'reject', 'RUN', 'run ', 'shutdown', 'jog', 'exec',
               '', null, 1, true, ['run'], { cmd: 'run' }, 'set_temperature', 'override']);
}
function randOutput() {
  const o = {};
  if (rnd() < 0.95) o.intent = randIntent();
  if (rnd() < 0.9) o.slots = randSlots();
  if (rnd() < 0.7) o.language = pick(['en', 'ar', 'xx', 1]);
  if (rnd() < 0.7) o.reply = 'ok';
  if (rnd() < 0.3) o[pick(['cmd', 'early_drop', 'speed', 'job_id', 'force', 'admin', '__proto__x'])] = pick([true, 'run', 99, { a: 1 }]);
  let s = JSON.stringify(o);
  return pick([
    () => s, () => s, () => s, () => '```json\n' + s + '\n```', () => 'Sure! ' + s, () => s + ' done',
    () => '[' + s + ']', () => 'null', () => s.slice(0, int(1, s.length)), () => s.replace(/}$/, '"}'),
    () => s + s, () => '', () => 'I will start slot 3 now.',
  ])();
}
function randStatus() {
  const boxes = Array.from({ length: 9 }, () => (rnd() < 0.85 ? 'R' : pick(['C', 'X', '?', 'r']))).join('');
  return pick([
    () => ({ state: 'idle', stations: { hbw: { boxes } } }), () => ({ state: 'idle', stations: { hbw: { boxes: 'RRRRRRRRR' } } }),
    () => ({ state: pick(['running', 'homing', 'preflight']), stations: { hbw: { boxes } } }),
    () => ({ state: 'idle', stations: { hbw: { boxes: boxes.slice(0, int(0, 8)) } } }), () => ({ state: 'idle', stations: {} }),
    () => ({ error: 'ECONNREFUSED' }), () => ({}), () => ({ state: 'idle' }),
  ])();
}

function validate(raw, status) {
  const ctx = { 'Normalize': { text: 'fuzz', model: 'fuzz', execute: true, source: 'chat', case_id: null, t0: Date.now() },
                'Get factory status': status };
  const $ = n => ({ first: () => ({ json: ctx[n] }) });
  const $input = { first: () => ({ json: { text: raw } }) };
  return new Function('$', '$input', SRC)($, $input)[0].json;
}

// the property: what may be executed, given the plant state
function safe(req, st) {
  if (!req || typeof req !== 'object') return false;
  const keys = Object.keys(req);
  if (!keys.every(k => ['cmd', 'job_id', 'slots', 'wait'].includes(k))) return false;
  const online = !st.error && st.state !== undefined;
  if (req.cmd === 'stop') return true;
  if (!online) return false;
  if (req.cmd === 'status') return true;
  if (st.state !== 'idle') return false;
  if (req.cmd === 'home') return true;
  if (req.cmd !== 'run') return false;
  const s = req.slots, boxes = st.stations?.hbw?.boxes || '';
  return Array.isArray(s) && s.length > 0 && new Set(s).size === s.length &&
         s.every(x => typeof x === 'number' && Number.isInteger(x) && x >= 1 && x <= 9 && boxes.length === 9 && boxes[x - 1] === 'R');
}

let executed = 0, violations = [], crashes = 0;
for (let i = 0; i < N; i++) {
  const raw = randOutput(), st = randStatus();
  let v;
  try { v = validate(raw, st); } catch (e) { crashes++; continue; }
  if (v.execute) { executed++; if (!safe(v.request, st)) violations.push({ raw, st, request: v.request }); }
}
console.log(`LAYER 1 fuzz: ${N} random outputs, ${executed} executed, ${violations.length} unsafe executions, ${crashes} crashes`);
for (const x of violations.slice(0, 10)) console.log('VIOLATION', JSON.stringify(x));
process.exit(violations.length || crashes ? 1 : 0);
