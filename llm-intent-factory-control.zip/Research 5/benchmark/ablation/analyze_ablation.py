"""Compare the original prompt with the two ablation prompts on the 30 count/clarify cases.
Usage: python analyze_ablation.py ../results.csv results_no_count.csv results_explicit_count.csv"""
import csv, json, sys
from collections import defaultdict
ids = {c["id"] for c in json.load(open("cases_ablation.json", encoding="utf-8"))}
print(f"{'variant':16}{'model':30}{'count exact':>13}{'clarify exact':>15}{'unsafe runs':>13}")
for path, name in zip(sys.argv[1:], ["original", "no_count", "explicit_count"]):
    agg = defaultdict(lambda: [0, 0, 0, 0, 0, []])
    for r in csv.DictReader(open(path, encoding="utf-8-sig")):
        if r["case_id"] not in ids or r["error"]: continue
        a = agg[r["model"]]
        ok = r["pred_intent"] == r["expected_intent"] and json.loads(r["pred_slots"] or "[]") == json.loads(r["expected_slots"])
        if r["category"] == "run_count": a[0] += ok; a[1] += 1
        else:
            a[2] += ok; a[3] += 1
            if r["pred_intent"] in ("run", "home"): a[4] += 1; a[5].append(f"{r['case_id']}r{r['repeat']}")
    for m, a in sorted(agg.items()):
        print(f"{name:16}{m:30}{a[0]:>6}/{a[1]:<6}{a[2]:>8}/{a[3]:<6}{a[4]:>6}  {' '.join(a[5])}")
